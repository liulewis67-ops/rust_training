# M10-L04 示例：feature 与可复现构建

此 workspace 无第三方依赖，并提交 Cargo.lock。Cargo.toml 描述清单和依赖范围，Cargo.lock 由 Cargo 维护本 workspace 的精确解析结果。

profile-cli 的默认 feature 集合为空，成功时 stderr 为空。trace-input-source 是可选编译期诊断；启用时 stderr 多一行 input source 标签，stdout 报告与退出码契约不变。

从 workspace 根目录运行：

~~~text
cargo test --workspace --no-default-features --locked --offline
cargo test -p profile-cli --features trace-input-source --locked --offline
cargo test --workspace --all-features --locked --offline
cargo doc --workspace --all-features --no-deps --locked --offline
cargo tree -e features --offline
~~~

干净解压后可执行相同命令；如果需要修改 Cargo.lock，--locked 会令命令失败，--offline 禁止网络取包。公开输出和 feature 作用见本 README 与 CLI 的测试契约。
