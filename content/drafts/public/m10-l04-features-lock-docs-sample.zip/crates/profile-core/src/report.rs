use crate::ProfileNameError;
use crate::name::ProfileName;

/// Formats a validated profile name behind the core crate's stable interface.
///
/// # Examples
///
/// ```rust
/// use profile_core::{render_profile_report, ProfileNameError};
///
/// assert_eq!(
///     render_profile_report(" training_user "),
///     Ok(String::from("profile=training_user"))
/// );
/// assert_eq!(
///     render_profile_report("bad name"),
///     Err(ProfileNameError::InvalidCharacters)
/// );
/// ```
///
/// # Errors
/// Returns the specific validation failure when `raw_name` is not a profile name.
pub fn render_profile_report(raw_name: &str) -> Result<String, ProfileNameError> {
    let name = ProfileName::parse(raw_name)?;
    Ok(format!("profile={}", name.as_str()))
}
