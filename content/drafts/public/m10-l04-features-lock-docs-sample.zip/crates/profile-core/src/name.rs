/// Describes why a profile name does not satisfy the domain rules.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ProfileNameError {
    /// The trimmed name contains no characters.
    Empty,
    /// The name contains characters outside ASCII letters, digits, `_`, or `-`.
    InvalidCharacters,
    /// The valid ASCII name contains more than 24 bytes.
    TooLong,
}

/// Holds a validated profile name inside the core crate.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct ProfileName(String);

impl ProfileName {
    /// Validates and stores the trimmed profile name.
    pub(super) fn parse(raw: &str) -> Result<Self, ProfileNameError> {
        let trimmed = raw.trim();
        if trimmed.is_empty() {
            return Err(ProfileNameError::Empty);
        }
        if !trimmed.bytes().all(is_valid_profile_byte) {
            return Err(ProfileNameError::InvalidCharacters);
        }
        if trimmed.len() > 24 {
            return Err(ProfileNameError::TooLong);
        }
        Ok(Self(trimmed.to_owned()))
    }

    /// Borrows the validated name for formatting without exposing its field.
    pub(super) fn as_str(&self) -> &str {
        &self.0
    }
}

/// Accepts only the ASCII characters in the profile-name contract.
fn is_valid_profile_byte(byte: u8) -> bool {
    byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'-')
}

#[cfg(test)]
mod tests {
    use super::ProfileName;

    /// Keeps the trimmed representation invariant inside the name module.
    #[test]
    fn parse_trims_outer_whitespace_before_storing() {
        let name = ProfileName::parse(" training_user ").unwrap();

        assert_eq!(name.as_str(), "training_user");
    }
}
