use profile_core::{ProfileNameError, render_profile_report};

/// Keeps whitespace normalization observable through the public library API.
#[test]
fn formats_a_trimmed_profile_name() {
    assert_eq!(
        render_profile_report(" training_user "),
        Ok(String::from("profile=training_user"))
    );
}

/// Keeps invalid-character errors stable for external callers.
#[test]
fn rejects_spaces_inside_a_profile_name() {
    assert_eq!(
        render_profile_report("bad name"),
        Err(ProfileNameError::InvalidCharacters)
    );
}
