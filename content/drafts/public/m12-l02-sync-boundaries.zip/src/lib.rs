//! Demonstrates Send/Sync boundaries and synchronization for shared writes.
//!
//! `Rc` cannot be moved to another thread:
//!
//! ```compile_fail
//! use std::rc::Rc;
//! use std::thread;
//!
//! let value = Rc::new(String::from("local"));
//! thread::spawn(move || value.len()).join().unwrap();
//! ```
//!
//! `Arc` does not make `RefCell` safe to share across threads:
//!
//! ```compile_fail
//! use std::cell::RefCell;
//! use std::sync::Arc;
//! use std::thread;
//!
//! let value = Arc::new(RefCell::new(4_u32));
//! thread::spawn(move || *value.borrow()).join().unwrap();
//! ```

use std::sync::{Arc, Mutex};
use std::thread::{self, JoinHandle};

/// Immutable worker settings that satisfy Send and Sync.
#[derive(Debug)]
pub struct Config {
    /// Number of retries workers may perform.
    pub retries: u8,
}

fn join_all(workers: Vec<JoinHandle<()>>) -> thread::Result<()> {
    let mut first_panic = None;
    for worker in workers {
        if let Err(payload) = worker.join() {
            if first_panic.is_none() {
                first_panic = Some(payload);
            }
        }
    }

    match first_panic {
        Some(payload) => Err(payload),
        None => Ok(()),
    }
}

/// Spawns a reader that owns one Arc handle to immutable configuration.
#[must_use]
pub fn read_retries(config: Arc<Config>) -> JoinHandle<u8> {
    thread::spawn(move || config.retries)
}

/// Increments one mutex-protected counter from several worker threads.
///
/// # Errors
/// Returns a worker panic payload if any worker panics.
///
/// # Panics
/// Panics if the OS cannot create a thread or if a counter increment overflows.
pub fn parallel_increment(
    worker_count: usize,
    increments_per_worker: usize,
) -> thread::Result<usize> {
    let counter = Arc::new(Mutex::new(0_usize));
    let mut workers = Vec::with_capacity(worker_count);

    for _ in 0..worker_count {
        let worker_counter = Arc::clone(&counter);
        workers.push(thread::spawn(move || {
            for _ in 0..increments_per_worker {
                let mut guard = worker_counter
                    .lock()
                    .expect("counter mutex should not be poisoned");
                *guard = guard.checked_add(1).expect("counter overflow");
            }
        }));
    }

    join_all(workers)?;

    let guard = counter
        .lock()
        .expect("successful workers leave the counter mutex unpoisoned");
    Ok(*guard)
}

#[cfg(test)]
mod tests {
    use super::join_all;
    use std::sync::Arc;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::thread;

    #[test]
    fn waits_for_every_worker_before_returning_first_panic() {
        let finished = Arc::new(AtomicUsize::new(0));
        let mut workers = vec![thread::spawn(|| -> () {
            panic!("expected worker panic");
        })];

        for _ in 0..3 {
            let finished = Arc::clone(&finished);
            workers.push(thread::spawn(move || {
                finished.fetch_add(1, Ordering::Relaxed);
            }));
        }

        assert!(join_all(workers).is_err());
        assert_eq!(finished.load(Ordering::Relaxed), 3);
    }
}
