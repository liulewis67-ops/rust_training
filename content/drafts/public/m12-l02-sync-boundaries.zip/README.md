# Send/Sync Boundaries

This crate shows that immutable `Arc<Config>` can be read by a worker, while `Arc<Mutex<usize>>` is needed for concurrent writes to one ordinary counter. Compile-fail doctests show that moving `Rc<T>` to a thread fails and wrapping `RefCell<T>` in Arc does not make it Sync.

The counter tests assert only the final invariant, not worker order. No third-party crates are used.

Run `cargo fmt -- --check`, `cargo check --offline`, `cargo test --offline`, `cargo clippy --all-targets --offline -- -D warnings`, and `cargo doc --no-deps --offline`.
