use std::sync::Arc;
use sync_boundaries::{Config, parallel_increment, read_retries};

#[test]
fn immutable_arc_config_is_read_in_worker_and_remains_available() {
    let config = Arc::new(Config { retries: 5 });
    assert_eq!(read_retries(Arc::clone(&config)).join().unwrap(), 5);
    assert_eq!(config.retries, 5);
}

#[test]
fn mutex_serializes_updates_from_multiple_workers() {
    assert_eq!(parallel_increment(1, 1).unwrap(), 1);
    assert_eq!(parallel_increment(3, 20).unwrap(), 60);
}

#[test]
fn zero_workers_leave_the_shared_counter_unchanged() {
    assert_eq!(parallel_increment(0, 20).unwrap(), 0);
}
