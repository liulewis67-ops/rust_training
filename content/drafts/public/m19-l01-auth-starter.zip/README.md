# M19-L01 authorization exercise

This public starter teaches the boundary between a trusted authentication adapter and per-resource authorization. The in-process tests inject `Principal` as trusted adapter output; this crate does not implement login, sessions, cookies, or credential validation.

The baseline intentionally has two authorization gaps: authenticated non-owners can read the fixture, and the owner-only export endpoint is absent. The contract tests expose those failures. Complete the TODO owner comparison and export route, then require all six contract tests and three unit tests to pass.

Run from this directory with the pinned lockfile:

```text
cargo test --locked
cargo clippy --locked --all-targets -- -D warnings
```

The R3 Linux container is deliberately not launched for this author-side package.
