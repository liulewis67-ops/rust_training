//! Black-box requests distinguish missing authentication from failed resource authorization.

use axum::body::{Body, to_bytes};
use axum::http::{Method, Request, StatusCode};
use axum::response::Response;
use m19_l01_auth::{ErrorBody, Principal, RecordView, app};
use serde_json::Value;
use tower::ServiceExt;

/// Sends a record request after the test adapter inserts an optional trusted principal.
async fn record_request(uri: &str, principal: Option<Principal>, method: Method) -> Response {
    let mut request = Request::builder()
        .method(method)
        .uri(uri)
        .body(Body::empty())
        .expect("valid test request");
    if let Some(principal) = principal {
        request.extensions_mut().insert(principal);
    }
    app().oneshot(request).await.expect("router response")
}

/// Decodes a small JSON HTTP body for contract assertions.
async fn response_json(response: Response) -> Value {
    let bytes = to_bytes(response.into_body(), 8 * 1024)
        .await
        .expect("bounded JSON response");
    serde_json::from_slice(&bytes).expect("valid JSON response")
}

/// Missing identity is an authentication failure, not an owner authorization failure.
#[tokio::test]
async fn anonymous_read_requires_authentication() {
    let response = record_request("/api/v1/records/record-10", None, Method::GET).await;
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    let body: ErrorBody =
        serde_json::from_value(response_json(response).await).expect("safe error contract");
    assert_eq!(body.code, "authentication_required");
}

/// The trusted owner can read the private record.
#[tokio::test]
async fn owner_can_read_record() {
    let response = record_request(
        "/api/v1/records/record-10",
        Some(Principal::new(7)),
        Method::GET,
    )
    .await;
    assert_eq!(response.status(), StatusCode::OK);
    let body: RecordView =
        serde_json::from_value(response_json(response).await).expect("record view");
    assert_eq!(body.id, "record-10");
    assert_eq!(body.title, "Private design notes");
}

/// A valid principal without permission must not pass merely because authentication succeeded.
#[tokio::test]
async fn authenticated_non_owner_cannot_read_record() {
    let response = record_request(
        "/api/v1/records/record-10",
        Some(Principal::new(12)),
        Method::GET,
    )
    .await;
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
    assert_eq!(response_json(response).await["code"], "forbidden");
}

/// The protected export action is implemented for the owner in the implementation exercise.
#[tokio::test]
async fn owner_can_export_record() {
    let response = record_request(
        "/api/v1/records/record-10/export",
        Some(Principal::new(7)),
        Method::GET,
    )
    .await;
    assert_eq!(response.status(), StatusCode::OK);
    assert_eq!(response_json(response).await["id"], "record-10");
}

/// The same export action must reject an authenticated caller who does not own the record.
#[tokio::test]
async fn authenticated_non_owner_cannot_export_record() {
    let response = record_request(
        "/api/v1/records/record-10/export",
        Some(Principal::new(12)),
        Method::GET,
    )
    .await;
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
    assert_eq!(response_json(response).await["code"], "forbidden");
}

/// A client-supplied query identity cannot replace the trusted principal from the adapter.
#[tokio::test]
async fn query_user_id_does_not_change_authenticated_identity() {
    let response = record_request(
        "/api/v1/records/record-10?user_id=7",
        Some(Principal::new(12)),
        Method::GET,
    )
    .await;
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
}
