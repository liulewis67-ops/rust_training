//! Small Axum exercise that separates trusted caller identity from record authorization.

use axum::extract::{Extension, Path, State};
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::{Json, Router};
use serde::{Deserialize, Serialize};

/// Creates the exercise API with one private fixture record owned by user 7.
#[must_use = "the returned router must be served or used by a test"]
pub fn app() -> Router {
    let state = AppState::default();
    Router::new()
        .route("/api/v1/records/{record_id}", get(read_record_handler))
        .fallback(unknown_route)
        .with_state(state)
}

/// Identity inserted only after a trusted adapter validates its credential or session.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Principal {
    /// Stable server-side caller identifier.
    pub user_id: u64,
}

impl Principal {
    /// Builds the caller value used by the in-process trusted test adapter.
    #[must_use]
    pub const fn new(user_id: u64) -> Self {
        Self { user_id }
    }
}

/// Public representation of the fixture record; owner information stays server-side.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct RecordView {
    /// Stable resource identifier.
    pub id: String,
    /// Safe user-visible title.
    pub title: String,
}

/// Stable error returned at the HTTP boundary.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct ErrorBody {
    /// Machine-readable failure category.
    pub code: String,
    /// Safe caller-facing explanation.
    pub message: String,
}

/// Fixture data and access policy for one independent router instance.
#[derive(Clone, Debug)]
struct AppState {
    record: PrivateRecord,
}

impl Default for AppState {
    /// Creates a private record without storing secrets in the public DTO.
    fn default() -> Self {
        Self {
            record: PrivateRecord {
                id: 10,
                owner_id: 7,
                title: "Private design notes".to_owned(),
            },
        }
    }
}

/// Server-side resource metadata used only during authorization.
#[derive(Clone, Debug)]
struct PrivateRecord {
    id: u64,
    // This value is intentionally reserved for the learner's owner check.
    #[allow(dead_code)]
    owner_id: u64,
    title: String,
}

impl PrivateRecord {
    /// Converts a visible resource to its owner-free API representation.
    fn into_view(self) -> RecordView {
        RecordView {
            id: format!("record-{}", self.id),
            title: self.title,
        }
    }
}

/// Reads one record after authentication and the exercise's owner authorization policy.
async fn read_record_handler(
    State(state): State<AppState>,
    Path(raw_id): Path<String>,
    principal: Option<Extension<Principal>>,
) -> Response {
    let Some(Extension(principal)) = principal else {
        return error_response(StatusCode::UNAUTHORIZED, "authentication_required");
    };
    let Some(record_id) = parse_record_id(&raw_id) else {
        return error_response(StatusCode::NOT_FOUND, "resource_not_found");
    };
    if state.record.id != record_id {
        return error_response(StatusCode::NOT_FOUND, "resource_not_found");
    }
    if let Err(error) = authorize_owner(Some(principal), &state.record) {
        return access_error_response(error);
    }
    (StatusCode::OK, Json(state.record.into_view())).into_response()
}

/// Requires a caller identity and then verifies it owns the resource.
fn authorize_owner(
    principal: Option<Principal>,
    record: &PrivateRecord,
) -> Result<(), AccessError> {
    let _principal = principal.ok_or(AccessError::Unauthenticated)?;
    // TODO: compare the authenticated principal with `record.owner_id` before allowing the read.
    let _ = record.owner_id;
    Ok(())
}

/// Maps a canonical opaque fixture path into the private record identifier.
fn parse_record_id(raw: &str) -> Option<u64> {
    let suffix = raw.strip_prefix("record-")?;
    let id = suffix.parse::<u64>().ok()?;
    (id > 0 && id.to_string() == suffix).then_some(id)
}

/// Converts an access decision to the exercise's stable safe HTTP error response.
fn access_error_response(error: AccessError) -> Response {
    match error {
        AccessError::Unauthenticated => {
            error_response(StatusCode::UNAUTHORIZED, "authentication_required")
        }
        AccessError::Forbidden => error_response(StatusCode::FORBIDDEN, "forbidden"),
    }
}

/// Builds an error body without exposing resource ownership or identity details.
fn error_response(status: StatusCode, code: &'static str) -> Response {
    let message = match code {
        "authentication_required" => "Authentication is required.",
        "forbidden" => "The caller cannot access this resource.",
        _ => "The resource was not found.",
    };
    (
        status,
        Json(ErrorBody {
            code: code.to_owned(),
            message: message.to_owned(),
        }),
    )
        .into_response()
}

/// Returns the stable not-found contract for unknown API paths.
async fn unknown_route() -> Response {
    error_response(StatusCode::NOT_FOUND, "resource_not_found")
}

/// The owner policy distinguishes an absent identity from a valid but unauthorized caller.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum AccessError {
    /// The authentication adapter did not provide a validated principal.
    Unauthenticated,
    /// The authenticated caller does not own this resource.
    // The public starter constructs this after the learner adds the owner comparison.
    #[allow(dead_code)]
    Forbidden,
}

#[cfg(test)]
mod tests {
    use super::{AccessError, Principal, PrivateRecord, authorize_owner, parse_record_id};

    /// A missing principal is an authentication failure, before any owner decision.
    #[test]
    fn missing_principal_is_unauthenticated() {
        let record = PrivateRecord {
            id: 10,
            owner_id: 7,
            title: "private".to_owned(),
        };
        assert_eq!(
            authorize_owner(None, &record),
            Err(AccessError::Unauthenticated)
        );
    }

    /// Resource paths accept only one canonical positive fixture ID.
    #[test]
    fn record_path_requires_a_canonical_id() {
        assert_eq!(parse_record_id("record-10"), Some(10));
        assert_eq!(parse_record_id("record-010"), None);
        assert_eq!(parse_record_id("record-0"), None);
        assert_eq!(parse_record_id("10"), None);
    }

    /// A correct policy permits only the principal whose ID matches the record owner.
    #[test]
    fn owner_is_the_only_authorized_principal() {
        let record = PrivateRecord {
            id: 10,
            owner_id: 7,
            title: "private".to_owned(),
        };
        assert_eq!(authorize_owner(Some(Principal::new(7)), &record), Ok(()));
        assert_eq!(
            authorize_owner(Some(Principal::new(12)), &record),
            Err(AccessError::Forbidden)
        );
    }
}
