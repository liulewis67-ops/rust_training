# M21-L03 pool/query/queue diagnostic starter

Run `cargo test --locked` on Windows to see the multi-signal contract failure. A clean baseline intentionally reports only one finding when pool, query, and queue thresholds overlap. Restore from `../m21-l03-diagnostic-starter.zip` and verify `starter-manifest.json` before restarting. Samples are local and synthetic: no PostgreSQL or Linux container is started.
