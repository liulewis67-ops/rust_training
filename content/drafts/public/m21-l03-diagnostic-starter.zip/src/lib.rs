//! M21-L03 diagnostic snapshot starter.

/// A bounded observation snapshot collected for one fixed time window.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Snapshot {
    /// p95 wait to acquire a database connection, in milliseconds.
    pub acquire_wait_p95_ms: u64,
    /// p95 time spent executing the database query, in milliseconds.
    pub query_p95_ms: u64,
    /// Current queued work items.
    pub queue_depth: u32,
    /// Maximum queued work items; zero means no queue sample is available.
    pub queue_capacity: u32,
    /// Current checked-out pool connections.
    pub pool_in_use: u32,
    /// Configured maximum pool connections.
    pub pool_max: u32,
}

/// A diagnostic signal supported by one or more measurements.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Finding {
    /// Acquire wait is high while every configured connection is checked out.
    PoolPressure,
    /// Query execution p95 is above the fixture threshold.
    SlowQuery,
    /// Queue depth is at least 80 percent of a known nonzero capacity.
    QueueBacklog,
}

/// Returns findings for one snapshot, currently stopping after the first match.
#[must_use]
pub fn findings(snapshot: Snapshot) -> Vec<Finding> {
    if snapshot.query_p95_ms >= 250 {
        vec![Finding::SlowQuery]
    } else if snapshot.acquire_wait_p95_ms >= 50
        && snapshot.pool_max > 0
        && snapshot.pool_in_use >= snapshot.pool_max
    {
        vec![Finding::PoolPressure]
    } else if snapshot.queue_capacity > 0
        && u64::from(snapshot.queue_depth) * 100 >= u64::from(snapshot.queue_capacity) * 80
    {
        vec![Finding::QueueBacklog]
    } else {
        Vec::new()
    }
}
