use m21_l03_diagnostic::{Finding, Snapshot, findings};

/// Makes a low-noise snapshot with only the specified queue values changed.
fn snapshot(queue_depth: u32, queue_capacity: u32) -> Snapshot {
    Snapshot {
        acquire_wait_p95_ms: 8,
        query_p95_ms: 18,
        queue_depth,
        queue_capacity,
        pool_in_use: 5,
        pool_max: 16,
    }
}

/// Pool acquisition wait with all connections in use is distinct from query latency.
#[test]
fn detects_pool_pressure_from_wait_and_saturation() {
    let event = Snapshot {
        acquire_wait_p95_ms: 240,
        pool_in_use: 16,
        pool_max: 16,
        ..snapshot(2, 100)
    };
    assert_eq!(findings(event), vec![Finding::PoolPressure]);
}

/// Query execution latency can be high while pool acquisition remains normal.
#[test]
fn detects_slow_query_without_pool_wait() {
    let event = Snapshot {
        query_p95_ms: 900,
        ..snapshot(3, 100)
    };
    assert_eq!(findings(event), vec![Finding::SlowQuery]);
}

/// Queue pressure is independent of query execution and pool utilization.
#[test]
fn detects_queue_backlog_without_slow_query() {
    assert_eq!(findings(snapshot(80, 100)), vec![Finding::QueueBacklog]);
}

/// Simultaneous symptoms must all survive rather than shadow one another.
#[test]
fn preserves_all_concurrent_findings() {
    let event = Snapshot {
        acquire_wait_p95_ms: 100,
        query_p95_ms: 300,
        pool_in_use: 16,
        pool_max: 16,
        ..snapshot(90, 100)
    };
    assert_eq!(
        findings(event),
        vec![
            Finding::PoolPressure,
            Finding::SlowQuery,
            Finding::QueueBacklog
        ]
    );
}

/// Zero queue capacity means that no queue measurement was supplied.
#[test]
fn does_not_flag_missing_or_healthy_signals() {
    assert!(findings(snapshot(0, 0)).is_empty());
    assert!(findings(snapshot(50, 100)).is_empty());
}
