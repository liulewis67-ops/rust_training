//! Displays the runtime-target facts embedded into the release executable.

/// Prints profile, target and package metadata for a release smoke check.
fn main() {
    let facts = m22_l01_release::build_facts();
    println!(
        "package_version={} target={}-{} debug_assertions={}",
        facts.package_version, facts.arch, facts.os, facts.debug_assertions
    );
}
