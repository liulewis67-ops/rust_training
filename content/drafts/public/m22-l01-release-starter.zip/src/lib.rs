//! M22-L01 release profile and executable target fact starter.

/// Build-time facts embedded in this executable.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct BuildFacts {
    /// Executable operating-system target.
    pub os: &'static str,
    /// Executable architecture target.
    pub arch: &'static str,
    /// Whether this build enables Rust debug assertions.
    pub debug_assertions: bool,
    /// Cargo package version embedded in the binary.
    pub package_version: &'static str,
}

/// Returns build facts, currently hard-coded for a different target/profile.
#[must_use]
pub fn build_facts() -> BuildFacts {
    BuildFacts {
        os: "linux",
        arch: "x86_64",
        debug_assertions: true,
        package_version: env!("CARGO_PKG_VERSION"),
    }
}
