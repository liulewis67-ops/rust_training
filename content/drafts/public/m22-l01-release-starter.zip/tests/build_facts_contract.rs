use m22_l01_release::build_facts;

/// The binary reports its compiled operating system rather than a deployment guess.
#[test]
fn reports_actual_compile_target_os() {
    assert_eq!(build_facts().os, std::env::consts::OS);
}

/// The binary reports its compiled architecture rather than the builder host name.
#[test]
fn reports_actual_compile_target_architecture() {
    assert_eq!(build_facts().arch, std::env::consts::ARCH);
}

/// Debug and release test runners report their own profile's assertion setting.
#[test]
fn reports_active_profile_debug_assertions() {
    assert_eq!(build_facts().debug_assertions, cfg!(debug_assertions));
}

/// Build facts retain the manifest package version.
#[test]
fn reports_manifest_package_version() {
    assert_eq!(build_facts().package_version, env!("CARGO_PKG_VERSION"));
}
