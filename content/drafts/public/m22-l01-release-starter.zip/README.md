# M22-L01 release target starter

Run `cargo test --locked`, `cargo test --release --locked`, and `cargo build --release --locked` on Windows. The baseline intentionally reports the wrong build OS/architecture/profile facts. Use `cargo run --release --locked` after repair. This crate has no external dependencies. It does not build or run a container image, cross-compile Linux, or prove runtime-image compatibility.
