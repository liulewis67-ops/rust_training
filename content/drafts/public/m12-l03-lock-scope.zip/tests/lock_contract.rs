use lock_scope::set_default_if_empty;
use std::sync::{Arc, Mutex, RwLock, TryLockError};
use std::thread;

#[test]
fn multiple_readers_coexist_but_writer_waits_for_both() {
    let state = RwLock::new(10_u32);
    let reader_a = state.read().unwrap();
    let reader_b = state.read().unwrap();
    assert_eq!(*reader_a + *reader_b, 20);
    assert!(matches!(state.try_write(), Err(TryLockError::WouldBlock)));

    drop(reader_a);
    assert!(matches!(state.try_write(), Err(TryLockError::WouldBlock)));
    drop(reader_b);
    assert!(state.try_write().is_ok());
}

#[test]
fn mutex_becomes_available_as_soon_as_guard_is_dropped() {
    let count = Mutex::new(3);
    let guard = count.lock().unwrap();
    assert!(matches!(count.try_lock(), Err(TryLockError::WouldBlock)));
    drop(guard);
    assert!(count.try_lock().is_ok());
}

#[test]
fn default_initialization_is_idempotent_and_does_not_overwrite() {
    let state = RwLock::new(None);
    assert!(set_default_if_empty(&state, "first".to_owned()));
    assert!(!set_default_if_empty(&state, "second".to_owned()));
    assert_eq!(state.read().unwrap().as_deref(), Some("first"));
}

#[test]
fn competing_writers_install_only_one_default() {
    let state = Arc::new(RwLock::new(None));
    let workers = ["alpha", "beta"].map(|candidate| {
        let state = Arc::clone(&state);
        thread::spawn(move || set_default_if_empty(&state, candidate.to_owned()))
    });

    let installed = workers
        .into_iter()
        .map(|worker| worker.join().unwrap())
        .filter(|was_installed| *was_installed)
        .count();
    assert_eq!(installed, 1);
    assert!(
        state
            .read()
            .unwrap()
            .as_deref()
            .is_some_and(|value| value == "alpha" || value == "beta")
    );
}
