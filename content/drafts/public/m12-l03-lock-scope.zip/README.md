# Lock Scope

The `set_default_if_empty` operation scopes its read guard before asking for a write guard, then rechecks the condition under exclusive access. Tests use `try_write`/`try_lock` to reproduce held-guard conflicts without sleeping or blocking, and a competing-writer test verifies the value is installed exactly once.

Run `cargo fmt -- --check`, `cargo check --offline`, `cargo test --offline`, `cargo clippy --all-targets --offline -- -D warnings`, and `cargo doc --no-deps --offline`.
