//! Demonstrates reader/writer policy and short lock-guard scopes.

use std::sync::RwLock;

/// Sets a default value only when no other writer has already initialized it.
///
/// The initial shared read ends before the exclusive write is requested. The
/// state is checked again while holding the write guard to handle intervening
/// writers correctly.
///
/// # Panics
/// Panics if the lock is poisoned by a prior writer panic.
#[must_use = "check whether this call installed the default"]
pub fn set_default_if_empty(state: &RwLock<Option<String>>, candidate: String) -> bool {
    let was_empty = {
        let current = state.read().expect("state lock should not be poisoned");
        current.is_none()
    };
    if !was_empty {
        return false;
    }

    let mut current = state.write().expect("state lock should not be poisoned");
    if current.is_some() {
        return false;
    }

    *current = Some(candidate);
    true
}
