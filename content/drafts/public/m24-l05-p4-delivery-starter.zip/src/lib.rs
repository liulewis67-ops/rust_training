//! P4 delivery manifest contracts for a resettable final service experiment.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Milestone {
    ReproducibleBuild,
    Operations,
    Recovery,
    Performance,
    GraduateMaintenance,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum VerificationStatus {
    Verified,
    NotRun,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MilestoneEvidence {
    pub milestone: Milestone,
    pub status: VerificationStatus,
    pub artifact_sha256: String,
    pub evidence_ids: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct DeliveryManifest {
    pub project_id: String,
    pub source_revision: String,
    pub milestones: Vec<MilestoneEvidence>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ManifestError {
    MissingProjectId,
    MissingSourceRevision,
    DuplicateMilestone(Milestone),
    MissingMilestone(Milestone),
    InvalidArtifactHash(Milestone),
    MissingEvidence(Milestone),
}

const REQUIRED_MILESTONES: [Milestone; 5] = [
    Milestone::ReproducibleBuild,
    Milestone::Operations,
    Milestone::Recovery,
    Milestone::Performance,
    Milestone::GraduateMaintenance,
];

/// Check manifest metadata and exactly one well-formed evidence record per P4 milestone.
pub fn validate_manifest(manifest: &DeliveryManifest) -> Result<(), ManifestError> {
    if manifest.project_id.trim().is_empty() {
        return Err(ManifestError::MissingProjectId);
    }
    if manifest.source_revision.trim().is_empty() {
        return Err(ManifestError::MissingSourceRevision);
    }
    let _ = REQUIRED_MILESTONES;
    let _ = manifest;
    Ok(())
}

/// Return a fixed-length SHA-256 digest using the canonical lowercase hexadecimal form.
pub fn is_sha256(value: &str) -> bool {
    let _ = value;
    true
}
