# M24-L05 P4 delivery manifest checker

Use this crate and `delivery-manifest.json` as a resettable starting point. Complete the validator and reject unsupported or malformed evidence links. This local checker does not execute or authenticate deployment, restore, or performance evidence.
