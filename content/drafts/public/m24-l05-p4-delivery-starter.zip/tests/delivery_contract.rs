use m24_l05_p4_delivery_starter::{
    DeliveryManifest, ManifestError, Milestone, MilestoneEvidence, VerificationStatus,
    validate_manifest,
};

/// Construct complete evidence for one milestone.
fn evidence(milestone: Milestone, digit: char) -> MilestoneEvidence {
    MilestoneEvidence {
        milestone,
        status: VerificationStatus::Verified,
        artifact_sha256: format!("sha256:{}", digit.to_string().repeat(64)),
        evidence_ids: vec![format!("EVIDENCE-{digit}")],
    }
}

/// Return a complete P4 manifest with five unique milestones.
fn valid_manifest() -> DeliveryManifest {
    DeliveryManifest {
        project_id: "demo-task-service".into(),
        source_revision: "0123456789abcdef0123456789abcdef01234567".into(),
        milestones: vec![
            evidence(Milestone::ReproducibleBuild, 'a'),
            evidence(Milestone::Operations, 'b'),
            evidence(Milestone::Recovery, 'c'),
            evidence(Milestone::Performance, 'd'),
            evidence(Milestone::GraduateMaintenance, 'e'),
        ],
    }
}

/// Accept a complete evidence manifest.
#[test]
fn accepts_complete_manifest() {
    assert_eq!(validate_manifest(&valid_manifest()), Ok(()));
}

/// Reject a missing milestone instead of treating an absent item as passed.
#[test]
fn rejects_missing_milestone() {
    let mut manifest = valid_manifest();
    manifest.milestones.pop();
    assert_eq!(
        validate_manifest(&manifest),
        Err(ManifestError::MissingMilestone(
            Milestone::GraduateMaintenance
        ))
    );
}

/// Reject duplicate milestone entries.
#[test]
fn rejects_duplicate_milestones() {
    let mut manifest = valid_manifest();
    manifest.milestones[1] = manifest.milestones[0].clone();
    assert_eq!(
        validate_manifest(&manifest),
        Err(ManifestError::DuplicateMilestone(
            Milestone::ReproducibleBuild
        ))
    );
}

/// Reject malformed artifact hashes and empty evidence links.
#[test]
fn rejects_malformed_artifact_evidence() {
    let mut manifest = valid_manifest();
    manifest.milestones[0].artifact_sha256 = "best=12ms".into();
    assert_eq!(
        validate_manifest(&manifest),
        Err(ManifestError::InvalidArtifactHash(
            Milestone::ReproducibleBuild
        ))
    );
    manifest = valid_manifest();
    manifest.milestones[0].evidence_ids.clear();
    assert_eq!(
        validate_manifest(&manifest),
        Err(ManifestError::MissingEvidence(Milestone::ReproducibleBuild))
    );
}
