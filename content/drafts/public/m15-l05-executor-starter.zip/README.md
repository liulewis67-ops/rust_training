# M15-L05 P2 任务执行器起始包 v0.1.0

从原始 ZIP 解压到全新的临时目录，先记录包版本、Cargo.lock SHA-256 和源码快照 SHA-256。`starter-manifest.json` 固定公开输入；重置时重新解压原包，不复制已改过的目录或 `target/`。

起始实现故意有三个缺陷：每个 worker 创建自己的 semaphore；协作取消被记为成功；超时也被记为成功。四类失败终态和 bounded queue 结构已给出，要求修复缺陷而不是绕过公开 gate 测试。
