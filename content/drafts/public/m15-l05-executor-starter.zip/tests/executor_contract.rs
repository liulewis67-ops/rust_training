//! Controlled P2 executor acceptance checks.

use std::collections::BTreeMap;
use std::time::Duration;

use m15_l05_executor_lab::{Job, JobResult, Terminal, WorkFailure, start_executor};
use tokio::sync::oneshot;

/// Builds a job and keeps its work, cancellation and started gates in the test.
type GatedJob = (
    Job,
    oneshot::Sender<Result<(), WorkFailure>>,
    oneshot::Sender<()>,
    oneshot::Receiver<()>,
    oneshot::Receiver<()>,
);

fn gated_job(id: u8) -> GatedJob {
    let (work_tx, work) = oneshot::channel();
    let (cancel_tx, cancel) = oneshot::channel();
    let (started_tx, started) = oneshot::channel();
    let (dequeued_tx, dequeued) = oneshot::channel();
    (
        Job {
            id,
            work,
            cancel,
            dequeued: dequeued_tx,
            started: started_tx,
        },
        work_tx,
        cancel_tx,
        started,
        dequeued,
    )
}

/// Returns one observed terminal report per submitted job, regardless of order.
async fn collect_reports(
    mut results: tokio::sync::mpsc::Receiver<JobResult>,
    expected: usize,
) -> BTreeMap<u8, Terminal> {
    let mut reports = BTreeMap::new();
    for _ in 0..expected {
        let report = results
            .recv()
            .await
            .expect("accepted job has one terminal report");
        assert!(
            reports.insert(report.id, report.terminal).is_none(),
            "job report is unique"
        );
    }
    reports
}

/// Preserves queue backpressure, processes released work and drains on close.
#[tokio::test(flavor = "current_thread")]
async fn bounded_queue_returns_full_job_and_drains() {
    let (jobs, results, workers) = start_executor(1, 1, 1, Duration::from_secs(10));
    let (job_1, work_1, _cancel_1, started_1, _dequeued_1) = gated_job(1);
    let (job_2, work_2, _cancel_2, _started_2, _dequeued_2) = gated_job(2);
    let (job_3, _work_3, _cancel_3, _started_3, _dequeued_3) = gated_job(3);
    jobs.send(job_1).await.expect("first job enters executor");
    started_1.await.expect("first job holds active slot");
    jobs.try_send(job_2).expect("one waiting slot remains");
    let returned = jobs.try_send(job_3).expect_err("queue is full");
    let job_3 = match returned {
        tokio::sync::mpsc::error::TrySendError::Full(job) => job,
        tokio::sync::mpsc::error::TrySendError::Closed(_job) => panic!("executor is still open"),
    };
    assert_eq!(job_3.id, 3);
    assert!(work_1.send(Ok(())).is_ok());
    assert!(work_2.send(Ok(())).is_ok());
    drop(jobs);
    for worker in workers {
        worker.await.expect("worker exits after drain");
    }
    let reports = collect_reports(results, 2).await;
    assert_eq!(reports.get(&1), Some(&Terminal::Succeeded));
    assert_eq!(reports.get(&2), Some(&Terminal::Succeeded));
}

/// Requires all workers to share the configured active-job semaphore.
#[tokio::test(flavor = "current_thread")]
async fn shared_active_limit_delays_the_next_job() {
    let (jobs, results, workers) = start_executor(2, 2, 1, Duration::from_secs(10));
    let (job_1, work_1, _cancel_1, started_1, _dequeued_1) = gated_job(1);
    let (job_2, work_2, _cancel_2, mut started_2, dequeued_2) = gated_job(2);
    jobs.send(job_1).await.expect("first job accepted");
    jobs.send(job_2).await.expect("second job queued");
    started_1.await.expect("first job acquired the only permit");
    dequeued_2.await.expect("second worker took the queued job");
    assert!(
        started_2.try_recv().is_err(),
        "second worker waits for shared permit"
    );
    assert!(work_1.send(Ok(())).is_ok());
    started_2.await.expect("second job starts after release");
    assert!(work_2.send(Ok(())).is_ok());
    drop(jobs);
    for worker in workers {
        worker.await.expect("worker exits after drain");
    }
    let reports = collect_reports(results, 2).await;
    assert_eq!(reports.len(), 2);
    assert!(
        reports
            .values()
            .all(|outcome| *outcome == Terminal::Succeeded)
    );
}

/// Classifies cooperative cancellation, timeout and both failure classes.
#[tokio::test(start_paused = true)]
async fn every_failure_mode_has_one_distinct_terminal_result() {
    let (jobs, results, workers) = start_executor(4, 4, 4, Duration::from_secs(5));
    let (cancel_job, _cancel_work, cancel_tx, cancel_started, _cancel_dequeued) = gated_job(10);
    let (timeout_job, _timeout_work, _timeout_cancel, timeout_started, _timeout_dequeued) =
        gated_job(11);
    let (retry_job, retry_work, _retry_cancel, retry_started, _retry_dequeued) = gated_job(12);
    let (permanent_job, permanent_work, _permanent_cancel, permanent_started, _permanent_dequeued) =
        gated_job(13);
    jobs.send(cancel_job).await.expect("cancel job accepted");
    jobs.send(timeout_job).await.expect("timeout job accepted");
    jobs.send(retry_job).await.expect("retryable job accepted");
    jobs.send(permanent_job)
        .await
        .expect("permanent job accepted");
    cancel_started.await.expect("cancel job admitted");
    timeout_started.await.expect("timeout job admitted");
    retry_started.await.expect("retryable job admitted");
    permanent_started.await.expect("permanent job admitted");
    assert!(cancel_tx.send(()).is_ok());
    assert!(retry_work.send(Err(WorkFailure::Retryable)).is_ok());
    assert!(permanent_work.send(Err(WorkFailure::Permanent)).is_ok());
    drop(jobs);
    for worker in workers {
        worker.await.expect("worker exits after terminal reports");
    }
    let reports = collect_reports(results, 4).await;
    assert_eq!(reports.get(&10), Some(&Terminal::Cancelled));
    assert_eq!(reports.get(&11), Some(&Terminal::TimedOut));
    assert_eq!(reports.get(&12), Some(&Terminal::RetryableFailure));
    assert_eq!(reports.get(&13), Some(&Terminal::PermanentFailure));
}

/// Turns an open work gate into exactly one timed-out result on paused time.
#[tokio::test(start_paused = true)]
async fn timeout_is_not_reported_as_success() {
    let (jobs, mut results, workers) = start_executor(1, 1, 1, Duration::from_secs(5));
    let (job, _work, _cancel, started, _dequeued) = gated_job(20);
    jobs.send(job).await.expect("job accepted");
    started.await.expect("job entered active work");
    drop(jobs);
    for worker in workers {
        worker.await.expect("worker exits after deadline");
    }
    assert_eq!(
        results.recv().await.expect("one terminal report").terminal,
        Terminal::TimedOut
    );
    assert!(results.recv().await.is_none(), "terminal is emitted once");
}
