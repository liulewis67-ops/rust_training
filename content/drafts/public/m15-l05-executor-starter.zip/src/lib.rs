//! Starter crate for the M15 P2 task executor experiment.

use std::sync::Arc;
use std::time::Duration;

use tokio::sync::{Mutex, Semaphore, mpsc, oneshot};
use tokio::task::JoinHandle;
use tokio::time::{self, Instant};

/// Failure category returned by one controlled job attempt.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WorkFailure {
    /// A caller may schedule a bounded retry according to its policy.
    Retryable,
    /// Repeating the same operation without changing input is not useful.
    Permanent,
}

/// Terminal classification for an accepted job.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Terminal {
    /// The controlled operation returned success.
    Succeeded,
    /// The controlled operation returned a retryable failure.
    RetryableFailure,
    /// The controlled operation returned a permanent failure.
    PermanentFailure,
    /// The job received its cooperative cancellation signal.
    Cancelled,
    /// The job exceeded its fixed per-job deadline.
    TimedOut,
}

/// One job whose work and cancellation are controlled by the acceptance test.
pub struct Job {
    /// Stable identity preserved in the terminal report.
    pub id: u8,
    /// Completes when the simulated attempt succeeds or fails.
    pub work: oneshot::Receiver<Result<(), WorkFailure>>,
    /// Requests cooperative cancellation while waiting or running.
    pub cancel: oneshot::Receiver<()>,
    /// Announces that a worker has removed this job from the bounded queue.
    pub dequeued: oneshot::Sender<()>,
    /// Announces that a worker has admitted this job under the active limit.
    pub started: oneshot::Sender<()>,
}

/// One terminal report for an accepted job.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct JobResult {
    /// Original identity from the submitted job.
    pub id: u8,
    /// Exactly one terminal classification for this attempt.
    pub terminal: Terminal,
}

/// Starts a bounded fixed-worker executor with a shared active-task limit.
///
/// The caller must keep the result receiver alive while draining accepted jobs.
/// Capacities, worker count, active limit and timeout must all be nonzero.
pub fn start_executor(
    queue_capacity: usize,
    worker_count: usize,
    active_limit: usize,
    job_timeout: Duration,
) -> (
    mpsc::Sender<Job>,
    mpsc::Receiver<JobResult>,
    Vec<JoinHandle<()>>,
) {
    assert!(queue_capacity > 0, "queue capacity must be nonzero");
    assert!(worker_count > 0, "worker count must be nonzero");
    assert!(active_limit > 0, "active limit must be nonzero");
    assert!(!job_timeout.is_zero(), "job timeout must be nonzero");

    let (job_tx, job_rx) = mpsc::channel::<Job>(queue_capacity);
    let shared_rx = Arc::new(Mutex::new(job_rx));
    let active = Arc::new(Semaphore::new(active_limit));
    let result_capacity = queue_capacity.saturating_add(worker_count).max(1);
    let (result_tx, result_rx) = mpsc::channel::<JobResult>(result_capacity);
    let mut workers = Vec::with_capacity(worker_count);

    for _worker_id in 0..worker_count {
        let receiver = Arc::clone(&shared_rx);
        let permits = Arc::clone(&active);
        let results = result_tx.clone();
        workers.push(tokio::spawn(async move {
            loop {
                let next_job = {
                    let mut receiver = receiver.lock().await;
                    receiver.recv().await
                };
                let Some(mut job) = next_job else {
                    break;
                };
                let _ = job.dequeued.send(());
                let deadline = Instant::now() + job_timeout;

                // BUG: each worker has an independent semaphore, so the shared active limit is ignored.
                let local = Arc::new(Semaphore::new(active_limit));
                let permit = tokio::select! {
                    acquired = Arc::clone(&local).acquire_owned() => match acquired {
                        Ok(permit) => permit,
                        Err(_closed) => break,
                    },
                    _ = &mut job.cancel => {
                        if results.send(JobResult { id: job.id, terminal: Terminal::Cancelled }).await.is_err() { break; }
                        continue;
                    }
                    _ = time::sleep_until(deadline) => {
                        if results.send(JobResult { id: job.id, terminal: Terminal::TimedOut }).await.is_err() { break; }
                        continue;
                    }
                };
                let _ = job.started.send(());
                let terminal = tokio::select! {
                    result = &mut job.work => match result {
                        Ok(Ok(())) => Terminal::Succeeded,
                        Ok(Err(WorkFailure::Retryable)) => Terminal::RetryableFailure,
                        Ok(Err(WorkFailure::Permanent)) => Terminal::PermanentFailure,
                        Err(_closed) => Terminal::PermanentFailure,
                    },
                    _ = &mut job.cancel => Terminal::Succeeded, // BUG: cancellation is reported as success.
                    _ = time::sleep_until(deadline) => Terminal::Succeeded, // BUG: deadline is reported as success.
                };
                drop(permit);
                if results.send(JobResult { id: job.id, terminal }).await.is_err() {
                    break;
                }
                let _ = &permits;
            }
        }));
    }
    drop(result_tx);
    (job_tx, result_rx, workers)
}
