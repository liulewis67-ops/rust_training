use std::sync::mpsc::{TrySendError, sync_channel};
use std::sync::{Arc, Barrier, Mutex, TryLockError};
use std::thread;

use bounded_channel_lock_order::{add_pair_in_order, sum_through_bounded_channel};

#[test]
fn bounded_queue_exposes_full_and_reuses_returned_value_after_receive() {
    let (sender, receiver) = sync_channel(1);
    sender.try_send("first").unwrap();
    let pending = match sender.try_send("second") {
        Err(TrySendError::Full(value)) => value,
        other => panic!("expected a full queue, got {other:?}"),
    };

    assert_eq!(receiver.recv().unwrap(), "first");
    sender.try_send(pending).unwrap();
    assert_eq!(receiver.recv().unwrap(), "second");
}

#[test]
fn bounded_sum_handles_empty_many_and_rendezvous_inputs() {
    assert_eq!(sum_through_bounded_channel(Vec::new(), 1), Ok(0));
    assert_eq!(sum_through_bounded_channel(vec![9], 1), Ok(9));
    assert_eq!(sum_through_bounded_channel(vec![1, 2, 3, 4], 1), Ok(10));
    assert_eq!(sum_through_bounded_channel(vec![5, 6], 0), Ok(11));
    assert_eq!(
        sum_through_bounded_channel(vec![u32::MAX, 1], 1),
        Err("sum overflowed")
    );
}

#[test]
fn opposite_held_locks_are_observed_without_blocking() {
    let left = Arc::new(Mutex::new(()));
    let right = Arc::new(Mutex::new(()));
    let ready = Arc::new(Barrier::new(2));

    let left_first = {
        let (left, right, ready) = (Arc::clone(&left), Arc::clone(&right), Arc::clone(&ready));
        thread::spawn(move || {
            let left_guard = left.lock().unwrap();
            ready.wait();
            let blocked = matches!(right.try_lock(), Err(TryLockError::WouldBlock));
            ready.wait();
            drop(left_guard);
            blocked
        })
    };
    let right_first = {
        let (left, right, ready) = (Arc::clone(&left), Arc::clone(&right), Arc::clone(&ready));
        thread::spawn(move || {
            let right_guard = right.lock().unwrap();
            ready.wait();
            let blocked = matches!(left.try_lock(), Err(TryLockError::WouldBlock));
            ready.wait();
            drop(right_guard);
            blocked
        })
    };

    assert!(left_first.join().unwrap());
    assert!(right_first.join().unwrap());
}

#[test]
fn concurrent_updates_follow_one_global_lock_order() {
    let left = Arc::new(Mutex::new(0_u32));
    let right = Arc::new(Mutex::new(0_u32));
    let ready = Arc::new(Barrier::new(8));
    let workers = (0..8)
        .map(|_| {
            let (left, right, ready) = (Arc::clone(&left), Arc::clone(&right), Arc::clone(&ready));
            thread::spawn(move || {
                ready.wait();
                add_pair_in_order(&left, &right, 3);
            })
        })
        .collect::<Vec<_>>();

    for worker in workers {
        worker.join().unwrap();
    }
    assert_eq!(*left.lock().unwrap(), 24);
    assert_eq!(*right.lock().unwrap(), 24);
}
