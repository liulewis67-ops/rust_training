//! Demonstrates bounded message flow and a consistent order for paired locks.

use std::sync::Mutex;
use std::sync::mpsc::sync_channel;
use std::thread;

/// Sends every value through a bounded queue and returns the checked sum.
///
/// The producer owns the sender; the caller drains the receiver until the
/// sender is dropped. A capacity of zero exercises rendezvous behavior.
///
/// # Errors
/// Returns an error if a value cannot be sent, the producer panics, or the sum
/// overflows `u32`.
pub fn sum_through_bounded_channel(values: Vec<u32>, capacity: usize) -> Result<u32, &'static str> {
    let (sender, receiver) = sync_channel(capacity);
    let producer = thread::spawn(move || {
        for value in values {
            sender.send(value).map_err(|_| "receiver disconnected")?;
        }
        Ok::<(), &'static str>(())
    });

    let mut total = 0_u32;
    let mut overflowed = false;
    for value in receiver {
        match total.checked_add(value) {
            Some(next) => total = next,
            None => overflowed = true,
        }
    }

    producer.join().map_err(|_| "producer panicked")??;
    if overflowed {
        Err("sum overflowed")
    } else {
        Ok(total)
    }
}

/// Adds the same amount to two mutex-protected counters in a fixed order.
///
/// Every path that needs both locks must use this API's left-then-right order.
///
/// # Panics
/// Panics if either mutex is poisoned.
pub fn add_pair_in_order(left: &Mutex<u32>, right: &Mutex<u32>, amount: u32) {
    let mut left_value = left.lock().expect("left counter should not be poisoned");
    let mut right_value = right.lock().expect("right counter should not be poisoned");
    *left_value += amount;
    *right_value += amount;
}
