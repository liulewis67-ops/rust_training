# M12-L04 bounded channel and lock order sample

Rust 2024, standard library only. The library sums values through a bounded
`sync_channel`, including capacity zero, and exposes a paired-counter helper
whose contract fixes lock acquisition to left then right.

The integration tests deterministically fill a one-slot queue with `try_send`,
observe opposite lock pressure with a `Barrier` and `try_lock`, and verify
concurrent use of the consistent-order helper. They never create a blocking
deadlock and do not use sleep-based scheduling assumptions.

Run with `cargo fmt -- --check`, `cargo test --locked --offline`,
`cargo clippy --all-targets --locked --offline -- -D warnings`, and
`cargo doc --no-deps --locked --offline`.
