# M24-L01 business acceptance starter

Implement the missing validation rules and trace-row builder using the contracts in the associated exercise sheet. This crate validates the shape and trace links of acceptance criteria; it does not decide business policy or invent requirement evidence.
