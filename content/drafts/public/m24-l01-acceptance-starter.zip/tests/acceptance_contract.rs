use m24_l01_acceptance_starter::{
    AcceptanceCriterion, CriterionError, TraceRow, build_trace_rows, validate_criterion,
};

/// Build one complete business acceptance criterion with explicit evidence IDs.
fn valid_criterion() -> AcceptanceCriterion {
    AcceptanceCriterion {
        requirement_id: "REQ-17".into(),
        scenario_id: "SCN-17-A".into(),
        given: "the actor owns project P".into(),
        when: "they request the January report".into(),
        then: "only January tasks from P are present".into(),
        evidence_ids: vec!["API-17".into(), "TEST-17".into()],
    }
}

/// Preserve a valid criterion without inventing or deleting evidence.
#[test]
fn accepts_complete_criterion() {
    assert_eq!(validate_criterion(&valid_criterion()), Ok(()));
}

/// Require an observable Then outcome rather than an implementation detail omission.
#[test]
fn rejects_missing_then_outcome() {
    let mut criterion = valid_criterion();
    criterion.then = "   ".into();
    assert_eq!(
        validate_criterion(&criterion),
        Err(CriterionError::MissingThen)
    );
}

/// Require trace evidence instead of generating a placeholder test link.
#[test]
fn rejects_missing_evidence() {
    let mut criterion = valid_criterion();
    criterion.evidence_ids.clear();
    assert_eq!(
        validate_criterion(&criterion),
        Err(CriterionError::MissingEvidence)
    );
}

/// Reject evidence IDs that contain only whitespace.
#[test]
fn rejects_blank_evidence_id() {
    let mut criterion = valid_criterion();
    criterion.evidence_ids = vec!["   ".into()];
    assert_eq!(
        validate_criterion(&criterion),
        Err(CriterionError::MissingEvidence)
    );
}

/// Preserve criterion order and evidence order when building the trace matrix.
#[test]
fn builds_trace_rows_in_input_order() {
    let first = valid_criterion();
    let mut second = valid_criterion();
    second.requirement_id = "REQ-18".into();
    second.scenario_id = "SCN-18-A".into();
    assert_eq!(
        build_trace_rows(&[first, second]).unwrap(),
        vec![
            TraceRow {
                requirement_id: "REQ-17".into(),
                scenario_id: "SCN-17-A".into(),
                evidence_ids: vec!["API-17".into(), "TEST-17".into()],
            },
            TraceRow {
                requirement_id: "REQ-18".into(),
                scenario_id: "SCN-18-A".into(),
                evidence_ids: vec!["API-17".into(), "TEST-17".into()],
            },
        ]
    );
}

/// Reject duplicate requirement IDs and keep empty input valid.
#[test]
fn rejects_duplicate_requirement_ids_and_accepts_empty_input() {
    let criterion = valid_criterion();
    assert_eq!(build_trace_rows(&[]), Ok(Vec::new()));
    assert_eq!(
        build_trace_rows(&[criterion.clone(), criterion]),
        Err(CriterionError::DuplicateRequirementId)
    );
}
