//! Business acceptance criteria and traceability contracts for M24-L01.

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct AcceptanceCriterion {
    pub requirement_id: String,
    pub scenario_id: String,
    pub given: String,
    pub when: String,
    pub then: String,
    pub evidence_ids: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum CriterionError {
    MissingRequirementId,
    MissingScenarioId,
    MissingGiven,
    MissingWhen,
    MissingThen,
    MissingEvidence,
    DuplicateRequirementId,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct TraceRow {
    pub requirement_id: String,
    pub scenario_id: String,
    pub evidence_ids: Vec<String>,
}

/// Validate that one criterion has an observable scenario and trace evidence.
pub fn validate_criterion(criterion: &AcceptanceCriterion) -> Result<(), CriterionError> {
    if criterion.requirement_id.trim().is_empty() {
        return Err(CriterionError::MissingRequirementId);
    }
    if criterion.scenario_id.trim().is_empty() {
        return Err(CriterionError::MissingScenarioId);
    }
    if criterion.given.trim().is_empty() {
        return Err(CriterionError::MissingGiven);
    }
    if criterion.when.trim().is_empty() {
        return Err(CriterionError::MissingWhen);
    }
    if criterion.evidence_ids.is_empty() {
        return Err(CriterionError::MissingEvidence);
    }
    Ok(())
}

/// Build ordered requirement-to-scenario-to-evidence rows after validating all input.
pub fn build_trace_rows(criteria: &[AcceptanceCriterion]) -> Result<Vec<TraceRow>, CriterionError> {
    let _ = criteria;
    Ok(Vec::new())
}
