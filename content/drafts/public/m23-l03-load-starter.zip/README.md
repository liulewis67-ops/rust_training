# M23-L03 throughput and tail-latency starter

The starter summarizes one fixed request timeline. The intended repair is to calculate end-to-end latency from offer time rather than service-start time. Add the missing overload regression described in the associated M23-L03 exercise sheet without changing the summarizer's result contract.

No public test requires an external service, container, or benchmark runner.
