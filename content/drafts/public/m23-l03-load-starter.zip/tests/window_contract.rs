use m23_l03_load_starter::{RequestSample, SummaryError, summarize_window};

/// Return two overlapping completed requests plus one request still queued.
fn fixture() -> [RequestSample; 3] {
    [
        RequestSample {
            offered_ms: 0,
            started_ms: Some(0),
            completed_ms: Some(100),
        },
        RequestSample {
            offered_ms: 0,
            started_ms: Some(80),
            completed_ms: Some(110),
        },
        RequestSample {
            offered_ms: 900,
            started_ms: None,
            completed_ms: None,
        },
    ]
}

/// Keep offered, completed, and pending counts separate in the report.
#[test]
fn counts_offered_completed_and_pending_separately() {
    let summary = summarize_window(&fixture(), 1_000).unwrap();
    assert_eq!(summary.offered_count, 3);
    assert_eq!(summary.completed_count, 2);
    assert_eq!(summary.pending_count, 1);
    assert_eq!(summary.throughput_per_second, 2.0);
}

/// Require queue wait to contribute to the end-to-end p95.
#[test]
fn p95_includes_time_spent_waiting_before_service_starts() {
    let summary = summarize_window(&fixture(), 1_000).unwrap();
    assert_eq!(summary.p95_end_to_end_ms, Some(110));
}

/// Count overlapping service intervals as concurrent in-flight work.
#[test]
fn peak_in_flight_counts_overlapping_started_requests() {
    let summary = summarize_window(&fixture(), 1_000).unwrap();
    assert_eq!(summary.peak_in_flight, 2);
}

/// Reject a zero-length measurement window rather than inventing a rate.
#[test]
fn rejects_an_empty_measurement_window() {
    assert_eq!(
        summarize_window(&fixture(), 0),
        Err(SummaryError::EmptyWindow)
    );
}
