//! Fixed-window load summary contracts for the M23-L03 lesson.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RequestSample {
    pub offered_ms: u64,
    pub started_ms: Option<u64>,
    pub completed_ms: Option<u64>,
}

#[derive(Clone, Debug, PartialEq)]
pub struct WindowSummary {
    pub offered_count: usize,
    pub completed_count: usize,
    pub pending_count: usize,
    pub throughput_per_second: f64,
    pub p95_end_to_end_ms: Option<u64>,
    pub peak_in_flight: usize,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SummaryError {
    EmptyWindow,
    InvalidTimeline,
}

/// Summarize a fixed window while keeping offered, completed, and pending work distinct.
pub fn summarize_window(
    samples: &[RequestSample],
    window_ms: u64,
) -> Result<WindowSummary, SummaryError> {
    if window_ms == 0 {
        return Err(SummaryError::EmptyWindow);
    }

    let mut latencies = Vec::new();
    let mut events = Vec::new();
    let mut completed_count = 0;
    let mut pending_count = 0;

    for sample in samples {
        if sample.offered_ms > window_ms {
            return Err(SummaryError::InvalidTimeline);
        }
        if let Some(started_ms) = sample.started_ms {
            if started_ms < sample.offered_ms || started_ms >= window_ms {
                return Err(SummaryError::InvalidTimeline);
            }
            events.push((started_ms, 1_i8));
            if let Some(completed_ms) = sample.completed_ms {
                if completed_ms <= started_ms || completed_ms > window_ms {
                    return Err(SummaryError::InvalidTimeline);
                }
                events.push((completed_ms, -1_i8));
                latencies.push(completed_ms - started_ms);
                completed_count += 1;
            } else {
                events.push((window_ms, -1_i8));
                pending_count += 1;
            }
        } else if sample.completed_ms.is_some() {
            return Err(SummaryError::InvalidTimeline);
        } else {
            pending_count += 1;
        }
    }

    events.sort_unstable();
    let mut in_flight = 0_usize;
    let mut peak_in_flight = 0_usize;
    for (_, delta) in events {
        if delta < 0 {
            in_flight -= 1;
        } else {
            in_flight += 1;
            peak_in_flight = peak_in_flight.max(in_flight);
        }
    }

    latencies.sort_unstable();
    let p95_end_to_end_ms = if latencies.is_empty() {
        None
    } else {
        let rank = (95 * latencies.len()).div_ceil(100);
        Some(latencies[rank - 1])
    };

    Ok(WindowSummary {
        offered_count: samples.len(),
        completed_count,
        pending_count,
        throughput_per_second: completed_count as f64 * 1_000.0 / window_ms as f64,
        p95_end_to_end_ms,
        peak_in_flight,
    })
}
