use std::thread;
use thread_outcomes::{doubled_in_worker, measure, run_job};

#[test]
fn joins_owned_worker_return_value() {
    assert_eq!(
        run_job("猫".to_owned(), false).expect("worker should return"),
        ("猫".to_owned(), 3)
    );
}

#[test]
fn join_reports_worker_panic_without_panicking_the_caller() {
    let outcome = run_job("ignored".to_owned(), true);
    let payload = outcome.expect_err("worker panic should be returned");
    assert!(payload.is::<&'static str>());
}

#[test]
fn worker_owns_a_copy_while_caller_keeps_the_borrowed_input() {
    let label = String::from("compile");
    assert_eq!(measure(&label).expect("worker should finish"), 7);
    assert_eq!(label, "compile");
}

#[test]
fn copy_capture_leaves_original_integer_available() {
    let value = 21_usize;
    let worker = doubled_in_worker(value);
    assert_eq!(value, 21);
    assert_eq!(worker.join().expect("worker should finish"), 42);
}

#[test]
fn worker_panic_result_has_the_standard_thread_result_type() {
    let outcome: thread::Result<(String, usize)> = run_job("x".to_owned(), true);
    assert!(outcome.is_err());
}
