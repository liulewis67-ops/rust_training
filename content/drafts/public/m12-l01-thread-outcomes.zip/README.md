# Thread Outcomes

This crate shows `JoinHandle<T>` returning both a worker value and `thread::Result<T>` when the worker panics. It demonstrates owned `move` captures, a Copy capture that leaves the caller's integer usable, and cloning borrowed string data only when both caller and worker need it.

No test depends on scheduler order or sleep timing. The compile-fail doctests show a borrowed local failing the normal `thread::spawn` lifetime requirement and a moved String no longer being available to its caller.

Run `cargo fmt -- --check`, `cargo check --offline`, `cargo test --offline`, `cargo clippy --all-targets --offline -- -D warnings`, and `cargo doc --no-deps --offline`.
