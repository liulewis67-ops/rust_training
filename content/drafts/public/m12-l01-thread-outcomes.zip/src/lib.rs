//! Demonstrates owned worker captures and explicit thread outcomes.
//!
//! A normal thread cannot retain a borrow of a local String:
//!
//! ```compile_fail
//! use std::thread;
//!
//! let label = String::from("build");
//! thread::spawn(|| label.len()).join().unwrap();
//! ```
//!
//! Moving a non-Copy String into the closure transfers it:
//!
//! ```compile_fail
//! use std::thread;
//!
//! let label = String::from("build");
//! let handle = thread::spawn(move || label.len());
//! println!("{label}");
//! handle.join().unwrap();
//! ```

use std::thread::{self, JoinHandle};

/// Runs a job and returns either its value or the worker's panic payload.
///
/// # Errors
/// Returns the worker's panic payload when `should_panic` is true.
///
/// # Panics
/// Panics if the operating system cannot create the thread.
pub fn run_job(input: String, should_panic: bool) -> thread::Result<(String, usize)> {
    thread::spawn(move || {
        assert!(!should_panic, "simulated worker failure");

        let byte_len = input.len();
        (input, byte_len)
    })
    .join()
}

/// Measures a borrowed label by moving an owned copy into the worker.
///
/// # Errors
/// Returns the worker's panic payload if the worker panics.
///
/// # Panics
/// Panics if the operating system cannot create the thread.
pub fn measure(label: &str) -> thread::Result<usize> {
    let worker_label = label.to_owned();
    thread::spawn(move || worker_label.len()).join()
}

/// Spawns a worker whose Copy capture leaves the caller's integer usable.
#[must_use]
pub fn doubled_in_worker(value: usize) -> JoinHandle<usize> {
    thread::spawn(move || value * 2)
}
