use std::sync::{Arc, Barrier};
use std::thread;

use quota_lock_scope_check::Registry;

fn run_fixed_probe() -> (Result<u64, &'static str>, bool, u64) {
    let registry = Arc::new(Registry::new());
    registry.set("gold", 10);
    let entered_transform = Arc::new(Barrier::new(2));
    let continue_transform = Arc::new(Barrier::new(2));

    let worker = {
        let registry = Arc::clone(&registry);
        let entered_transform = Arc::clone(&entered_transform);
        let continue_transform = Arc::clone(&continue_transform);
        thread::spawn(move || {
            registry.quote_with("gold", |snapshot| {
                entered_transform.wait();
                continue_transform.wait();
                snapshot * 3
            })
        })
    };

    entered_transform.wait();
    let update_was_available = registry.set_if_lock_available("gold", 11) == Ok(true);
    continue_transform.wait();
    let quote = worker.join().expect("quote worker should finish");
    let current_value = registry.read("gold").expect("updated quota should exist");
    (quote, update_was_available, current_value)
}

#[test]
fn same_load_keeps_quote_result_but_releases_registry_during_transform() {
    let (quote, update_was_available, current_value) = run_fixed_probe();

    assert_eq!(quote, Ok(30));
    assert!(
        update_was_available,
        "update_available={update_was_available}, quote={quote:?}, current_value={current_value}"
    );
    assert_eq!(current_value, 11, "the competing update should complete");
}

#[test]
fn missing_key_remains_an_error() {
    let registry = Registry::new();
    assert_eq!(
        registry.quote_with("unknown", |value| value * 3),
        Err("missing quota")
    );
}

#[test]
fn short_lookup_and_update_operations_remain_available() {
    let registry = Registry::new();
    registry.set("silver", 7);
    assert_eq!(registry.quote_with("silver", |value| value + 2), Ok(9));
    registry.set("silver", 12);
    assert_eq!(registry.quote_with("silver", |value| value + 2), Ok(14));
}
