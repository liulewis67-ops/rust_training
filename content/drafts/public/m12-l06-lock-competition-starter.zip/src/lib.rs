//! Starter for inspecting lock scope in a shared quota table.

use std::collections::HashMap;
use std::sync::{Mutex, TryLockError};

/// Registry shared by concurrent quote requests.
#[derive(Debug, Default)]
pub struct Registry {
    values: Mutex<HashMap<String, u64>>,
}

impl Registry {
    /// Creates an empty quota registry.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Inserts or replaces a named quota.
    ///
    /// # Panics
    /// Panics if a prior thread panicked while holding the registry lock.
    pub fn set(&self, key: impl Into<String>, value: u64) {
        self.values
            .lock()
            .expect("quota registry should not be poisoned")
            .insert(key.into(), value);
    }

    /// Attempts to replace a value without waiting for another lock holder.
    ///
    /// # Errors
    /// Returns an error if the registry lock is poisoned.
    pub fn set_if_lock_available(&self, key: &str, value: u64) -> Result<bool, &'static str> {
        match self.values.try_lock() {
            Ok(mut values) => {
                values.insert(key.to_owned(), value);
                Ok(true)
            }
            Err(TryLockError::WouldBlock) => Ok(false),
            Err(TryLockError::Poisoned(_)) => Err("quota registry is poisoned"),
        }
    }

    /// Reads a named quota after acquiring the registry lock.
    ///
    /// # Panics
    /// Panics if a prior thread panicked while holding the registry lock.
    #[must_use]
    pub fn read(&self, key: &str) -> Option<u64> {
        self.values
            .lock()
            .expect("quota registry should not be poisoned")
            .get(key)
            .copied()
    }

    /// Reads a quota and applies a caller-supplied transformation.
    ///
    /// # Errors
    /// Returns `missing quota` when key is absent.
    ///
    /// # Panics
    /// Panics if a prior thread panicked while holding the registry lock.
    pub fn quote_with<F>(&self, key: &str, transform: F) -> Result<u64, &'static str>
    where
        F: FnOnce(u64) -> u64,
    {
        let values = self
            .values
            .lock()
            .expect("quota registry should not be poisoned");
        let snapshot = values.get(key).copied().ok_or("missing quota")?;

        // Intentionally flawed: arbitrary work runs while the registry is locked.
        Ok(transform(snapshot))
    }
}
