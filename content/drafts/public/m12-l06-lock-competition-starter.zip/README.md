# M12-L06 lock competition check

Rust 2024, standard library only. Read the independent-check prompt first.
The starter intentionally calls a user transform while holding the shared
quota-table Mutex. The public contention probe uses barriers and `try_lock`;
it has no sleeps and always releases the worker, so the expected failure does
not hang the test process.

## Reset and commands

Extract the original ZIP into a new directory, verify every path in
`starter-manifest.json`, then run:

```text
cargo fmt -- --check
cargo check --locked --offline
cargo test --locked --offline
cargo clippy --all-targets --locked --offline -- -D warnings
cargo doc --no-deps --locked --offline
```

The baseline compiles; the lock-availability assertion in
`same_load_keeps_quote_result_but_releases_registry_during_transform` is
expected to fail. Repair the lock scope without changing the quote result.
