# M08-L06 所有权与统计独立检查

Edition 2024、无第三方依赖。该检查使用陌生于实验题的传感器读数需求，限定借用输入切片的接口；先只看题面并独立提交，再查看任何参考实现。

运行起始公开契约：

```text
cargo test --offline
```

起始函数返回空 Vec，非空契约断言会失败。实现后运行：

```text
cargo fmt -- --check
cargo check --offline
cargo test --offline
```

重置时从 `content/drafts/public/m08-l06-ownership-statistics-check.zip` 解压到全新目录，并按 `starter-manifest.json` 核对原始项目文件 SHA-256。保留原始解压副本作起始快照；只在另一个副本中作答。不得先打开教师参考或私有验收材料。

本地验证可把构建产物放在项目外：

```powershell
$env:CARGO_TARGET_DIR = Join-Path $env:TEMP 'm08-l06-cargo-target'
cargo test --offline
```

本地编译/测试不代表平台独立提交、隐藏验收或技能档案已通过。平台运行故障必须记录为环境问题，不计作学习者能力失败。
