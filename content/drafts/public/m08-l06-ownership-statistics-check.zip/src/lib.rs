/// One sensor reading, including whether the reading passed acceptance rules.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Reading<'a> {
    /// Identifies the sensor that produced this reading.
    pub sensor: &'a str,
    /// Stores the optional value; `Some(0)` is a real reading.
    pub value: Option<i32>,
    /// Indicates whether the value is eligible for the total.
    pub accepted: bool,
}

/// Summarizes accepted readings for one sensor.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SensorSummary<'a> {
    /// Borrows the sensor name from an input reading.
    pub sensor: &'a str,
    /// Counts accepted readings that contain a value.
    pub accepted_count: usize,
    /// Sums accepted values, using zero when none are present.
    pub total: i64,
}

/// Summarizes readings while borrowing sensor names from the input slice.
pub fn summarize<'a>(_readings: &[Reading<'a>]) -> Vec<SensorSummary<'a>> {
    // TODO: Create one row per sensor, aggregate eligible values, and sort rows.
    Vec::new()
}
