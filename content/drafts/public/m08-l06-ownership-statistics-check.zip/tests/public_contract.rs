use m08_l06_ownership_statistics_check::{Reading, SensorSummary, summarize};

/// Ensures empty input returns an empty result.
#[test]
fn empty_input_has_no_sensor_rows() {
    assert!(summarize(&[]).is_empty());
}

/// Ensures accepted readings accumulate and a sensor with no accepted values remains visible.
#[test]
fn duplicate_sensors_accumulate_without_dropping_empty_groups() {
    let readings = [
        Reading {
            sensor: "api",
            value: Some(4),
            accepted: true,
        },
        Reading {
            sensor: "cache",
            value: Some(9),
            accepted: false,
        },
        Reading {
            sensor: "api",
            value: Some(0),
            accepted: true,
        },
        Reading {
            sensor: "api",
            value: None,
            accepted: true,
        },
    ];

    assert_eq!(
        summarize(&readings),
        vec![
            SensorSummary {
                sensor: "api",
                accepted_count: 2,
                total: 4,
            },
            SensorSummary {
                sensor: "cache",
                accepted_count: 0,
                total: 0,
            },
        ]
    );
}

/// Ensures Unicode names are preserved and summaries use the specified order.
#[test]
fn unicode_sensor_names_are_sorted_lexicographically() {
    let readings = [
        Reading {
            sensor: "网关",
            value: Some(-2),
            accepted: true,
        },
        Reading {
            sensor: "缓存",
            value: Some(5),
            accepted: true,
        },
        Reading {
            sensor: "api",
            value: Some(3),
            accepted: true,
        },
    ];

    let summaries = summarize(&readings);
    assert_eq!(
        summaries
            .iter()
            .map(|summary| summary.sensor)
            .collect::<Vec<_>>(),
        vec!["api", "缓存", "网关"]
    );
    assert_eq!(summaries[2].total, -2);
}

/// Ensures aggregation borrows input names and does not change its readings.
#[test]
fn input_remains_available_after_summarizing() {
    let readings = [Reading {
        sensor: "worker",
        value: Some(6),
        accepted: true,
    }];

    let _summary = summarize(&readings);
    assert_eq!(readings[0].sensor, "worker");
    assert_eq!(readings[0].value, Some(6));
}

/// Ensures the output can borrow a name owned by the caller rather than requiring a static string.
#[test]
fn output_borrows_non_static_sensor_names() {
    let sensor = String::from("动态传感器");
    let readings = [Reading {
        sensor: sensor.as_str(),
        value: Some(11),
        accepted: true,
    }];

    let summaries = summarize(&readings);
    assert_eq!(summaries[0].sensor, sensor);
    assert_eq!(readings[0].sensor, sensor);
}
