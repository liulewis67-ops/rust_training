//! Request-level acceptance tests for the M16-L05 in-memory API lab.

use axum::body::{Body, to_bytes};
use axum::http::{Method, Request, StatusCode};
use m16_l05_task_api::app;
use tower::ServiceExt;

/// Sends one full request through the in-memory task router.
async fn send(
    router: &axum::Router,
    method: Method,
    uri: &str,
    body: Body,
) -> axum::response::Response {
    router
        .clone()
        .oneshot(
            Request::builder()
                .method(method)
                .uri(uri)
                .header("content-type", "application/json")
                .body(body)
                .unwrap(),
        )
        .await
        .unwrap()
}

/// Reads one small JSON response.
async fn json(response: axum::response::Response) -> serde_json::Value {
    let bytes = to_bytes(response.into_body(), usize::MAX).await.unwrap();
    serde_json::from_slice(&bytes).unwrap()
}

/// Creates distinct resources and reads the second one back.
#[tokio::test]
async fn creates_allocate_unique_ids_and_read_back() {
    let router = app();
    let first = send(
        &router,
        Method::POST,
        "/tasks",
        Body::from(r#"{"title":"first"}"#),
    )
    .await;
    assert_eq!(first.status(), StatusCode::CREATED);
    assert_eq!(json(first).await["id"], 43);

    let second = send(
        &router,
        Method::POST,
        "/tasks",
        Body::from(r#"{"title":"second"}"#),
    )
    .await;
    assert_eq!(second.status(), StatusCode::CREATED);
    assert_eq!(json(second).await["id"], 44);

    let read_back = send(&router, Method::GET, "/tasks/44", Body::empty()).await;
    assert_eq!(read_back.status(), StatusCode::OK);
    assert_eq!(json(read_back).await["title"], "second");
}

/// Replaces an existing task and deletes it with a no-content response.
#[tokio::test]
async fn update_delete_and_missing_resource_contract() {
    let router = app();
    let created = send(
        &router,
        Method::POST,
        "/tasks",
        Body::from(r#"{"title":"before"}"#),
    )
    .await;
    let id = json(created).await["id"].as_u64().unwrap();

    let updated = send(
        &router,
        Method::PUT,
        &format!("/tasks/{id}"),
        Body::from(r#"{"title":"after"}"#),
    )
    .await;
    assert_eq!(updated.status(), StatusCode::OK);
    assert_eq!(json(updated).await["title"], "after");

    let deleted = send(
        &router,
        Method::DELETE,
        &format!("/tasks/{id}"),
        Body::empty(),
    )
    .await;
    assert_eq!(deleted.status(), StatusCode::NO_CONTENT);
    assert!(
        to_bytes(deleted.into_body(), usize::MAX)
            .await
            .unwrap()
            .is_empty()
    );
    assert_eq!(
        send(&router, Method::GET, &format!("/tasks/{id}"), Body::empty())
            .await
            .status(),
        StatusCode::NOT_FOUND
    );
}

/// Rejects invalid fields and unsupported methods without crashing the router.
#[tokio::test]
async fn invalid_title_and_method_mismatch_are_explicit() {
    let router = app();
    let invalid = send(
        &router,
        Method::POST,
        "/tasks",
        Body::from(r#"{"title":"  "}"#),
    )
    .await;
    assert_eq!(invalid.status(), StatusCode::UNPROCESSABLE_ENTITY);

    let unsupported = send(&router, Method::PATCH, "/tasks/43", Body::empty()).await;
    assert_eq!(unsupported.status(), StatusCode::METHOD_NOT_ALLOWED);
    assert!(unsupported.headers().contains_key("allow"));
}
