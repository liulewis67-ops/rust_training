//! Public starter for the M16-L05 in-memory task API lab.

use std::collections::BTreeMap;
use std::sync::{Arc, RwLock};

use axum::extract::{Json, Path, State};
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::routing::get;
use axum::{Router, http::Response};
use serde::{Deserialize, Serialize};

/// A task returned by the API.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct Task {
    /// Stable identifier allocated by the API.
    pub id: u64,
    /// Human-readable task title.
    pub title: String,
}

/// Fields accepted when creating or replacing a task.
#[derive(Debug, Deserialize)]
pub struct TaskInput {
    /// Required non-whitespace title.
    pub title: String,
}

/// In-memory state shared by route handlers.
#[derive(Clone, Default)]
pub struct AppState {
    /// Tasks indexed by their public identifiers.
    tasks: Arc<RwLock<BTreeMap<u64, Task>>>,
}

/// Builds a fresh task API with predictable initial state.
pub fn app() -> Router {
    let state = AppState::default();
    Router::new()
        .route("/tasks", get(list_tasks).post(create_task))
        .route(
            "/tasks/{id}",
            get(show_task).put(replace_task).delete(delete_task),
        )
        .with_state(state)
}

/// Returns all tasks sorted by their stable identifiers.
async fn list_tasks(State(state): State<AppState>) -> Json<Vec<Task>> {
    let tasks = state.tasks.read().expect("task store lock poisoned");
    Json(tasks.values().cloned().collect())
}

/// Creates a task in the in-memory store.
async fn create_task(
    State(state): State<AppState>,
    Json(input): Json<TaskInput>,
) -> Response<axum::body::Body> {
    if input.title.trim().is_empty() {
        return (StatusCode::UNPROCESSABLE_ENTITY, "title must not be empty").into_response();
    }
    let mut tasks = state.tasks.write().expect("task store lock poisoned");
    // BUG: Every create reuses the same identifier and overwrites the previous task.
    let id = 43;
    let task = Task {
        id,
        title: input.title,
    };
    tasks.insert(id, task.clone());
    (StatusCode::CREATED, Json(task)).into_response()
}

/// Returns one task or 404 when the identifier does not exist.
async fn show_task(
    Path(id): Path<u64>,
    State(state): State<AppState>,
) -> Result<Json<Task>, StatusCode> {
    state
        .tasks
        .read()
        .expect("task store lock poisoned")
        .get(&id)
        .cloned()
        .map(Json)
        .ok_or(StatusCode::NOT_FOUND)
}

/// Replaces the complete representation of an existing task.
async fn replace_task(
    Path(id): Path<u64>,
    State(state): State<AppState>,
    Json(input): Json<TaskInput>,
) -> Result<Json<Task>, StatusCode> {
    if input.title.trim().is_empty() {
        return Err(StatusCode::UNPROCESSABLE_ENTITY);
    }
    let mut tasks = state.tasks.write().expect("task store lock poisoned");
    let task = tasks.get_mut(&id).ok_or(StatusCode::NOT_FOUND)?;
    task.title = input.title;
    Ok(Json(task.clone()))
}

/// Deletes one task and returns no content on success.
async fn delete_task(Path(id): Path<u64>, State(state): State<AppState>) -> StatusCode {
    if state
        .tasks
        .write()
        .expect("task store lock poisoned")
        .remove(&id)
        .is_some()
    {
        StatusCode::NO_CONTENT
    } else {
        StatusCode::NOT_FOUND
    }
}
