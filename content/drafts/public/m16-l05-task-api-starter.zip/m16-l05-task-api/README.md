# M16-L05 P3.1 In-memory task API starter

This public starter uses Axum 0.8.9 and contains one deliberate CRUD defect: create overwrites the task at ID 43 rather than allocating the next available ID. Fix the implementation using the supplied request tests.

Run `cargo test` from this directory. Read `m16-l05-task-api-lab.md` for the contract and reset workflow. `starter-manifest.json` pins starter file hashes; `m16-l05-task-api-starter.zip` is the versioned reset snapshot.
