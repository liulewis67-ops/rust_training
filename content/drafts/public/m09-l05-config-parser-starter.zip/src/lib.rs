use std::error::Error;
use std::fmt;

/// A validated runtime configuration parsed from a small key-value document.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Config {
    /// Sets the request timeout in milliseconds.
    pub timeout_ms: u64,
    /// Sets the maximum number of retry attempts.
    pub retry_limit: u8,
}

/// Identifies a configuration failure without storing or echoing raw values.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ConfigError {
    /// A non-empty line has no key/value separator.
    MissingSeparator { line: usize, column: usize },
    /// A field name is not part of this configuration contract.
    UnknownField { line: usize, column: usize },
    /// A required field appears more than once.
    DuplicateField {
        field: &'static str,
        line: usize,
        column: usize,
    },
    /// A field value is empty, not decimal, or outside its integer range.
    InvalidValue {
        field: &'static str,
        line: usize,
        column: usize,
    },
    /// A required field was not supplied before end of input.
    MissingField {
        field: &'static str,
        line: usize,
        column: usize,
    },
}

/// Formats a stable diagnostic category and source position for the parser.
impl fmt::Display for ConfigError {
    /// Writes the category and one-based line/Unicode-scalar column.
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::MissingSeparator { line, column } => {
                write!(formatter, "expected '=' at {line}:{column}")
            }
            Self::UnknownField { line, column } => {
                write!(formatter, "unknown field at {line}:{column}")
            }
            Self::DuplicateField {
                field,
                line,
                column,
            } => write!(formatter, "duplicate field '{field}' at {line}:{column}"),
            Self::InvalidValue {
                field,
                line,
                column,
            } => write!(formatter, "invalid value for '{field}' at {line}:{column}"),
            Self::MissingField {
                field,
                line,
                column,
            } => write!(
                formatter,
                "missing required field '{field}' before {line}:{column}"
            ),
        }
    }
}

/// Marks configuration errors as standard error values.
impl Error for ConfigError {}

/// Parses required timeout and retry fields from a strict key-value document.
///
/// Blank lines are allowed. Field names and values are not trimmed; values must
/// contain only ASCII decimal digits. Error columns count Unicode scalar values
/// from one, and invalid raw values are never copied into the error.
///
/// # Errors
/// Returns a positioned error for malformed, unknown, duplicate, missing, or
/// invalid fields.
pub fn parse_config(input: &str) -> Result<Config, ConfigError> {
    let mut timeout_ms = None;
    let mut retry_limit = None;
    let mut line_count = 0;

    for (line_index, line) in input.lines().enumerate() {
        let line_number = line_index + 1;
        line_count = line_number;
        if line.is_empty() {
            continue;
        }

        let Some((field, raw_value)) = line.split_once('=') else {
            return Err(ConfigError::MissingSeparator {
                line: line_number,
                column: line.chars().count() + 1,
            });
        };

        match field {
            "timeout_ms" => {
                // Reject empty, signed, whitespace-padded, and non-ASCII digit values.
                if raw_value.is_empty()
                    || !raw_value.bytes().all(|byte| {
                        // Checks one byte against the ASCII decimal range.
                        byte.is_ascii_digit()
                    })
                {
                    return Err(ConfigError::InvalidValue {
                        field: "timeout_ms",
                        line: line_number,
                        column: field.chars().count() + 2,
                    });
                }
                let parsed = match raw_value.parse::<u64>() {
                    Ok(value) => value,
                    Err(_) => {
                        return Err(ConfigError::InvalidValue {
                            field: "timeout_ms",
                            line: line_number,
                            column: field.chars().count() + 2,
                        });
                    }
                };
                // TODO: This silently replaces a previous value; report DuplicateField instead.
                timeout_ms = Some(parsed);
            }
            "retry_limit" => {
                // Reject empty, signed, whitespace-padded, and non-ASCII digit values.
                if raw_value.is_empty()
                    || !raw_value.bytes().all(|byte| {
                        // Checks one byte against the ASCII decimal range.
                        byte.is_ascii_digit()
                    })
                {
                    return Err(ConfigError::InvalidValue {
                        field: "retry_limit",
                        line: line_number,
                        column: field.chars().count() + 2,
                    });
                }
                let parsed = match raw_value.parse::<u8>() {
                    Ok(value) => value,
                    Err(_) => {
                        return Err(ConfigError::InvalidValue {
                            field: "retry_limit",
                            line: line_number,
                            column: field.chars().count() + 2,
                        });
                    }
                };
                // TODO: This silently replaces a previous value; report DuplicateField instead.
                retry_limit = Some(parsed);
            }
            _ => {
                return Err(ConfigError::UnknownField {
                    line: line_number,
                    column: 1,
                });
            }
        }
    }

    let end_line = line_count + 1;
    let timeout_ms = timeout_ms.ok_or(ConfigError::MissingField {
        field: "timeout_ms",
        line: end_line,
        column: 1,
    })?;
    let retry_limit = retry_limit.ok_or(ConfigError::MissingField {
        field: "retry_limit",
        line: end_line,
        column: 1,
    })?;

    Ok(Config {
        timeout_ms,
        retry_limit,
    })
}
