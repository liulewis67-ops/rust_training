# M09-L05 配置解析器起始工作区

Edition 2024、无第三方依赖的 Rust 库实验。包版本为 `0.1.0`。解析器已实现位置化错误，但故意保留重复字段覆盖错误；公开测试应编译并仅因该行为断言失败。

## 开始实验

先检查 `tests/public_contract.rs` 与 `src/lib.rs`，再运行：

```text
cargo test --offline
```

起始版本的重复 `retry_limit` 会被后一个值覆盖，而不是返回 `ConfigError::DuplicateField`。其余契约覆盖正常配置、空输入、空值、缺分隔符、缺字段、Unicode 列号与非法数字。通过设置的行为测试后运行：

```text
cargo fmt -- --check
cargo check --offline
cargo test --offline
```

## 重置与追溯

从 `content/drafts/public/m09-l05-config-parser-starter.zip` 解压到一个**全新**目录。使用 `starter-manifest.json` 对每个列出的文件复核 SHA-256，再开始一轮新尝试。不要把修复后的工作目录重新打包成起始包。

本地验证可将 Cargo 目标目录指向项目外部目录，以免构建产物污染起始快照：

```powershell
$env:CARGO_TARGET_DIR = Join-Path $env:TEMP 'm09-l05-cargo-target'
cargo test --offline
cargo fmt -- --check
cargo check --offline
cargo test --offline
```

作者侧快照元数据不能替代正式 R2 对运行环境、重置、提交版本和成绩证据的控制。
