use m09_l05_config_parser::{Config, ConfigError, parse_config};

/// Accepts valid fields in either order and ignores empty lines.
#[test]
fn parses_valid_configuration_with_blank_lines() {
    assert_eq!(
        parse_config("\r\nretry_limit=3\r\ntimeout_ms=250\r\n"),
        Ok(Config {
            timeout_ms: 250,
            retry_limit: 3,
        })
    );
}

/// Reports the first required field at the end position for empty input.
#[test]
fn reports_missing_field_for_empty_document() {
    assert_eq!(
        parse_config(""),
        Err(ConfigError::MissingField {
            field: "timeout_ms",
            line: 1,
            column: 1,
        })
    );
}

/// Reports the missing value column without returning raw input text.
#[test]
fn reports_empty_value_at_its_start_column() {
    assert_eq!(
        parse_config("timeout_ms=\nretry_limit=2"),
        Err(ConfigError::InvalidValue {
            field: "timeout_ms",
            line: 1,
            column: 12,
        })
    );
}

/// Reports the expected separator after Unicode scalar values, not bytes.
#[test]
fn reports_malformed_line_at_unicode_character_position() {
    assert_eq!(
        parse_config("界xyz\ntimeout_ms=250\nretry_limit=2"),
        Err(ConfigError::MissingSeparator { line: 1, column: 5 })
    );
}

/// Reports a missing required field at the logical end of the document.
#[test]
fn reports_missing_field_after_other_valid_field() {
    assert_eq!(
        parse_config("retry_limit=2\n"),
        Err(ConfigError::MissingField {
            field: "timeout_ms",
            line: 2,
            column: 1,
        })
    );
}

/// Reports a missing retry field when the timeout field is present.
#[test]
fn reports_missing_retry_field() {
    assert_eq!(
        parse_config("timeout_ms=250"),
        Err(ConfigError::MissingField {
            field: "retry_limit",
            line: 2,
            column: 1,
        })
    );
}

/// Rejects duplicate required fields instead of silently accepting one value.
#[test]
fn reports_duplicate_field_location() {
    assert_eq!(
        parse_config("timeout_ms=250\nretry_limit=2\nretry_limit=4"),
        Err(ConfigError::DuplicateField {
            field: "retry_limit",
            line: 3,
            column: 1,
        })
    );
}

/// Rejects numeric text that is not an unsigned decimal value.
#[test]
fn reports_invalid_numeric_value() {
    assert_eq!(
        parse_config("timeout_ms=25x\nretry_limit=2"),
        Err(ConfigError::InvalidValue {
            field: "timeout_ms",
            line: 1,
            column: 12,
        })
    );
}

/// Rejects a valid decimal value that exceeds the target field's range.
#[test]
fn reports_numeric_overflow_at_the_value_start() {
    assert_eq!(
        parse_config("timeout_ms=18446744073709551616\nretry_limit=2"),
        Err(ConfigError::InvalidValue {
            field: "timeout_ms",
            line: 1,
            column: 12,
        })
    );
}

/// Rejects unknown keys without echoing untrusted field text in the error.
#[test]
fn reports_unknown_field_location() {
    assert_eq!(
        parse_config("secret_option=abc\ntimeout_ms=250\nretry_limit=2"),
        Err(ConfigError::UnknownField { line: 1, column: 1 })
    );
}
