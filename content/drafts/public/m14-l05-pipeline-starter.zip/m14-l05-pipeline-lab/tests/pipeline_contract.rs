//! Controlled acceptance tests for the bounded pipeline experiment.

use std::collections::BTreeSet;

use m14_l05_pipeline_lab::{Job, start_pipeline};
use tokio::sync::oneshot;

/// Builds one work item and returns its release and started gates.
fn gated_job(id: u8) -> (Job, oneshot::Sender<()>, oneshot::Receiver<()>) {
    let (release_tx, release_rx) = oneshot::channel();
    let (started_tx, started_rx) = oneshot::channel();
    (
        Job {
            id,
            release: release_rx,
            started: started_tx,
        },
        release_tx,
        started_rx,
    )
}

/// Preserves overflow work and collects each result after the gate opens.
#[tokio::test(flavor = "current_thread")]
async fn bounded_queue_applies_backpressure_and_collects_results() {
    let (job_tx, mut result_rx, workers) = start_pipeline(1, 1, 1);
    let (job_1, release_1, started_1) = gated_job(1);
    let (job_2, release_2, _started_2) = gated_job(2);
    let (job_3, _release_3, _started_3) = gated_job(3);

    job_tx.send(job_1).await.expect("first job enters queue");
    started_1.await.expect("worker starts first job");
    job_tx.try_send(job_2).expect("one waiting slot remains");
    let returned = job_tx.try_send(job_3).expect_err("queue is at capacity");
    let job_3 = match returned {
        tokio::sync::mpsc::error::TrySendError::Full(job) => job,
        tokio::sync::mpsc::error::TrySendError::Closed(_job) => {
            panic!("live pipeline must report Full, not Closed")
        }
    };
    assert_eq!(job_3.id, 3);

    assert!(release_1.send(()).is_ok());
    assert!(release_2.send(()).is_ok());
    drop(job_tx);
    for worker in workers {
        worker.await.expect("worker exits after queue closes");
    }
    let mut collected = Vec::new();
    while let Some(result) = result_rx.recv().await {
        collected.push(result);
    }
    collected.sort_unstable();
    assert_eq!(collected, [1, 2]);
}

/// Shares one active permit budget across every worker in the pipeline.
#[tokio::test(flavor = "current_thread")]
async fn active_work_never_exceeds_shared_limit() {
    let (job_tx, mut result_rx, workers) = start_pipeline(3, 3, 2);
    let (job_0, release_0, started_0) = gated_job(0);
    let (job_1, release_1, started_1) = gated_job(1);
    let (job_2, release_2, mut started_2) = gated_job(2);
    job_tx.send(job_0).await.expect("job zero is admitted");
    job_tx.send(job_1).await.expect("job one is admitted");
    job_tx.send(job_2).await.expect("job two is admitted");
    started_0.await.expect("first job starts");
    started_1.await.expect("second job starts");

    // Poll all workers while the first two jobs still hold the shared permits.
    tokio::task::yield_now().await;
    assert!(started_2.try_recv().is_err());
    assert!(release_0.send(()).is_ok());
    started_2
        .await
        .expect("third job starts after a permit is released");
    assert!(release_1.send(()).is_ok());
    assert!(release_2.send(()).is_ok());
    drop(job_tx);
    for worker in workers {
        worker.await.expect("worker exits after queue closes");
    }
    let mut collected = BTreeSet::new();
    while let Some(result) = result_rx.recv().await {
        assert!(collected.insert(result), "each job result is sent once");
    }
    assert_eq!(collected, BTreeSet::from([0, 1, 2]));
}
