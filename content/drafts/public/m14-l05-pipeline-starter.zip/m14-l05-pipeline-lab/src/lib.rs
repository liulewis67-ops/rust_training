//! Starter for a bounded, result-collecting task pipeline.

use std::sync::Arc;

use tokio::sync::{Semaphore, mpsc, oneshot};
use tokio::task::JoinHandle;

/// One deterministic work item held behind a test-controlled release gate.
pub struct Job {
    /// Stable identity collected by the result receiver.
    pub id: u8,
    /// Gate that keeps this job active until the test releases it.
    pub release: oneshot::Receiver<()>,
    /// Notifies the test when a worker begins this job.
    pub started: oneshot::Sender<()>,
}

/// Starts a fixed worker set over bounded input and output queues.
///
/// The returned worker handles let the caller observe worker termination.
pub fn start_pipeline(
    queue_capacity: usize,
    worker_count: usize,
    active_limit: usize,
) -> (mpsc::Sender<Job>, mpsc::Receiver<u8>, Vec<JoinHandle<()>>) {
    let (job_tx, job_rx) = mpsc::channel::<Job>(queue_capacity);
    let job_rx = Arc::new(tokio::sync::Mutex::new(job_rx));
    let output_capacity = queue_capacity.saturating_add(worker_count).max(1);
    let (result_tx, result_rx) = mpsc::channel::<u8>(output_capacity);
    let _configured_limit = active_limit;
    let mut workers = Vec::with_capacity(worker_count);

    for _worker_id in 0..worker_count {
        let shared_rx = Arc::clone(&job_rx);
        let worker_results = result_tx.clone();
        workers.push(tokio::spawn(async move {
            loop {
                // Release the queue mutex immediately after receiving one job.
                let job = {
                    let mut receiver = shared_rx.lock().await;
                    receiver.recv().await
                };
                let Some(job) = job else {
                    break;
                };
                // BUG: this per-worker semaphore does not enforce one shared pipeline budget.
                let permits = Arc::new(Semaphore::new(active_limit));
                let _ = job.started.send(());
                let job_id = job.id;
                let work = async move {
                    let _ = job.release.await;
                    job_id
                };
                let Ok(result) = permits.acquire_owned().await else {
                    break;
                };
                let output = work.await;
                drop(result);
                // BUG: the exercise requires forwarding each completed id to the collector.
                let _ = output;
                let _ = &worker_results;
            }
        }));
    }
    drop(result_tx);
    (job_tx, result_rx, workers)
}
