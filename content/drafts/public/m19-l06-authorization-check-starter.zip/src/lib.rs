//! Independent object-authorization regression check over a project task export API.

use axum::extract::{Extension, Path, State};
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::{Json, Router};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};

/// Builds the export router with an isolated fixed project fixture.
#[must_use = "use the returned router to exercise the endpoint"]
pub fn app() -> Router {
    Router::new()
        .route(
            "/api/v1/projects/{project_id}/tasks/export",
            get(export_tasks),
        )
        .with_state(AppState::default())
}

/// Trusted identity added by the test adapter after authentication.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct VerifiedIdentity {
    /// Stable server-side caller identifier.
    pub user_id: u64,
}

impl VerifiedIdentity {
    /// Constructs the identity fixture used by router tests.
    #[must_use]
    pub const fn new(user_id: u64) -> Self {
        Self { user_id }
    }
}

/// Safe API projection returned for one exported task.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct TaskView {
    /// Stable fixture task identifier.
    pub task_id: String,
    /// Project identifier stored with the task.
    pub project_id: String,
    /// User-visible task title.
    pub title: String,
}

/// Shared state for the two-project export fixture.
#[derive(Clone, Debug)]
struct AppState {
    store: Arc<Mutex<Store>>,
}

impl Default for AppState {
    fn default() -> Self {
        let mut store = Store::default();
        store.tasks.insert(
            "task-101".to_owned(),
            TaskRecord::new("task-101", "project-1", "Prepare launch checklist"),
        );
        store.tasks.insert(
            "task-102".to_owned(),
            TaskRecord::new("task-102", "project-1", "Review API contract"),
        );
        store.tasks.insert(
            "task-202".to_owned(),
            TaskRecord::new("task-202", "project-2", "Approve payroll report"),
        );
        store
            .memberships
            .insert((1, "project-1".to_owned()), ProjectRole::Owner);
        store
            .memberships
            .insert((2, "project-1".to_owned()), ProjectRole::Editor);
        store
            .memberships
            .insert((3, "project-1".to_owned()), ProjectRole::Viewer);
        store
            .memberships
            .insert((4, "project-2".to_owned()), ProjectRole::Owner);
        Self {
            store: Arc::new(Mutex::new(store)),
        }
    }
}

#[derive(Clone, Debug, Default)]
struct Store {
    tasks: HashMap<String, TaskRecord>,
    memberships: HashMap<(u64, String), ProjectRole>,
}

#[derive(Clone, Debug)]
struct TaskRecord {
    task_id: String,
    project_id: String,
    title: String,
}

impl TaskRecord {
    /// Creates one immutable task row for the assessment fixture.
    fn new(task_id: &str, project_id: &str, title: &str) -> Self {
        Self {
            task_id: task_id.to_owned(),
            project_id: project_id.to_owned(),
            title: title.to_owned(),
        }
    }

    /// Converts the server row to the public export representation.
    fn view(&self) -> TaskView {
        TaskView {
            task_id: self.task_id.clone(),
            project_id: self.project_id.clone(),
            title: self.title.clone(),
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ProjectRole {
    Owner,
    Editor,
    Viewer,
}

impl ProjectRole {
    /// Checks whether the role permits the sensitive export operation.
    fn permits_export(self) -> bool {
        matches!(self, Self::Owner | Self::Editor)
    }
}

async fn export_tasks(
    State(state): State<AppState>,
    Path(project_id): Path<String>,
    identity: Option<Extension<VerifiedIdentity>>,
) -> Response {
    let Some(Extension(identity)) = identity else {
        return auth_required();
    };
    let Ok(store) = state.store.lock() else {
        return internal_error();
    };
    let Some(role) = store
        .memberships
        .get(&(identity.user_id, project_id.clone()))
    else {
        return unavailable();
    };
    if !role.permits_export() {
        return unavailable();
    }

    // TODO: scope the export query to the requested project before serializing rows.
    let exported = store
        .tasks
        .values()
        .map(TaskRecord::view)
        .collect::<Vec<_>>();
    (StatusCode::OK, Json(exported)).into_response()
}

fn auth_required() -> Response {
    public_error(StatusCode::UNAUTHORIZED, "authentication_required")
}

fn unavailable() -> Response {
    public_error(StatusCode::NOT_FOUND, "resource_unavailable")
}

fn internal_error() -> Response {
    public_error(StatusCode::INTERNAL_SERVER_ERROR, "service_unavailable")
}

fn public_error(status: StatusCode, code: &'static str) -> Response {
    let message = match code {
        "authentication_required" => "A verified identity is required.",
        "resource_unavailable" => "The requested resource is unavailable.",
        _ => "The service is temporarily unavailable.",
    };
    (
        status,
        Json(ErrorBody {
            code: code.to_owned(),
            message: message.to_owned(),
        }),
    )
        .into_response()
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
struct ErrorBody {
    code: String,
    message: String,
}
