use axum::body::{Body, to_bytes};
use axum::http::Request;
use axum::http::StatusCode;
use axum::response::Response;
use m19_l06_authorization_check::{TaskView, VerifiedIdentity, app};
use serde_json::Value;
use tower::ServiceExt;

/// Sends one full-router export request with an optional trusted identity.
async fn export(user_id: Option<u64>, project_id: &str) -> Response {
    let request = Request::get(format!("/api/v1/projects/{project_id}/tasks/export"));
    let mut request = request.body(Body::empty()).expect("request");
    if let Some(user_id) = user_id {
        request
            .extensions_mut()
            .insert(VerifiedIdentity::new(user_id));
    }
    app().oneshot(request).await.expect("router response")
}

/// Reads one bounded JSON response for assertions.
async fn json(response: Response) -> Value {
    let bytes = to_bytes(response.into_body(), 16 * 1024)
        .await
        .expect("bounded response body");
    serde_json::from_slice(&bytes).expect("JSON response")
}

#[tokio::test]
async fn editor_export_keeps_all_tasks_but_only_from_the_editor_project() {
    let response = export(Some(2), "project-1").await;
    assert_eq!(response.status(), StatusCode::OK);
    let tasks: Vec<TaskView> = serde_json::from_value(json(response).await).expect("task list");
    assert_eq!(tasks.len(), 2);
    assert!(tasks.iter().all(|task| task.project_id == "project-1"));
}

#[tokio::test]
async fn viewer_cannot_use_the_export_action() {
    let response = export(Some(3), "project-1").await;
    assert_eq!(response.status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn outsider_cannot_export_a_project() {
    let response = export(Some(99), "project-1").await;
    assert_eq!(response.status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn anonymous_caller_is_rejected_before_export() {
    let response = export(None, "project-1").await;
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
}

#[tokio::test]
#[allow(clippy::todo)] // The learner must supply this regression test as part of the independent check.
async fn add_an_independent_cross_project_export_regression_test() {
    // TODO: choose a trusted member, request another project's export, and assert no foreign row is returned.
    // The hidden assessment uses different fixture IDs and checks that the regression test fails on the baseline.
    todo!("write one regression test for cross-project task export isolation");
}
