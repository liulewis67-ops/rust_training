# M19-L06 independent check: project task export isolation

This is an independent assessment variation following the M19-L05 task detail lab. The handler already checks a trusted identity and an action-specific project role. Inspect the data flow from the requested project to the exported rows, add one regression test that exposes the authorization bypass, then fix the implementation without removing the legitimate editor export.

Do not inspect M19-L05 reference code, private assessment files, or another learner's answer before your first submission. A first independent pass requires both a regression test that fails against the starter and a repair that passes the assessment while preserving an authorized export. Looking at a hint is allowed; opening a reference answer ends independent status for that attempt.

Run `cargo test --locked` to see the starter contract, then run fmt, strict Clippy and Rustdoc after implementing. The hidden checks vary user/project/task IDs and include a normal allowed export. Submit the `src/lib.rs` and test-file SHA-256 with assessment version and attempt label using the evidence contract in the course instructions.

Feedback categories:

- `FOREIGN_PROJECT_ROW`: the export contains a task stored under a different project.
- `VIEWER_EXPORT`: the Viewer action matrix is not enforced.
- `REGRESSION_TEST_MISSING`: no independent test demonstrates the bypass before the fix.
- `ALLOWED_EXPORT_REGRESSED`: the authorized Editor flow no longer works.

Platform execution failure is recorded separately from a learner result and does not lower a skill level. Failed attempts provide focused feedback and can be retried after practice.
