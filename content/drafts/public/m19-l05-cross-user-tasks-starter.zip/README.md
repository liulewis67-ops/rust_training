# M19-L05 experiment: stop cross-user task access

This deterministic in-memory Axum fixture models two projects, an owner/editor/viewer in project 1, and a separate owner in project 2. The baseline deliberately omits object-level permission checks and ignores the stored parent project on lookup. The full-router contract tests should expose those paths.

## Work loop

1. Run `cargo test --locked`; keep the failing rows as regression evidence.
2. Inspect each request's trusted user, URL project, stored task parent, action, and membership role. Repair read and write paths separately.
3. Run the full test suite until all cases pass, then run strict Clippy and Rustdoc.
4. Save a versioned digest of your solution with `node scripts/snapshot.mjs repaired-01`.
5. Run `node scripts/reset.mjs` and `cargo test --locked` again. The reset must reproduce the original failing baseline; restore the saved solution after checking it.

`node scripts/reset.mjs` restores `snapshots/0.1.0/src/lib.rs` and clears the generated submission snapshot. `snapshot.mjs` records the label, baseline version, and source SHA-256. These scripts only operate inside this package directory.

The public response contract is 401 for a missing trusted identity and a fixed 404 `resource_unavailable` for missing, invisible, path-mismatched, or unauthorized tasks. No real database, identity provider, or Linux R3 container is used here.
