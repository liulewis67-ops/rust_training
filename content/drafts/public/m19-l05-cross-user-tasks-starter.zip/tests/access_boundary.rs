use axum::body::{Body, to_bytes};
use axum::http::header::CONTENT_TYPE;
use axum::http::{Method, Request, StatusCode};
use axum::response::Response;
use m19_l05_cross_user_tasks::{ErrorBody, TaskView, VerifiedIdentity, app};
use serde_json::Value;
use tower::ServiceExt;

/// Sends a request through the full router using an optional trusted test identity.
async fn send(
    router: axum::Router,
    method: Method,
    path: &str,
    user_id: Option<u64>,
    body: Option<&str>,
) -> Response {
    let mut request = Request::builder().method(method).uri(path);
    let body = if let Some(body) = body {
        request = request.header(CONTENT_TYPE, "application/json");
        Body::from(body.to_owned())
    } else {
        Body::empty()
    };
    let mut request = request.body(body).expect("request");
    if let Some(user_id) = user_id {
        request
            .extensions_mut()
            .insert(VerifiedIdentity::new(user_id));
    }
    router.oneshot(request).await.expect("router response")
}

/// Reads a small response body for an assertion without unbounded collection.
async fn json(response: Response) -> Value {
    let bytes = to_bytes(response.into_body(), 8 * 1024)
        .await
        .expect("bounded response");
    serde_json::from_slice(&bytes).expect("JSON response")
}

#[tokio::test]
async fn owner_reads_a_task_inside_the_owned_project() {
    let response = send(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(1),
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::OK);
    let view: TaskView = serde_json::from_value(json(response).await).expect("task view");
    assert_eq!(view.project_id, "project-1");
}

#[tokio::test]
async fn outsider_cannot_read_an_existing_task_by_guessing_its_id() {
    let response = send(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(99),
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::NOT_FOUND);
    let error: ErrorBody = serde_json::from_value(json(response).await).expect("error shape");
    assert_eq!(error.code, "resource_unavailable");
}

#[tokio::test]
async fn viewer_can_read_but_cannot_update_a_task() {
    let response = send(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(3),
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::OK);

    let response = send(
        app(),
        Method::PATCH,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(3),
        Some(r#"{"title":"unauthorized edit"}"#),
    )
    .await;
    assert_eq!(response.status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn project_member_cannot_swap_parent_path_to_reach_another_project_task() {
    let response = send(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-202",
        Some(1),
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn outsider_cannot_write_and_rejection_does_not_change_state() {
    let response = send(
        app(),
        Method::PATCH,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(99),
        Some(r#"{"title":"stolen update"}"#),
    )
    .await;
    assert_eq!(response.status(), StatusCode::NOT_FOUND);

    let response = send(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(1),
        None,
    )
    .await;
    let view: TaskView = serde_json::from_value(json(response).await).expect("owner can reread");
    assert_eq!(view.title, "Review deployment plan");
}

#[tokio::test]
async fn editor_can_update_a_task_in_their_project() {
    let response = send(
        app(),
        Method::PATCH,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(2),
        Some(r#"{"title":"reviewed safely"}"#),
    )
    .await;
    assert_eq!(response.status(), StatusCode::OK);
    let view: TaskView = serde_json::from_value(json(response).await).expect("updated view");
    assert_eq!(view.title, "reviewed safely");
}

#[tokio::test]
async fn missing_and_invisible_task_use_the_same_public_error() {
    let missing = send(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/no-such-task",
        Some(1),
        None,
    )
    .await;
    let invisible = send(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(99),
        None,
    )
    .await;
    assert_eq!(missing.status(), StatusCode::NOT_FOUND);
    assert_eq!(invisible.status(), StatusCode::NOT_FOUND);
    assert_eq!(json(missing).await, json(invisible).await);
}

#[tokio::test]
async fn anonymous_request_is_distinct_from_authenticated_invisibility() {
    let response = send(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        None,
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
}
