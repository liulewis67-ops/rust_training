//! Cross-user task access experiment with a deterministic in-memory fixture.

use axum::extract::{Extension, Path, State};
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::{Json, Router};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};

/// Creates the experiment router and its isolated deterministic fixture.
#[must_use = "use the router to send requests through the experiment"]
pub fn app() -> Router {
    Router::new()
        .route(
            "/api/v1/projects/{project_id}/tasks/{task_id}",
            get(read_task).patch(update_task),
        )
        .with_state(AppState::default())
}

/// Trusted identity supplied by the isolated test adapter.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct VerifiedIdentity {
    /// Stable server-side user identifier.
    pub user_id: u64,
}

impl VerifiedIdentity {
    /// Constructs a fixture identity for a request test.
    #[must_use]
    pub const fn new(user_id: u64) -> Self {
        Self { user_id }
    }
}

/// Task data visible after object-level read authorization succeeds.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct TaskView {
    /// Stable task identifier in the fixture.
    pub task_id: String,
    /// Parent project identifier from server-side storage.
    pub project_id: String,
    /// User-visible task title.
    pub title: String,
}

/// Stable public error representation.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct ErrorBody {
    /// Machine-readable public category.
    pub code: String,
    /// Fixed user-facing message.
    pub message: String,
}

#[derive(Clone, Debug)]
struct AppState {
    store: Arc<Mutex<Store>>,
}

impl Default for AppState {
    fn default() -> Self {
        let mut store = Store::default();
        store.tasks.insert(
            "task-101".to_owned(),
            TaskRecord::new("task-101", "project-1", "Review deployment plan"),
        );
        store.tasks.insert(
            "task-202".to_owned(),
            TaskRecord::new("task-202", "project-2", "Rotate service key"),
        );
        store
            .memberships
            .insert((1, "project-1".to_owned()), ProjectRole::Owner);
        store
            .memberships
            .insert((2, "project-1".to_owned()), ProjectRole::Editor);
        store
            .memberships
            .insert((3, "project-1".to_owned()), ProjectRole::Viewer);
        store
            .memberships
            .insert((4, "project-2".to_owned()), ProjectRole::Owner);
        Self {
            store: Arc::new(Mutex::new(store)),
        }
    }
}

#[derive(Clone, Debug, Default)]
struct Store {
    tasks: HashMap<String, TaskRecord>,
    memberships: HashMap<(u64, String), ProjectRole>,
}

#[derive(Clone, Debug)]
struct TaskRecord {
    task_id: String,
    project_id: String,
    title: String,
}

impl TaskRecord {
    /// Creates a server-owned task row for the fixed course fixture.
    fn new(task_id: &str, project_id: &str, title: &str) -> Self {
        Self {
            task_id: task_id.to_owned(),
            project_id: project_id.to_owned(),
            title: title.to_owned(),
        }
    }

    /// Projects the storage row into the public API representation.
    fn view(&self) -> TaskView {
        TaskView {
            task_id: self.task_id.clone(),
            project_id: self.project_id.clone(),
            title: self.title.clone(),
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ProjectRole {
    Owner,
    Editor,
    Viewer,
}

impl ProjectRole {
    /// Checks the minimum project role for reading or editing a task.
    fn permits(self, action: TaskAction) -> bool {
        match action {
            TaskAction::Read => true,
            TaskAction::Edit => matches!(self, Self::Owner | Self::Editor),
        }
    }
}

#[derive(Clone, Copy, Debug)]
enum TaskAction {
    Read,
    Edit,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct TaskPatch {
    title: String,
}

async fn read_task(
    State(state): State<AppState>,
    Path((_project_id, task_id)): Path<(String, String)>,
    identity: Option<Extension<VerifiedIdentity>>,
) -> Response {
    let Some(Extension(identity)) = identity else {
        return auth_required();
    };
    let Ok(store) = state.store.lock() else {
        return internal_error();
    };
    let Some(task) = store.tasks.get(&task_id) else {
        return unavailable();
    };
    // TODO: bind the URL parent and caller membership to the stored task before returning it.
    let role = store
        .memberships
        .get(&(identity.user_id, task.project_id.clone()));
    let _has_read_role = role.is_some_and(|role| role.permits(TaskAction::Read));
    (StatusCode::OK, Json(task.view())).into_response()
}

async fn update_task(
    State(state): State<AppState>,
    Path((_project_id, task_id)): Path<(String, String)>,
    identity: Option<Extension<VerifiedIdentity>>,
    Json(patch): Json<TaskPatch>,
) -> Response {
    let Some(Extension(identity)) = identity else {
        return auth_required();
    };
    if patch.title.trim().is_empty() {
        return invalid_update();
    }
    let Ok(mut store) = state.store.lock() else {
        return internal_error();
    };
    let Some(current) = store.tasks.get(&task_id) else {
        return unavailable();
    };
    // TODO: reject parent-path mismatches and require Owner or Editor membership.
    let role = store
        .memberships
        .get(&(identity.user_id, current.project_id.clone()));
    let _has_edit_role = role.is_some_and(|role| role.permits(TaskAction::Edit));
    let Some(task) = store.tasks.get_mut(&task_id) else {
        return unavailable();
    };
    patch.title.trim().clone_into(&mut task.title);
    (StatusCode::OK, Json(task.view())).into_response()
}

fn auth_required() -> Response {
    public_error(StatusCode::UNAUTHORIZED, "authentication_required")
}

fn unavailable() -> Response {
    public_error(StatusCode::NOT_FOUND, "resource_unavailable")
}

fn invalid_update() -> Response {
    public_error(StatusCode::UNPROCESSABLE_ENTITY, "invalid_task_update")
}

fn internal_error() -> Response {
    public_error(StatusCode::INTERNAL_SERVER_ERROR, "service_unavailable")
}

fn public_error(status: StatusCode, code: &'static str) -> Response {
    let message = match code {
        "authentication_required" => "A verified identity is required.",
        "resource_unavailable" => "The requested resource is unavailable.",
        "invalid_task_update" => "The task update is invalid.",
        _ => "The service is temporarily unavailable.",
    };
    (
        status,
        Json(ErrorBody {
            code: code.to_owned(),
            message: message.to_owned(),
        }),
    )
        .into_response()
}
