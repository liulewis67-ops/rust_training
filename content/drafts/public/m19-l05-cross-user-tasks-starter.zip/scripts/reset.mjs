import { copyFile, unlink } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

/** Restore the checked-in baseline source and clear this exercise's result snapshot. */
async function main() {
  const packageDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
  const baseline = path.join(packageDir, "snapshots", "0.1.0", "src", "lib.rs");
  const target = path.join(packageDir, "src", "lib.rs");
  await copyFile(baseline, target);
  const result = path.join(packageDir, "submission-snapshot.json");
  await unlink(result).catch((error) => {
    if (error.code !== "ENOENT") throw error;
  });
  process.stdout.write("Restored baseline version 0.1.0\n");
}

await main();
