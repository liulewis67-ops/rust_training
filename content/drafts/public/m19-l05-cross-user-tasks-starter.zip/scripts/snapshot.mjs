import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

/** Hash the repaired source and write a versioned experiment snapshot. */
async function main() {
  const label = process.argv[2];
  if (!label || !/^[a-zA-Z0-9][a-zA-Z0-9.-]{0,39}$/.test(label)) {
    throw new Error("usage: node scripts/snapshot.mjs <version-label>");
  }
  const packageDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
  const source = await readFile(path.join(packageDir, "src", "lib.rs"));
  const sourceSha256 = createHash("sha256").update(source).digest("hex");
  const snapshot = {
    exercise: "m19-l05-cross-user-tasks",
    baseline_version: "0.1.0",
    submission_label: label,
    source_sha256: sourceSha256,
  };
  await writeFile(
    path.join(packageDir, "submission-snapshot.json"),
    `${JSON.stringify(snapshot, null, 2)}\n`,
    "utf8",
  );
  process.stdout.write(`Saved ${label} ${sourceSha256}\n`);
}

await main();
