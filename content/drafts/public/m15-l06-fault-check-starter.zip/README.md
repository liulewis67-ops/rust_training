# M15-L06 Fault Injection Check Starter v0.1.0

Extract the original ZIP into a fresh directory. Verify the public-file SHA-256 entries in `starter-manifest.json`, preserve the original snapshot, then run the contract test before and after your change. For each attempt, start again from this package version; do not carry a modified `target/` or private scoring files into the next attempt.

The public tests describe allowed terminal results, exact cleanup counts, and the requirement to join the complete task set. The check does not require real network access or a Linux container.
