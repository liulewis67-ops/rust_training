//! Combined cancellation, deadline and failure injection contracts.

use std::collections::BTreeMap;
use std::sync::{Arc, atomic::AtomicUsize};

use m15_l06_fault_check::{FaultJob, Outcome, WorkFailure, assess_batch};
use tokio::sync::oneshot;
use tokio::time::Instant;

/// Builds one assessment task with explicit work and cancellation gates.
type FaultGates = (
    FaultJob,
    oneshot::Sender<Result<(), WorkFailure>>,
    oneshot::Sender<()>,
);

fn fault_job(id: u8, deadline: Instant) -> FaultGates {
    let (work_tx, work) = oneshot::channel();
    let (cancel_tx, cancel) = oneshot::channel();
    (
        FaultJob {
            id,
            work,
            cancel,
            deadline,
        },
        work_tx,
        cancel_tx,
    )
}

/// Emits one result per accepted task and runs cleanup once under combined faults.
#[tokio::test(flavor = "current_thread")]
async fn combined_faults_settle_once_and_leave_no_task() {
    let now = Instant::now();
    let (cancelled, retry_tx, cancel_tx) = fault_job(31, now);
    let (failed, permanent_tx, _permanent_cancel) = fault_job(32, now);
    let (completed, success_tx, _success_cancel) =
        fault_job(33, now + std::time::Duration::from_secs(10));
    let (timed_out, _timeout_work, _timeout_cancel) = fault_job(34, now);
    assert!(retry_tx.send(Err(WorkFailure::Retryable)).is_ok());
    assert!(cancel_tx.send(()).is_ok());
    assert!(permanent_tx.send(Err(WorkFailure::Permanent)).is_ok());
    assert!(success_tx.send(Ok(())).is_ok());

    let cleanup = Arc::new(AtomicUsize::new(0));
    let report = assess_batch(
        vec![cancelled, failed, completed, timed_out],
        Arc::clone(&cleanup),
    )
    .await;
    let by_id: BTreeMap<_, _> = report
        .tasks
        .iter()
        .map(|task| (task.id, task.outcome))
        .collect();
    assert_eq!(report.tasks.len(), 4);
    assert_eq!(by_id.len(), 4, "each ID appears exactly once");
    assert_eq!(by_id.get(&31), Some(&Outcome::Cancelled));
    assert_eq!(by_id.get(&32), Some(&Outcome::PermanentFailure));
    assert_eq!(by_id.get(&33), Some(&Outcome::Succeeded));
    assert_eq!(by_id.get(&34), Some(&Outcome::TimedOut));
    assert_eq!(report.join_failures, 0);
    assert_eq!(report.cleanup_runs, 4, "cleanup runs once for every task");
    assert_eq!(cleanup.load(std::sync::atomic::Ordering::SeqCst), 4);
}

/// Keeps exactly-once and cleanup contracts under a new ID order and fifth task.
#[tokio::test(flavor = "current_thread")]
async fn permuted_extended_batch_preserves_all_terminal_ids() {
    let now = Instant::now();
    let (timeout_job, _timeout_work, _timeout_cancel) = fault_job(9, now);
    let (permanent_job, permanent_tx, _permanent_cancel) = fault_job(2, now);
    let (success_job, success_tx, _success_cancel) =
        fault_job(5, now + std::time::Duration::from_secs(10));
    let (cancel_job, retry_tx, cancel_tx) = fault_job(8, now);
    let (retry_job, retryable_tx, _retryable_cancel) =
        fault_job(100, now + std::time::Duration::from_secs(10));
    assert!(permanent_tx.send(Err(WorkFailure::Permanent)).is_ok());
    assert!(success_tx.send(Ok(())).is_ok());
    assert!(retry_tx.send(Err(WorkFailure::Retryable)).is_ok());
    assert!(cancel_tx.send(()).is_ok());
    assert!(retryable_tx.send(Err(WorkFailure::Retryable)).is_ok());

    let cleanup = Arc::new(AtomicUsize::new(0));
    let report = assess_batch(
        vec![
            retry_job,
            success_job,
            timeout_job,
            cancel_job,
            permanent_job,
        ],
        Arc::clone(&cleanup),
    )
    .await;
    let actual: BTreeMap<_, _> = report
        .tasks
        .iter()
        .map(|task| (task.id, task.outcome))
        .collect();
    assert_eq!(actual.len(), 5, "every ID appears exactly once");
    assert_eq!(actual.get(&2), Some(&Outcome::PermanentFailure));
    assert_eq!(actual.get(&5), Some(&Outcome::Succeeded));
    assert_eq!(actual.get(&8), Some(&Outcome::Cancelled));
    assert_eq!(actual.get(&9), Some(&Outcome::TimedOut));
    assert_eq!(actual.get(&100), Some(&Outcome::RetryableFailure));
    assert_eq!(report.join_failures, 0);
    assert_eq!(report.cleanup_runs, 5);
    assert_eq!(cleanup.load(std::sync::atomic::Ordering::SeqCst), 5);
}
