//! Starter for a fault-injection assessment of terminal state and cleanup.

use std::sync::{
    Arc,
    atomic::{AtomicUsize, Ordering},
};

use tokio::sync::oneshot;
use tokio::task::JoinSet;
use tokio::time::{Instant, sleep_until};

/// One terminal result observed for a task.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Outcome {
    /// Work produced a successful value.
    Succeeded,
    /// Work failed with an error that may be retried by bounded policy.
    RetryableFailure,
    /// Work failed permanently.
    PermanentFailure,
    /// A cancellation request won the arbitration policy.
    Cancelled,
    /// The absolute deadline won the arbitration policy.
    TimedOut,
}

/// Injected work error class used by the fault assessment.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WorkFailure {
    /// The caller may retry under a bounded policy.
    Retryable,
    /// Repeating the same attempt is not useful.
    Permanent,
}

/// A deterministic fault injection input for one task.
pub struct FaultJob {
    /// Stable task identity.
    pub id: u8,
    /// Injected success or failure result.
    pub work: oneshot::Receiver<Result<(), WorkFailure>>,
    /// Injected cancellation request.
    pub cancel: oneshot::Receiver<()>,
    /// One absolute task deadline.
    pub deadline: Instant,
}

/// One terminal task result.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct TaskReport {
    /// Original task identity.
    pub id: u8,
    /// The single winning terminal classification.
    pub outcome: Outcome,
}

/// Results and cleanup evidence after every injected task has been joined.
#[derive(Debug, PartialEq, Eq)]
pub struct BatchReport {
    /// One record for each task that was spawned into the assessment set.
    pub tasks: Vec<TaskReport>,
    /// Number of join failures while collecting the task set.
    pub join_failures: usize,
    /// Number of cleanup calls observed by the fault-injection counter.
    pub cleanup_runs: usize,
}

/// Runs one fault-injection batch and joins every spawned task to termination.
pub async fn assess_batch(jobs: Vec<FaultJob>, cleanup_runs: Arc<AtomicUsize>) -> BatchReport {
    let expected = jobs.len();
    let mut tasks = JoinSet::new();
    for job in jobs {
        let cleanup = Arc::clone(&cleanup_runs);
        tasks.spawn(async move { settle_one(job, cleanup).await });
    }

    let mut reports = Vec::with_capacity(expected);
    let mut join_failures = 0;
    while let Some(result) = tasks.join_next().await {
        match result {
            Ok(report) => reports.push(report),
            Err(_join_error) => join_failures += 1,
        }
    }
    reports.sort_unstable_by_key(|report| report.id);
    BatchReport {
        tasks: reports,
        join_failures,
        cleanup_runs: cleanup_runs.load(Ordering::SeqCst),
    }
}

/// Chooses one terminal result using cancellation, work, then deadline priority.
async fn settle_one(job: FaultJob, cleanup_runs: Arc<AtomicUsize>) -> TaskReport {
    let outcome = tokio::select! {
        biased;
        _ = job.cancel => Outcome::Cancelled,
        result = job.work => match result {
            Ok(Ok(())) => Outcome::Succeeded,
            Ok(Err(WorkFailure::Retryable)) => Outcome::RetryableFailure,
            Ok(Err(WorkFailure::Permanent)) | Err(_) => Outcome::PermanentFailure,
        },
        _ = sleep_until(job.deadline) => Outcome::TimedOut,
    };

    cleanup_runs.fetch_add(1, Ordering::SeqCst);
    // Record the cancellation cleanup path.
    if outcome == Outcome::Cancelled {
        cleanup_runs.fetch_add(1, Ordering::SeqCst);
    }
    TaskReport {
        id: job.id,
        outcome,
    }
}
