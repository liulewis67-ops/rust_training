# M19-L03 resource ownership and project roles

This public starter uses an in-memory project membership fixture to make object-level authorization observable. The fixture roles are resolved from the server-side membership map; the exercise does not implement platform roles, database persistence, or production authentication.

The baseline intentionally grants every project member write access, accepts a body-supplied role, and looks up tasks without binding the requested project path to the task's actual project. Contract tests expose those failures.

Run from this directory:

```text
cargo test --locked --no-fail-fast
cargo clippy --locked --all-targets -- -D warnings
```

The Linux R3 container remains deferred for author-side work.
