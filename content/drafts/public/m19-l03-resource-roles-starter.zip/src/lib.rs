//! Project-scoped task access with a server-side role matrix.

use axum::extract::{Extension, Path, State};
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::{Json, Router};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};

/// Builds a router over isolated project, task, and membership fixtures.
#[must_use = "the returned router must be served or used by a test"]
pub fn app() -> Router {
    Router::new()
        .route(
            "/api/v1/projects/{project_id}/tasks/{task_id}",
            get(get_task_handler).patch(patch_task_handler),
        )
        .fallback(unknown_route)
        .with_state(AppState::default())
}

/// Identity supplied only by the trusted in-process authentication adapter.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct VerifiedIdentity {
    /// Stable server-side caller identifier.
    pub user_id: u64,
}

impl VerifiedIdentity {
    /// Builds the caller value used by the trusted test adapter.
    #[must_use]
    pub const fn new(user_id: u64) -> Self {
        Self { user_id }
    }
}

/// Allowed task states in the lesson's fixed workflow.
#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum TaskStatus {
    /// Work has not started.
    Todo,
    /// Work is in progress.
    InProgress,
    /// Work is complete.
    Done,
}

/// Public task fields returned after the caller passes object and role checks.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct TaskView {
    /// Opaque task identifier used by this fixture.
    pub task_id: String,
    /// Parent project identifier.
    pub project_id: String,
    /// User-visible task title.
    pub title: String,
    /// Current workflow state.
    pub status: TaskStatus,
}

/// Stable error shape for authentication and input failures.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct ErrorBody {
    /// Machine-readable error category.
    pub code: String,
    /// Safe public message.
    pub message: String,
}

/// Shared server-side task and membership state for this test application.
#[derive(Clone, Debug)]
struct AppState {
    store: Arc<Mutex<Store>>,
}

impl Default for AppState {
    /// Creates two projects with distinct member roles and predictable task IDs.
    fn default() -> Self {
        let mut store = Store::default();
        store.tasks.insert(
            "task-101".to_owned(),
            TaskRecord::new(
                "task-101",
                "project-1",
                "Close release notes",
                TaskStatus::Done,
            ),
        );
        store.tasks.insert(
            "task-102".to_owned(),
            TaskRecord::new(
                "task-102",
                "project-1",
                "Review pull request",
                TaskStatus::InProgress,
            ),
        );
        store.tasks.insert(
            "task-202".to_owned(),
            TaskRecord::new(
                "task-202",
                "project-2",
                "Rotate deployment key",
                TaskStatus::Done,
            ),
        );
        store
            .memberships
            .insert((1, "project-1".to_owned()), ProjectRole::Owner);
        store
            .memberships
            .insert((2, "project-1".to_owned()), ProjectRole::Editor);
        store
            .memberships
            .insert((3, "project-1".to_owned()), ProjectRole::Viewer);
        store
            .memberships
            .insert((4, "project-2".to_owned()), ProjectRole::Owner);
        Self {
            store: Arc::new(Mutex::new(store)),
        }
    }
}

/// In-memory project data and membership relationships owned by the server.
#[derive(Clone, Debug, Default)]
struct Store {
    tasks: HashMap<String, TaskRecord>,
    memberships: HashMap<(u64, String), ProjectRole>,
}

/// Private task fields that must not be trusted from a request body.
#[derive(Clone, Debug)]
struct TaskRecord {
    task_id: String,
    project_id: String,
    title: String,
    status: TaskStatus,
}

impl TaskRecord {
    /// Creates one server-owned task fixture.
    fn new(task_id: &str, project_id: &str, title: &str, status: TaskStatus) -> Self {
        Self {
            task_id: task_id.to_owned(),
            project_id: project_id.to_owned(),
            title: title.to_owned(),
            status,
        }
    }

    /// Removes internal storage concerns from the HTTP representation.
    fn into_view(self) -> TaskView {
        TaskView {
            task_id: self.task_id,
            project_id: self.project_id,
            title: self.title,
            status: self.status,
        }
    }
}

/// Project-scoped relationship returned by the server-side membership lookup.
#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
enum ProjectRole {
    Owner,
    Editor,
    Viewer,
}

impl ProjectRole {
    /// Checks whether this membership permits the requested operation.
    fn permits(self, _action: TaskAction) -> bool {
        // TODO: enforce the operation matrix for Owner, Editor, and Viewer.
        matches!(self, Self::Owner | Self::Editor | Self::Viewer)
    }
}

/// Protected operation used by the task role matrix.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum TaskAction {
    Read,
    Edit,
    ReopenDone,
}

/// Reads a task only when its requested project path, stored owner project, and membership agree.
async fn get_task_handler(
    State(state): State<AppState>,
    Path((_project_id, task_id)): Path<(String, String)>,
    identity: Option<Extension<VerifiedIdentity>>,
) -> Response {
    let Some(Extension(identity)) = identity else {
        return authentication_error();
    };
    let Ok(store) = state.store.lock() else {
        return internal_error();
    };
    let Some(task) = store.tasks.get(&task_id) else {
        return invisible_error();
    };
    // TODO: bind the requested project path to the task's stored parent project.
    let role = store
        .memberships
        .get(&(identity.user_id, task.project_id.clone()));
    if !role.is_some_and(|role| role.permits(TaskAction::Read)) {
        return invisible_error();
    }
    (StatusCode::OK, Json(task.clone().into_view())).into_response()
}

/// Applies an allowed patch after checking the exact task's project relationship and role.
async fn patch_task_handler(
    State(state): State<AppState>,
    Path((_project_id, task_id)): Path<(String, String)>,
    identity: Option<Extension<VerifiedIdentity>>,
    Json(patch): Json<TaskPatch>,
) -> Response {
    let Some(Extension(identity)) = identity else {
        return authentication_error();
    };
    if patch.title.is_none() && patch.status.is_none() {
        return invalid_update_error();
    }
    if patch
        .title
        .as_ref()
        .is_some_and(|title| title.trim().is_empty())
    {
        return invalid_update_error();
    }
    let Ok(mut store) = state.store.lock() else {
        return internal_error();
    };
    let Some(current) = store.tasks.get(&task_id).cloned() else {
        return invisible_error();
    };
    // TODO: bind both path IDs before checking membership or mutating the task.
    let Some(stored_role) = store
        .memberships
        .get(&(identity.user_id, current.project_id.clone()))
        .copied()
    else {
        return invisible_error();
    };
    // TODO: role must come only from server-side membership, never a patch field.
    let role = if let Some(requested_role) = patch.role {
        store.memberships.insert(
            (identity.user_id, current.project_id.clone()),
            requested_role,
        );
        requested_role
    } else {
        stored_role
    };
    let action =
        if current.status == TaskStatus::Done && patch.status == Some(TaskStatus::InProgress) {
            TaskAction::ReopenDone
        } else {
            TaskAction::Edit
        };
    if !role.permits(action) {
        return invisible_error();
    }
    let Some(task) = store.tasks.get_mut(&task_id) else {
        return invisible_error();
    };
    if let Some(title) = patch.title {
        title.trim().clone_into(&mut task.title);
    }
    if let Some(status) = patch.status {
        task.status = status;
    }
    (StatusCode::OK, Json(task.clone().into_view())).into_response()
}

/// Body schema contains task fields only; client-supplied role or membership is rejected.
#[derive(Clone, Debug, Deserialize)]
struct TaskPatch {
    title: Option<String>,
    status: Option<TaskStatus>,
    role: Option<ProjectRole>,
}

/// Creates the stable anonymous response used for requests without trusted identity.
fn authentication_error() -> Response {
    public_error(StatusCode::UNAUTHORIZED, "authentication_required")
}

/// Hides missing resources and unauthorized memberships under one non-enumerating response.
fn invisible_error() -> Response {
    public_error(StatusCode::NOT_FOUND, "resource_unavailable")
}

/// Describes a malformed or empty task patch without leaking private resource data.
fn invalid_update_error() -> Response {
    public_error(StatusCode::UNPROCESSABLE_ENTITY, "invalid_task_update")
}

/// Keeps internal state failures separate from public authorization decisions.
fn internal_error() -> Response {
    public_error(StatusCode::INTERNAL_SERVER_ERROR, "service_unavailable")
}

/// Builds a fixed public error body without exposing project membership or task ownership.
fn public_error(status: StatusCode, code: &'static str) -> Response {
    let message = match code {
        "authentication_required" => "A verified identity is required.",
        "resource_unavailable" => "The requested resource is unavailable.",
        "invalid_task_update" => "The task update is invalid.",
        _ => "The service is temporarily unavailable.",
    };
    (
        status,
        Json(ErrorBody {
            code: code.to_owned(),
            message: message.to_owned(),
        }),
    )
        .into_response()
}

/// Returns a stable not-found response for unsupported routes.
async fn unknown_route() -> Response {
    invisible_error()
}
