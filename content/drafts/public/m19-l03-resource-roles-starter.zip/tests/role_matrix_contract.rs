//! Full-router matrix checks for project-scoped object authorization.

use axum::body::{Body, to_bytes};
use axum::http::header::CONTENT_TYPE;
use axum::http::{Method, Request, StatusCode};
use axum::response::Response;
use m19_l03_resource_roles::{ErrorBody, TaskStatus, TaskView, VerifiedIdentity, app};
use serde_json::Value;
use tower::ServiceExt;

/// Sends one request through a complete router as an optional trusted test identity.
async fn task_request(
    router: axum::Router,
    method: Method,
    uri: &str,
    user_id: Option<u64>,
    body: Option<&str>,
) -> Response {
    let mut builder = Request::builder().method(method).uri(uri);
    let request_body = if let Some(body) = body {
        builder = builder.header(CONTENT_TYPE, "application/json");
        Body::from(body.to_owned())
    } else {
        Body::empty()
    };
    let mut request = builder.body(request_body).expect("valid exercise request");
    if let Some(user_id) = user_id {
        request
            .extensions_mut()
            .insert(VerifiedIdentity::new(user_id));
    }
    router.oneshot(request).await.expect("router response")
}

/// Decodes a bounded response body for stable contract assertions.
async fn response_json(response: Response) -> Value {
    let bytes = to_bytes(response.into_body(), 8 * 1024)
        .await
        .expect("bounded JSON response");
    serde_json::from_slice(&bytes).expect("valid JSON response")
}

/// Missing trusted identity is rejected before the handler reads a protected task.
#[tokio::test]
async fn anonymous_task_read_requires_authentication() {
    let response = task_request(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        None,
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    let body: ErrorBody =
        serde_json::from_value(response_json(response).await).expect("error contract");
    assert_eq!(body.code, "authentication_required");
}

/// The project owner can read the task within the owner's project.
#[tokio::test]
async fn project_owner_can_read_task() {
    let response = task_request(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(1),
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::OK);
    let task: TaskView =
        serde_json::from_value(response_json(response).await).expect("public task view");
    assert_eq!(task.task_id, "task-101");
    assert_eq!(task.project_id, "project-1");
    assert_eq!(task.status, TaskStatus::Done);
}

/// An editor can update a task title within the editor's own project.
#[tokio::test]
async fn project_editor_can_update_task_title() {
    let response = task_request(
        app(),
        Method::PATCH,
        "/api/v1/projects/project-1/tasks/task-102",
        Some(2),
        Some(r#"{"title":"Review release checklist"}"#),
    )
    .await;
    assert_eq!(response.status(), StatusCode::OK);
    let task: TaskView =
        serde_json::from_value(response_json(response).await).expect("updated task view");
    assert_eq!(task.title, "Review release checklist");
}

/// A viewer can read the object but cannot modify it, and a denied patch changes no state.
#[tokio::test]
async fn project_viewer_can_read_but_cannot_edit() {
    let router = app();
    let read = task_request(
        router.clone(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-102",
        Some(3),
        None,
    )
    .await;
    assert_eq!(read.status(), StatusCode::OK);

    let denied = task_request(
        router.clone(),
        Method::PATCH,
        "/api/v1/projects/project-1/tasks/task-102",
        Some(3),
        Some(r#"{"title":"viewer changed this"}"#),
    )
    .await;
    assert_eq!(denied.status(), StatusCode::NOT_FOUND);
    assert_eq!(response_json(denied).await["code"], "resource_unavailable");

    let unchanged = task_request(
        router,
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-102",
        Some(3),
        None,
    )
    .await;
    let task: TaskView =
        serde_json::from_value(response_json(unchanged).await).expect("unchanged task");
    assert_eq!(task.title, "Review pull request");
}

/// An editor cannot roll a completed task back; denied workflow changes do not persist.
#[tokio::test]
async fn project_editor_cannot_reopen_done_task() {
    let router = app();
    let denied = task_request(
        router.clone(),
        Method::PATCH,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(2),
        Some(r#"{"status":"in_progress"}"#),
    )
    .await;
    assert_eq!(denied.status(), StatusCode::NOT_FOUND);

    let unchanged = task_request(
        router,
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(1),
        None,
    )
    .await;
    let task: TaskView =
        serde_json::from_value(response_json(unchanged).await).expect("unchanged task");
    assert_eq!(task.status, TaskStatus::Done);
}

/// Only the project owner can reopen a completed task.
#[tokio::test]
async fn project_owner_can_reopen_done_task() {
    let response = task_request(
        app(),
        Method::PATCH,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(1),
        Some(r#"{"status":"in_progress"}"#),
    )
    .await;
    assert_eq!(response.status(), StatusCode::OK);
    let task: TaskView =
        serde_json::from_value(response_json(response).await).expect("reopened task");
    assert_eq!(task.status, TaskStatus::InProgress);
}

/// A member from another project cannot read a guessed task identifier.
#[tokio::test]
async fn cross_project_guessed_task_is_hidden() {
    let response = task_request(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(4),
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::NOT_FOUND);
    assert_eq!(
        response_json(response).await["code"],
        "resource_unavailable"
    );
}

/// The path project must match the task's stored parent even when the caller owns its real project.
#[tokio::test]
async fn project_path_cannot_be_swapped_for_another_task() {
    let response = task_request(
        app(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-202",
        Some(4),
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::NOT_FOUND);
}

/// Missing and unauthorized task references share the same public response.
#[tokio::test]
async fn missing_and_invisible_tasks_share_error_contract() {
    let router = app();
    let invisible = task_request(
        router.clone(),
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(4),
        None,
    )
    .await;
    let missing = task_request(
        router,
        Method::GET,
        "/api/v1/projects/project-1/tasks/task-999",
        Some(1),
        None,
    )
    .await;
    assert_eq!(invisible.status(), StatusCode::NOT_FOUND);
    assert_eq!(missing.status(), StatusCode::NOT_FOUND);
    assert_eq!(response_json(invisible).await, response_json(missing).await);
}

/// A request body cannot mass-assign a project role or change a later authorization decision.
#[tokio::test]
async fn client_cannot_assign_its_own_project_role() {
    let router = app();
    let forged = task_request(
        router.clone(),
        Method::PATCH,
        "/api/v1/projects/project-1/tasks/task-102",
        Some(2),
        Some(r#"{"title":"forged role","role":"owner"}"#),
    )
    .await;
    assert_eq!(forged.status(), StatusCode::UNPROCESSABLE_ENTITY);

    let still_forbidden = task_request(
        router,
        Method::PATCH,
        "/api/v1/projects/project-1/tasks/task-101",
        Some(2),
        Some(r#"{"status":"in_progress"}"#),
    )
    .await;
    assert_eq!(still_forbidden.status(), StatusCode::NOT_FOUND);
}
