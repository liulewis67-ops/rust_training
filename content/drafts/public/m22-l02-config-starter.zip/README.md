# M22-L02 configuration and secrets starter

Run `cargo test --locked` on Windows to observe the deliberately unsafe fallback, secret Debug output, and invalid bind address behavior. The parser accepts a synthetic settings map so tests never modify process-global environment variables or read real credentials. The fixed reference should pass both debug and release tests after repair. No secret provider, Docker engine, or container is used.
