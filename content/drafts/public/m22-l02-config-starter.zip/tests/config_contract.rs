use std::collections::BTreeMap;

use m22_l02_config::{ConfigError, parse_config};

fn settings(database_url: &str, bind_addr: &str) -> BTreeMap<String, String> {
    BTreeMap::from([
        ("APP_DATABASE_URL".to_owned(), database_url.to_owned()),
        ("APP_BIND_ADDR".to_owned(), bind_addr.to_owned()),
        (
            "APP_API_TOKEN_FILE".to_owned(),
            "/run/secrets/api_token".to_owned(),
        ),
    ])
}

/// Missing required settings fail closed instead of selecting a demo credential.
#[test]
fn missing_required_settings_fail_closed() {
    assert_eq!(
        parse_config(&BTreeMap::new(), None),
        Err(ConfigError::Missing("APP_DATABASE_URL")),
    );
}

/// The token is obtained from the mounted secret file and not an environment value.
#[test]
fn reads_secret_file_contents_and_trims_line_ending() {
    let config = parse_config(
        &settings("postgres://db.internal/app", "127.0.0.1:8080"),
        Some("sentinel-token\n"),
    )
    .expect("valid synthetic configuration");

    assert_eq!(config.api_token.expose_secret(), "sentinel-token");
}

/// Config Debug output must not disclose the secret sentinel.
#[test]
fn config_debug_redacts_secret() {
    let config = parse_config(
        &settings("postgres://db.internal/app", "127.0.0.1:8080"),
        Some("sentinel-token"),
    )
    .expect("valid synthetic configuration");

    let rendered = format!("{config:?}");
    assert!(rendered.contains("[REDACTED]"));
    assert!(!rendered.contains("demo-token"));
    assert!(!rendered.contains("sentinel-token"));
}

/// Invalid values produce a stable field error without echoing the input.
#[test]
fn invalid_bind_address_is_rejected_without_echoing_value() {
    let error = parse_config(
        &settings("postgres://db.internal/app", "credential-sentinel"),
        Some("token-sentinel"),
    )
    .expect_err("invalid socket address must fail startup");
    let rendered = format!("{error}");

    assert_eq!(error, ConfigError::Invalid("APP_BIND_ADDR"));
    assert!(!rendered.contains("credential-sentinel"));
    assert!(!rendered.contains("token-sentinel"));
}
