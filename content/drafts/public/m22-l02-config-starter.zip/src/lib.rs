//! M22-L02 deployment configuration and secret injection exercise.

use std::collections::BTreeMap;
use std::fmt;
use std::net::SocketAddr;

/// Parsed service configuration. The starter intentionally exposes its token in Debug.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Config {
    /// Validated listener address.
    pub bind_addr: SocketAddr,
    /// Database resource address supplied by the deployment.
    pub database_url: String,
    /// Secret token loaded from the declared secret file.
    pub api_token: SecretString,
}

/// Secret wrapper; the starter intentionally has a leaking Debug implementation.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SecretString(String);

impl SecretString {
    /// Exposes the value to the specific client that needs to authenticate.
    #[must_use]
    pub fn expose_secret(&self) -> &str {
        &self.0
    }
}

/// Configuration errors should name a setting without disclosing its value.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ConfigError {
    /// A required deployment setting was not supplied.
    Missing(&'static str),
    /// A supplied setting did not satisfy its contract.
    Invalid(&'static str),
}

impl fmt::Display for ConfigError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Missing(name) => write!(formatter, "required setting {name} is missing"),
            Self::Invalid(name) => write!(formatter, "setting {name} is invalid"),
        }
    }
}

impl std::error::Error for ConfigError {}

/// Parses deployment settings and synthetic secret-file contents.
///
/// This baseline intentionally has unsafe defaults and does not validate values.
pub fn parse_config(
    _settings: &BTreeMap<String, String>,
    _token_file_contents: Option<&str>,
) -> Result<Config, ConfigError> {
    Ok(Config {
        bind_addr: "127.0.0.1:3000".parse().expect("static address"),
        database_url: "postgres://demo:demo@localhost/app".to_owned(),
        api_token: SecretString("demo-token".to_owned()),
    })
}
