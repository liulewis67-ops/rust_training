# M21-L06 independent observability check starter

Use only `variant.json` and `submission-template.md` to prepare an independent report. Do not inspect private answers before submitting. The variant is deliberately different from the M21-L05 synthetic pool/query/queue cards. Restore a fresh attempt from `../m21-l06-check-starter.zip` and verify every `starter-manifest.json` entry first. This package has no evaluator and cannot issue skill evidence.
