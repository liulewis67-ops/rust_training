# Independent diagnosis report

## Immutable attempt identity

- Course/check version:
- Starter ZIP and manifest SHA-256:
- Evaluator version (assigned by platform):
- Attempt number:
- Answer viewed before this submission: yes / no

## SLI calculations

| Boundary | good / eligible | ppm | target ppm | met? | Included/excluded event categories |
|---|---:|---:|---:|---|---|
| API | | | | | |
| Runner | | | | | |

## Accepted request and execution lifecycle

- What does 202 confirm?
- What remains unknown about background delivery?
- Which runner outcomes show platform availability?

## Queue evidence and hypothesis

- Observed facts with units/window:
- Falsifiable hypothesis:
- Alternative explanation:
- Evidence needed to confirm root cause:
- What result would disconfirm the hypothesis?

## Signal design

- Finite metric dimensions:
- High-cardinality IDs and their permitted diagnostic signal:
- Sensitive values excluded:

## Controlled experiment and regression

- One variable to change:
- Predicted signals:
- Rollback/reset plan:
- Regression case:
- Limitation / platform evidence boundary:
