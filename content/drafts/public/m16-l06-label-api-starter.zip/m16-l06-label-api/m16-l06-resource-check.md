# M16-L06 独立检查：实现一个陌生资源接口

## 检查任务

不看本课答案，使用 Axum starter 实现 Label API。资源不同于前面的 Task API；评分不接受固定 ID、固定 response 或只对公开样例硬编码的实现。

### API contract

| Method / path | Contract |
|---|---|
| `GET /labels` | `200`，JSON label 数组按 `name` 排序 |
| `POST /labels` | JSON `{ "name": "...", "color": "#RRGGBB" }`；创建成功 `201` + 指向新 label 的 `Location` + JSON representation；重复名称 `409`；非法 name/color `422` |
| `GET /labels/{name}` | 存在返回 `200` + label；不存在 `404` |
| `DELETE /labels/{name}` | 删除成功 `204` 且无 body；不存在 `404` |
| 已有 path 上不支持的 method | `405` 且 `Allow` 准确 |

`name` 是 1–24 个小写 ASCII 字母、数字或单个连字符连接的 slug；不得以连字符开头/结尾或包含连续连字符。`color` 必须是 `#` 后恰好六个 ASCII 十六进制字符。API 对 name 比较大小写敏感。

Starter 初始有 `blue` 和 `orange` 两种 label。测试会使用未在 seed 中出现的新名字、改变创建顺序、重复创建、缺失资源和非法颜色，以区分动态资源行为与固定响应。

## 提交步骤

1. 阅读 `content/drafts/public/m16-l06-label-api/README.md` 和 `starter-manifest.json`；运行 `cargo test` 留存起始错误。
2. 从 Router/handler 输入与 response contract 推导实现，不依赖 endpoint 对固定字符串做分支。
3. 增补至少一项自己设计的陌生 slug 和一种非法输入测试。
4. 运行格式化、check、公开测试、严格 Clippy 和 Rustdoc；用全新 starter ZIP 重跑 baseline。
5. 记录提交快照、题包版本、变式输入、测试输出与结果。正式技能评价只计算未查看私有参考的独立提交。

## 起始故障反馈

公开 baseline 的失败指向 `GET /labels/{name}` 没按 path 中的 name 返回对应资源。检查查找逻辑是否使用了 handler 收到的 `name`，以及查无资源时是否为 404。公开信息不会暴露隐藏 slug、颜色边界或全部私有评分规则。

这是作者侧检查设计与参考实现，不代表已经有独立学习者技能证据；I09-F02、R3 与正式课程门槛仍未完成。
