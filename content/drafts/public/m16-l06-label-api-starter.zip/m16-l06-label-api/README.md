# M16-L06 unfamiliar resource check starter

The Axum 0.8.9 starter contains one intentional hard-coded item response. Run `cargo test`, inspect the failing path-variation tests, and implement the contract from `m16-l06-resource-check.md`. The ZIP and starter manifest provide a clean, traceable reset point.
