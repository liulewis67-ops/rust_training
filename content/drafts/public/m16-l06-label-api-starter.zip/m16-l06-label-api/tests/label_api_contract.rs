//! Public behavior checks for the unfamiliar Label resource contract.

use axum::body::{Body, to_bytes};
use axum::http::{Method, Request, StatusCode};
use m16_l06_label_api::app;
use tower::ServiceExt;

/// Sends a request through the complete label router.
async fn send(
    router: &axum::Router,
    method: Method,
    uri: &str,
    body: Body,
) -> axum::response::Response {
    router
        .clone()
        .oneshot(
            Request::builder()
                .method(method)
                .uri(uri)
                .header("content-type", "application/json")
                .body(body)
                .unwrap(),
        )
        .await
        .unwrap()
}

/// Reads a small label JSON representation.
async fn json(response: axum::response::Response) -> serde_json::Value {
    let bytes = to_bytes(response.into_body(), usize::MAX).await.unwrap();
    serde_json::from_slice(&bytes).unwrap()
}

/// Reads a seeded item that differs from the starter's fixed response.
#[tokio::test]
async fn path_selects_the_requested_seeded_resource() {
    let router = app();
    let response = send(&router, Method::GET, "/labels/orange", Body::empty()).await;
    assert_eq!(response.status(), StatusCode::OK);
    let label = json(response).await;
    assert_eq!(label["name"], "orange");
    assert_eq!(label["color"], "#FF8800");
}

/// Keeps the collection sorted and missing item explicit.
#[tokio::test]
async fn collection_and_missing_item_are_deterministic() {
    let router = app();
    let response = send(&router, Method::GET, "/labels", Body::empty()).await;
    assert_eq!(response.status(), StatusCode::OK);
    let labels = json(response).await;
    assert_eq!(labels[0]["name"], "blue");
    assert_eq!(labels[1]["name"], "orange");
    assert_eq!(
        send(&router, Method::GET, "/labels/not-seeded", Body::empty())
            .await
            .status(),
        StatusCode::NOT_FOUND
    );
}

/// Checks a new name and color do not receive a hard-coded representation.
#[tokio::test]
async fn create_then_read_uses_the_new_resource_values() {
    let router = app();
    let created = send(
        &router,
        Method::POST,
        "/labels",
        Body::from(r##"{"name":"forest","color":"#17A35B"}"##),
    )
    .await;
    assert_eq!(created.status(), StatusCode::CREATED);
    assert_eq!(created.headers().get("location").unwrap(), "/labels/forest");
    assert_eq!(json(created).await["color"], "#17A35B");

    let read_back = send(&router, Method::GET, "/labels/forest", Body::empty()).await;
    assert_eq!(read_back.status(), StatusCode::OK);
    assert_eq!(json(read_back).await["name"], "forest");
}

/// Rejects malformed color/slug data and duplicate names with distinct statuses.
#[tokio::test]
async fn create_validation_and_duplicate_contract() {
    let router = app();
    for invalid in [
        r##"{"name":"Bad Name","color":"#17A35B"}"##,
        r##"{"name":"lime","color":"green"}"##,
    ] {
        assert_eq!(
            send(&router, Method::POST, "/labels", Body::from(invalid))
                .await
                .status(),
            StatusCode::UNPROCESSABLE_ENTITY
        );
    }
    assert_eq!(
        send(
            &router,
            Method::POST,
            "/labels",
            Body::from(r##"{"name":"blue","color":"#0000FF"}"##),
        )
        .await
        .status(),
        StatusCode::CONFLICT
    );
}

/// Deletes an existing label and handles a disallowed method through Axum.
#[tokio::test]
async fn delete_and_method_mismatch_contract() {
    let router = app();
    let deleted = send(&router, Method::DELETE, "/labels/orange", Body::empty()).await;
    assert_eq!(deleted.status(), StatusCode::NO_CONTENT);
    assert!(
        to_bytes(deleted.into_body(), usize::MAX)
            .await
            .unwrap()
            .is_empty()
    );
    assert_eq!(
        send(&router, Method::GET, "/labels/orange", Body::empty())
            .await
            .status(),
        StatusCode::NOT_FOUND
    );

    let unsupported = send(&router, Method::PUT, "/labels/blue", Body::empty()).await;
    assert_eq!(unsupported.status(), StatusCode::METHOD_NOT_ALLOWED);
    assert!(unsupported.headers().contains_key("allow"));
}
