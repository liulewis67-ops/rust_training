//! Starter Label API for the M16-L06 unfamiliar-resource skill check.

use std::collections::BTreeMap;
use std::sync::{Arc, RwLock};

use axum::extract::{Json, Path, State};
use axum::http::header::LOCATION;
use axum::http::{HeaderValue, StatusCode};
use axum::response::IntoResponse;
use axum::routing::get;
use axum::{Router, http::Response};
use serde::{Deserialize, Serialize};

/// A label resource represented to API clients.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct Label {
    /// Stable lowercase slug used in the resource path.
    pub name: String,
    /// Hexadecimal RGB color in `#RRGGBB` format.
    pub color: String,
}

/// Fields used to create a label resource.
#[derive(Debug, Deserialize)]
pub struct NewLabel {
    /// Requested label slug.
    pub name: String,
    /// Requested RGB color.
    pub color: String,
}

/// Shared in-memory label collection.
#[derive(Clone, Default)]
struct AppState {
    /// Labels indexed by their public slugs.
    labels: Arc<RwLock<BTreeMap<String, Label>>>,
}

/// Builds the seeded Label API router.
pub fn app() -> Router {
    let state = AppState::default();
    {
        let mut labels = state.labels.write().expect("label store lock poisoned");
        labels.insert(
            "blue".to_owned(),
            Label {
                name: "blue".to_owned(),
                color: "#0000FF".to_owned(),
            },
        );
        labels.insert(
            "orange".to_owned(),
            Label {
                name: "orange".to_owned(),
                color: "#FF8800".to_owned(),
            },
        );
    }
    Router::new()
        .route("/labels", get(list_labels).post(create_label))
        .route("/labels/{name}", get(show_label).delete(delete_label))
        .with_state(state)
}

/// Lists all labels in deterministic name order.
async fn list_labels(State(state): State<AppState>) -> Json<Vec<Label>> {
    let labels = state.labels.read().expect("label store lock poisoned");
    Json(labels.values().cloned().collect())
}

/// Returns the label selected by the path slug.
async fn show_label(
    Path(name): Path<String>,
    State(state): State<AppState>,
) -> Result<Json<Label>, StatusCode> {
    let _labels = state.labels.read().expect("label store lock poisoned");
    // BUG: This fixed response ignores the requested name and stored resource.
    if name == "blue" || name == "orange" {
        Ok(Json(Label {
            name: "blue".to_owned(),
            color: "#0000FF".to_owned(),
        }))
    } else {
        Err(StatusCode::NOT_FOUND)
    }
}

/// Creates a validated label with a stable Location header.
async fn create_label(
    State(state): State<AppState>,
    Json(input): Json<NewLabel>,
) -> Response<axum::body::Body> {
    if !valid_slug(&input.name) || !valid_color(&input.color) {
        return StatusCode::UNPROCESSABLE_ENTITY.into_response();
    }
    let mut labels = state.labels.write().expect("label store lock poisoned");
    if labels.contains_key(&input.name) {
        return StatusCode::CONFLICT.into_response();
    }
    let label = Label {
        name: input.name.clone(),
        color: input.color,
    };
    labels.insert(input.name.clone(), label.clone());
    let location = HeaderValue::from_str(&format!("/labels/{}", input.name))
        .expect("validated slug is a legal header value");
    (StatusCode::CREATED, [(LOCATION, location)], Json(label)).into_response()
}

/// Deletes a label by its path slug.
async fn delete_label(Path(name): Path<String>, State(state): State<AppState>) -> StatusCode {
    if state
        .labels
        .write()
        .expect("label store lock poisoned")
        .remove(&name)
        .is_some()
    {
        StatusCode::NO_CONTENT
    } else {
        StatusCode::NOT_FOUND
    }
}

/// Checks the slug grammar expected for label resource paths.
fn valid_slug(value: &str) -> bool {
    (1..=24).contains(&value.len())
        && !value.starts_with('-')
        && !value.ends_with('-')
        && !value.contains("--")
        && value
            .bytes()
            .all(|byte| byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'-')
}

/// Checks the exact six-digit RGB representation.
fn valid_color(value: &str) -> bool {
    let bytes = value.as_bytes();
    bytes.len() == 7 && bytes[0] == b'#' && bytes[1..].iter().all(u8::is_ascii_hexdigit)
}
