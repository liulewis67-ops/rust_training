//! M21-L01 的 Axum request correlation 与结构化日志练习。

use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Instant;

use axum::body::Body;
use axum::extract::{Extension, Path, Request};
use axum::http::{HeaderName, HeaderValue, StatusCode};
use axum::middleware::{self, Next};
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::{Json, Router};
use serde::Serialize;
use tracing::Instrument;

const REQUEST_ID: HeaderName = HeaderName::from_static("x-request-id");

/// 已在 middleware 验证/生成并贯穿请求和响应的关联上下文。
#[derive(Clone, Debug)]
struct RequestContext {
    /// response 与 tracing 事件共用的非敏感 request ID。
    request_id: String,
    /// HTTP method，用于有限枚举形式的事件字段。
    method: String,
}

/// 允许从不可信上游请求头接收的 request-id token。
fn valid_request_id(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= 64
        && value
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || byte == b'-' || byte == b'_')
}

/// 为本机 fixture 生成确定性 ID；生产服务须换成足够随机且经过评审的策略。
fn generated_request_id() -> String {
    static NEXT_ID: AtomicU64 = AtomicU64::new(1);
    format!("req-local-{:016x}", NEXT_ID.fetch_add(1, Ordering::Relaxed))
}

/// 构建带请求上下文的 API Router。
pub fn app() -> Router {
    Router::new()
        .route("/users/{id}", get(show_user))
        .layer(middleware::from_fn(request_context))
}

/// 为成功与失败 response 一致建立 ID、span 和完成事件。
async fn request_context(mut request: Request<Body>, next: Next) -> Response {
    let request_id = request
        .headers()
        .get(&REQUEST_ID)
        .and_then(|value| value.to_str().ok())
        .filter(|value| valid_request_id(value))
        .map_or_else(generated_request_id, str::to_owned);
    let method = request.method().as_str().to_owned();
    let auth = request
        .headers()
        .get("authorization")
        .and_then(|value| value.to_str().ok())
        .unwrap_or("absent")
        .to_owned();
    let context = RequestContext {
        request_id: request_id.clone(),
        method: method.clone(),
    };
    request.extensions_mut().insert(context.clone());
    let started = Instant::now();
    let span = tracing::info_span!(
        "http.request",
        request_id = %request_id,
        http_request_method = %method,
        http_route = "/users/{id}",
    );
    let mut response = next.run(request).instrument(span.clone()).await;
    if let Ok(value) = HeaderValue::from_str(&request_id) {
        response.headers_mut().insert(REQUEST_ID.clone(), value);
    }
    let status = response.status().as_u16();
    // TODO(M21-L01): 拼接日志丢失字段类型，还会把认证头写入日志。
    tracing::info!(
        parent: &span,
        message = %format!(
            "request_id={request_id} method={method} route=/users/{{id}} status={status} auth={auth}"
        ),
        "request finished"
    );
    let _elapsed_ms = started.elapsed().as_millis() as u64;
    response
}

/// 对外错误体提供稳定 code/message 和 request ID，不包含内部诊断。
#[derive(Serialize)]
struct ErrorBody {
    /// 稳定错误分类。
    code: &'static str,
    /// 可供客户端安全展示的简短信息。
    message: &'static str,
    /// 与 response header 和 request span 一致的关联 ID。
    request_id: String,
}

/// Handles one fixture user and associates handler events with the request span.
async fn show_user(
    Extension(context): Extension<RequestContext>,
    Path(raw_id): Path<String>,
) -> Response {
    let (status, body) = match raw_id.as_str() {
        "42" => {
            tracing::info!(
                request_id = %context.request_id,
                route = "/users/{id}",
                outcome = "found",
                "user lookup completed"
            );
            return Json(serde_json::json!({"id": 42, "name": "Ada"})).into_response();
        }
        "offline" => (
            StatusCode::SERVICE_UNAVAILABLE,
            ErrorBody {
                code: "service_unavailable",
                message: "service temporarily unavailable",
                request_id: context.request_id.clone(),
            },
        ),
        _ => (
            StatusCode::NOT_FOUND,
            ErrorBody {
                code: "not_found",
                message: "user was not found",
                request_id: context.request_id.clone(),
            },
        ),
    };
    tracing::warn!(
        request_id = %context.request_id,
        method = %context.method,
        route = "/users/{id}",
        outcome = body.code,
        "user request failed"
    );
    (status, Json(body)).into_response()
}
