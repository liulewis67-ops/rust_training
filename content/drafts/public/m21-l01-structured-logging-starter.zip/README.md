# M21-L01 structured logging starter

在 Windows 原生环境运行 `cargo test --locked` 观察 baseline；其中不通过的字段合同是本练习目标。发行快照为同目录的 `m21-l01-structured-logging-starter.zip`。新尝试从原始 ZIP 解压，先核对 `starter-manifest.json`。本地自定义 Subscriber 验证 tracing fields，不连接数据库、Linux 容器或生产 collector。
