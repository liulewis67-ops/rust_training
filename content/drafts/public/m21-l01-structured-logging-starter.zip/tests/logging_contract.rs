use std::fmt::Debug;
use std::sync::{Arc, Mutex};

use axum::body::{Body, to_bytes};
use axum::http::{Request, StatusCode};
use m21_l01_structured_logging::app;
use tower::ServiceExt;
use tracing::field::{Field, Visit};
use tracing::{Event, Id, Metadata, Subscriber};

#[derive(Clone)]
struct CaptureSubscriber(Arc<Mutex<Vec<String>>>);

impl Subscriber for CaptureSubscriber {
    /// Lets the local author fixture observe every event under test.
    fn enabled(&self, _: &Metadata<'_>) -> bool {
        true
    }

    /// Creates a stable fixture span identifier.
    fn new_span(&self, _: &tracing::span::Attributes<'_>) -> Id {
        Id::from_u64(1)
    }

    /// Ignores later span-field updates in this event-focused capture.
    fn record(&self, _: &Id, _: &tracing::span::Record<'_>) {}

    /// Ignores explicit span links in this local fixture.
    fn record_follows_from(&self, _: &Id, _: &Id) {}

    /// Captures event fields separately so tests do not parse terminal formatting.
    fn event(&self, event: &Event<'_>) {
        let mut visitor = FieldCapture::default();
        event.record(&mut visitor);
        if let Ok(mut fields) = self.0.lock() {
            fields.extend(visitor.0);
        }
    }

    /// Does not add behavior when a span is entered.
    fn enter(&self, _: &Id) {}

    /// Does not add behavior when a span is exited.
    fn exit(&self, _: &Id) {}
}

#[derive(Default)]
struct FieldCapture(Vec<String>);

impl Visit for FieldCapture {
    /// Stores a field name and debug value as one test observation.
    fn record_debug(&mut self, field: &Field, value: &dyn Debug) {
        self.0.push(format!("{}={value:?}", field.name()));
    }
}

/// Sends a request with sentinels and returns status, response, and observed tracing fields.
async fn send(id: &str, uri: &str) -> (StatusCode, axum::http::HeaderMap, String, Vec<String>) {
    let captured = Arc::new(Mutex::new(Vec::new()));
    let guard = tracing::subscriber::set_default(CaptureSubscriber(Arc::clone(&captured)));
    let response = app()
        .oneshot(
            Request::get(uri)
                .header("x-request-id", id)
                .header("authorization", "Bearer auth-secret-sentinel")
                .header("cookie", "session=cookie-secret-sentinel")
                .body(Body::from("body-secret-sentinel"))
                .expect("build request"),
        )
        .await
        .expect("run router");
    let status = response.status();
    let headers = response.headers().clone();
    let body = String::from_utf8_lossy(
        &to_bytes(response.into_body(), usize::MAX)
            .await
            .expect("read response body"),
    )
    .to_string();
    drop(guard);
    let fields = captured.lock().expect("captured fields").clone();
    (status, headers, body, fields)
}

/// Requires the response ID and independently queryable fields to share one request context.
#[tokio::test(flavor = "current_thread")]
async fn exposes_correlated_structured_fields() {
    let (status, headers, _, fields) = send("req-observe-5", "/users/42").await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(headers["x-request-id"], "req-observe-5");
    let output = fields.join(" ");
    assert!(output.contains("request_id=\"req-observe-5\""));
    assert!(output.contains("http_route=\"/users/{id}\""));
    assert!(output.contains("http_response_status_code=200"));
    assert!(output.contains("duration_ms="));
    assert!(output.contains("outcome=\"found\""));
}

/// Requires failed requests to keep the same request ID and final response status in the log.
#[tokio::test(flavor = "current_thread")]
async fn correlates_error_response_and_log_status() {
    let (status, headers, body, fields) = send("req-error-8", "/users/missing").await;
    assert_eq!(status, StatusCode::NOT_FOUND);
    assert_eq!(headers["x-request-id"], "req-error-8");
    assert!(body.contains("req-error-8"));
    let output = fields.join(" ");
    assert!(output.contains("request_id=\"req-error-8\""));
    assert!(output.contains("http_response_status_code=404"));
}

/// Rejects credentials and bodies from all observed tracing event fields.
#[tokio::test(flavor = "current_thread")]
async fn never_logs_auth_cookie_or_request_body() {
    let (_, _, _, fields) = send("req-safe-1", "/users/offline").await;
    let output = fields.join(" ");
    assert!(!output.contains("auth-secret-sentinel"));
    assert!(!output.contains("cookie-secret-sentinel"));
    assert!(!output.contains("body-secret-sentinel"));
}

/// Requires route fields to use a template instead of a specific path resource ID.
#[tokio::test(flavor = "current_thread")]
async fn logs_route_template_not_dynamic_user_id() {
    let (_, _, _, fields) = send("req-route-3", "/users/98765").await;
    let output = fields.join(" ");
    assert!(output.contains("/users/{id}"));
    assert!(!output.contains("98765"));
}

/// Replaces malformed upstream request IDs and associates the generated value with errors.
#[tokio::test(flavor = "current_thread")]
async fn generates_safe_id_when_header_is_invalid() {
    let response = app()
        .oneshot(
            Request::get("/users/offline")
                .header("x-request-id", "bad=value")
                .body(Body::empty())
                .expect("build invalid-id request"),
        )
        .await
        .expect("run router");
    assert_eq!(response.status(), StatusCode::SERVICE_UNAVAILABLE);
    let request_id = response.headers()["x-request-id"]
        .to_str()
        .expect("valid response ID")
        .to_owned();
    assert!(request_id.starts_with("req-local-"));
    let body = to_bytes(response.into_body(), usize::MAX)
        .await
        .expect("read response body");
    assert!(String::from_utf8_lossy(&body).contains(&request_id));
}
