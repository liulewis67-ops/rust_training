use m23_l01_sample_summary_starter::{
    Distribution, ReportError, RunMetadata, SummaryError, summarize,
};

fn valid_metadata() -> RunMetadata {
    RunMetadata {
        benchmark_id: "json-parse-v1".into(),
        workload_id: "fixture-64k".into(),
        source_revision: "0123456789abcdef".into(),
        rustc: "rustc 1.95.0".into(),
        profile: "bench".into(),
        target: "x86_64-pc-windows-msvc".into(),
        build_flags: "defaults".into(),
        features: "none".into(),
        cargo_lock_sha256: "b".repeat(64),
        cpu_model: "Example CPU".into(),
        operating_system: "Windows 11".into(),
        fixture_sha256: "a".repeat(64),
        warmup_iterations: 3,
        measured_samples: 5,
    }
}

#[test]
fn empty_input_is_an_error() {
    assert_eq!(summarize(&[]), Err(SummaryError::EmptySamples));
}

#[test]
fn singleton_summary_preserves_its_only_value() {
    assert_eq!(
        summarize(&[17]).unwrap(),
        Distribution {
            count: 1,
            min_ns: 17,
            median_ns: 17,
            p95_ns: 17,
            mean_ns: 17,
        }
    );
}

#[test]
fn even_median_rounds_down_and_input_is_sorted_for_summary() {
    let summary = summarize(&[9, 2, 8, 3]).unwrap();
    assert_eq!(summary.min_ns, 2);
    assert_eq!(summary.median_ns, 5);
    assert_eq!(summary.mean_ns, 5);
}

#[test]
fn p95_uses_nearest_rank_for_twenty_samples() {
    let samples: Vec<u64> = (1..=20).collect();
    assert_eq!(summarize(&samples).unwrap().p95_ns, 19);
}

#[test]
fn valid_report_metadata_is_accepted() {
    assert_eq!(valid_metadata().validate(5), Ok(()));
}

#[test]
fn debug_profile_is_rejected() {
    let mut metadata = valid_metadata();
    metadata.profile = "debug".into();
    assert_eq!(metadata.validate(5), Err(ReportError::UnsupportedProfile));
}

#[test]
fn missing_environment_and_bad_hash_are_rejected() {
    let mut metadata = valid_metadata();
    metadata.cpu_model.clear();
    assert_eq!(
        metadata.validate(5),
        Err(ReportError::MissingField("cpu_model"))
    );

    let mut metadata = valid_metadata();
    metadata.fixture_sha256 = "not-a-sha256".into();
    assert_eq!(metadata.validate(5), Err(ReportError::InvalidFixtureHash));

    let mut metadata = valid_metadata();
    metadata.cargo_lock_sha256 = "not-a-sha256".into();
    assert_eq!(metadata.validate(5), Err(ReportError::InvalidCargoLockHash));
}

#[test]
fn cargo_lock_hash_must_be_lowercase_sha256() {
    let mut metadata = valid_metadata();
    metadata.cargo_lock_sha256 = "B".repeat(64);
    assert_eq!(metadata.validate(5), Err(ReportError::InvalidCargoLockHash));
}

#[test]
fn warmup_and_sample_minimums_are_enforced() {
    let mut metadata = valid_metadata();
    metadata.warmup_iterations = 2;
    assert_eq!(metadata.validate(5), Err(ReportError::WarmupTooSmall));

    let mut metadata = valid_metadata();
    metadata.measured_samples = 4;
    assert_eq!(
        metadata.validate(4),
        Err(ReportError::TooFewMeasuredSamples)
    );
}

#[test]
fn declared_sample_count_must_match_the_observations() {
    assert_eq!(
        valid_metadata().validate(6),
        Err(ReportError::SampleCountMismatch)
    );
}
