//! Small report-contract exercise; it does not run or time the workload.

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Distribution {
    pub count: usize,
    pub min_ns: u64,
    pub median_ns: u64,
    pub p95_ns: u64,
    pub mean_ns: u64,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum SummaryError {
    EmptySamples,
}

/// Summarize raw nanosecond samples without removing any observation.
pub fn summarize(samples: &[u64]) -> Result<Distribution, SummaryError> {
    if samples.is_empty() {
        return Err(SummaryError::EmptySamples);
    }

    let mut sorted = samples.to_vec();
    sorted.sort_unstable();
    let count = sorted.len();
    let median_ns = if count % 2 == 0 {
        ((u128::from(sorted[count / 2 - 1]) + u128::from(sorted[count / 2])) / 2) as u64
    } else {
        sorted[count / 2]
    };

    // Exercise defect: this is an incorrect zero-based rank for some sample counts.
    let p95_index = count * 95 / 100;
    let total: u128 = sorted.iter().map(|value| u128::from(*value)).sum();

    Ok(Distribution {
        count,
        min_ns: sorted[0],
        median_ns,
        p95_ns: sorted[p95_index],
        mean_ns: (total / count as u128) as u64,
    })
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RunMetadata {
    pub benchmark_id: String,
    pub workload_id: String,
    pub source_revision: String,
    pub rustc: String,
    pub profile: String,
    pub target: String,
    pub build_flags: String,
    pub features: String,
    pub cargo_lock_sha256: String,
    pub cpu_model: String,
    pub operating_system: String,
    pub fixture_sha256: String,
    pub warmup_iterations: usize,
    pub measured_samples: usize,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ReportError {
    MissingField(&'static str),
    UnsupportedProfile,
    InvalidFixtureHash,
    InvalidCargoLockHash,
    WarmupTooSmall,
    TooFewMeasuredSamples,
    SampleCountMismatch,
}

impl RunMetadata {
    /// Validate metadata against the exercise's report contract.
    pub fn validate(&self, actual_sample_count: usize) -> Result<(), ReportError> {
        if self.measured_samples != actual_sample_count {
            return Err(ReportError::SampleCountMismatch);
        }

        // Exercise defect: required fields, profile, hashes, and minimums are unchecked.
        Ok(())
    }
}
