# M23-L01 benchmark report starter

This crate is an exercise fixture with two intentional gaps:

1. The p95 array index does not follow the documented nearest-rank contract.
2. `RunMetadata::validate` checks sample count but does not yet enforce report provenance and environment requirements.

Use the three exercise contracts from the M23-L01 course package. Keep every raw sample. Run `cargo test --locked` after fixing the starter. A passing summary function does not establish a valid benchmark protocol or target-environment performance result.
