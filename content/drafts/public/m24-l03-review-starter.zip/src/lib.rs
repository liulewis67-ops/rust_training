//! Contracts for actionable code review and dependency compatibility checks.

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ReviewFinding {
    pub title: String,
    pub location: String,
    pub observed_behavior: String,
    pub expected_contract: String,
    pub reproduction: String,
    pub impact: String,
    pub evidence_ids: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum FindingError {
    MissingTitle,
    MissingLocation,
    MissingObservedBehavior,
    MissingExpectedContract,
    MissingReproduction,
    MissingImpact,
    MissingEvidence,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CompatibilityCheck {
    OldClientNewService,
    NewClientOldService,
    OldDataNewCode,
    RollbackDataCompatibility,
}

const REQUIRED_CHECKS: [CompatibilityCheck; 4] = [
    CompatibilityCheck::OldClientNewService,
    CompatibilityCheck::NewClientOldService,
    CompatibilityCheck::OldDataNewCode,
    CompatibilityCheck::RollbackDataCompatibility,
];

/// Validate that a review finding has enough evidence to guide a concrete change.
pub fn validate_finding(finding: &ReviewFinding) -> Result<(), FindingError> {
    if finding.title.trim().is_empty() {
        return Err(FindingError::MissingTitle);
    }
    if finding.location.trim().is_empty() {
        return Err(FindingError::MissingLocation);
    }
    if finding.observed_behavior.trim().is_empty() {
        return Err(FindingError::MissingObservedBehavior);
    }
    if finding.expected_contract.trim().is_empty() {
        return Err(FindingError::MissingExpectedContract);
    }
    if finding.reproduction.trim().is_empty() {
        return Err(FindingError::MissingReproduction);
    }
    let _ = finding;
    Ok(())
}

/// Report required consumer/data compatibility checks that are not covered.
pub fn missing_compatibility_checks(present: &[CompatibilityCheck]) -> Vec<CompatibilityCheck> {
    let _ = present;
    let _ = REQUIRED_CHECKS;
    Vec::new()
}
