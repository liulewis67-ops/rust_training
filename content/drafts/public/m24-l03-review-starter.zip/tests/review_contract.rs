use m24_l03_review_starter::{
    CompatibilityCheck, FindingError, ReviewFinding, missing_compatibility_checks, validate_finding,
};

/// Build a finding with reproducible behavior and linked evidence.
fn valid_finding() -> ReviewFinding {
    ReviewFinding {
        title: "Project membership is not checked".into(),
        location: "src/api/tasks.rs:42".into(),
        observed_behavior: "A member of project A can read project B tasks".into(),
        expected_contract: "Only project members can read that project's tasks".into(),
        reproduction: "Authenticate as A, request B's task URL".into(),
        impact: "Cross-project data exposure".into(),
        evidence_ids: vec!["TEST-SEC-42".into()],
    }
}

/// Accept a complete actionable finding.
#[test]
fn accepts_complete_finding() {
    assert_eq!(validate_finding(&valid_finding()), Ok(()));
}

/// Reject a finding without an impact explanation.
#[test]
fn rejects_missing_impact() {
    let mut finding = valid_finding();
    finding.impact.clear();
    assert_eq!(validate_finding(&finding), Err(FindingError::MissingImpact));
}

/// Reject a finding without regression evidence.
#[test]
fn rejects_missing_evidence() {
    let mut finding = valid_finding();
    finding.evidence_ids.clear();
    assert_eq!(
        validate_finding(&finding),
        Err(FindingError::MissingEvidence)
    );
}

/// Report all missing compatibility checks in their contract order.
#[test]
fn reports_empty_compatibility_matrix() {
    assert_eq!(
        missing_compatibility_checks(&[]),
        vec![
            CompatibilityCheck::OldClientNewService,
            CompatibilityCheck::NewClientOldService,
            CompatibilityCheck::OldDataNewCode,
            CompatibilityCheck::RollbackDataCompatibility,
        ]
    );
}

/// Do not report compatibility checks already covered by the evidence.
#[test]
fn reports_only_uncovered_compatibility_checks() {
    assert_eq!(
        missing_compatibility_checks(&[
            CompatibilityCheck::OldClientNewService,
            CompatibilityCheck::OldDataNewCode,
        ]),
        vec![
            CompatibilityCheck::NewClientOldService,
            CompatibilityCheck::RollbackDataCompatibility,
        ]
    );
}
