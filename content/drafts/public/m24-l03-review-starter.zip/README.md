# M24-L03 review and compatibility contracts

Complete the review finding validator and compatibility matrix checker from the exercise sheet. These helpers verify documentation and test coverage inputs; they do not replace human review or real upgrade testing.
