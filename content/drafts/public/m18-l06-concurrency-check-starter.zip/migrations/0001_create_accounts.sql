CREATE TABLE accounts (
    id INTEGER PRIMARY KEY,
    balance INTEGER NOT NULL CHECK (balance >= 0),
    version INTEGER NOT NULL DEFAULT 0 CHECK (version >= 0)
);
