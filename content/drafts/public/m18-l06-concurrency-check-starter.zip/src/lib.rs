//! Public starter for the M18-L06 optimistic concurrency and rollback check.

use std::str::FromStr;

use sqlx::sqlite::{SqliteConnectOptions, SqlitePoolOptions};
use sqlx::{SqlitePool, Transaction};

static MIGRATOR: sqlx::migrate::Migrator = sqlx::migrate!();

/// Outcome of an atomic version-checked withdrawal.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WithdrawOutcome {
    /// The account changed and its version was incremented.
    Applied,
    /// The row exists, but another writer already changed its version.
    Conflict,
    /// The requested balance is unavailable.
    InsufficientFunds,
    /// No account has the requested identifier.
    MissingAccount,
}

/// Outcome of a two-account transfer.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TransferOutcome {
    /// Both account updates committed.
    Applied,
    /// The source account cannot cover the transfer.
    InsufficientFunds,
    /// The source account does not exist.
    MissingSource,
    /// The destination account does not exist.
    MissingDestination,
}

/// Opens the isolated lab database and applies embedded migrations.
pub async fn open_pool(database_url: &str) -> Result<SqlitePool, sqlx::Error> {
    let options = SqliteConnectOptions::from_str(database_url)?.create_if_missing(true);
    let pool = SqlitePoolOptions::new()
        .max_connections(4)
        .connect_with(options)
        .await?;
    MIGRATOR.run(&pool).await?;
    Ok(pool)
}

/// Applies one version-checked withdrawal.
pub async fn withdraw(
    pool: &SqlitePool,
    account_id: i64,
    expected_version: i64,
    amount: i64,
) -> Result<WithdrawOutcome, sqlx::Error> {
    if amount <= 0 {
        return Ok(WithdrawOutcome::InsufficientFunds);
    }
    // BUG: The stale version is ignored, so two writers can both report success.
    let result = sqlx::query(
        "UPDATE accounts SET balance = balance - ?, version = version + 1 WHERE id = ? AND balance >= ?",
    )
    .bind(amount)
    .bind(account_id)
    .bind(amount)
    .execute(pool)
    .await?;
    if result.rows_affected() == 1 {
        return Ok(WithdrawOutcome::Applied);
    }
    classify_withdraw_miss(pool, account_id, expected_version).await
}

async fn classify_withdraw_miss(
    pool: &SqlitePool,
    account_id: i64,
    expected_version: i64,
) -> Result<WithdrawOutcome, sqlx::Error> {
    let row: Option<(i64, i64)> =
        sqlx::query_as("SELECT balance, version FROM accounts WHERE id = ?")
            .bind(account_id)
            .fetch_optional(pool)
            .await?;
    Ok(match row {
        None => WithdrawOutcome::MissingAccount,
        Some((_, version)) if version != expected_version => WithdrawOutcome::Conflict,
        Some(_) => WithdrawOutcome::InsufficientFunds,
    })
}

/// Transfers funds; a missing destination must leave both accounts unchanged.
pub async fn transfer(
    pool: &SqlitePool,
    source_id: i64,
    destination_id: i64,
    amount: i64,
) -> Result<TransferOutcome, sqlx::Error> {
    if amount <= 0 || source_id == destination_id {
        return Ok(TransferOutcome::InsufficientFunds);
    }
    let mut transaction = pool.begin().await?;
    let debit =
        sqlx::query("UPDATE accounts SET balance = balance - ? WHERE id = ? AND balance >= ?")
            .bind(amount)
            .bind(source_id)
            .bind(amount)
            .execute(&mut *transaction)
            .await?;
    if debit.rows_affected() != 1 {
        transaction.rollback().await?;
        return Ok(if account_exists(pool, source_id).await? {
            TransferOutcome::InsufficientFunds
        } else {
            TransferOutcome::MissingSource
        });
    }

    // BUG: Commit the debit before knowing whether the destination can be credited.
    transaction.commit().await?;
    let credit = sqlx::query("UPDATE accounts SET balance = balance + ? WHERE id = ?")
        .bind(amount)
        .bind(destination_id)
        .execute(pool)
        .await?;
    if credit.rows_affected() == 0 {
        return Ok(TransferOutcome::MissingDestination);
    }
    Ok(TransferOutcome::Applied)
}

async fn account_exists(pool: &SqlitePool, account_id: i64) -> Result<bool, sqlx::Error> {
    let exists: i64 = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM accounts WHERE id = ?)")
        .bind(account_id)
        .fetch_one(pool)
        .await?;
    Ok(exists == 1)
}

#[allow(dead_code)]
async fn rollback_destination_missing(
    transaction: Transaction<'_, sqlx::Sqlite>,
) -> Result<TransferOutcome, sqlx::Error> {
    transaction.rollback().await?;
    Ok(TransferOutcome::MissingDestination)
}
