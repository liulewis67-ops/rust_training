# M18-L06 independent concurrency and rollback check

This SQLx 0.9.0 starter contains two deliberate defects: stale versions are ignored by `withdraw`, and `transfer` commits the debit before the destination credit succeeds. Run `cargo test` and use `m18-l06-independent-check.md` for the task and fresh-reset rules.
