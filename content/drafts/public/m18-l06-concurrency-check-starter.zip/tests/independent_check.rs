//! Black-box concurrency and all-or-nothing transfer checks.

use m18_l06_concurrency_check::{TransferOutcome, WithdrawOutcome, open_pool, transfer, withdraw};
use std::sync::atomic::{AtomicU64, Ordering};

static NEXT_DB: AtomicU64 = AtomicU64::new(0);

fn database_url() -> String {
    let directory = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("target");
    std::fs::create_dir_all(&directory).unwrap();
    let sequence = NEXT_DB.fetch_add(1, Ordering::Relaxed);
    let path = directory.join(format!("m18-l06-{}-{sequence}.sqlite", std::process::id()));
    format!(
        "sqlite://{}?mode=rwc",
        path.display().to_string().replace('\\', "/")
    )
}

#[tokio::test]
async fn concurrent_writers_from_one_version_have_one_winner() {
    let pool = open_pool(&database_url()).await.unwrap();
    sqlx::query("INSERT INTO accounts (id, balance, version) VALUES (7, 300, 0)")
        .execute(&pool)
        .await
        .unwrap();

    let (first, second) = tokio::join!(withdraw(&pool, 7, 0, 100), withdraw(&pool, 7, 0, 100));
    let outcomes = [first.unwrap(), second.unwrap()];
    assert_eq!(
        outcomes
            .iter()
            .filter(|x| **x == WithdrawOutcome::Applied)
            .count(),
        1
    );
    assert_eq!(
        outcomes
            .iter()
            .filter(|x| **x == WithdrawOutcome::Conflict)
            .count(),
        1
    );
    let row: (i64, i64) = sqlx::query_as("SELECT balance, version FROM accounts WHERE id = 7")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(row, (200, 1));
}

#[tokio::test]
async fn missing_destination_rolls_back_the_source_debit() {
    let pool = open_pool(&database_url()).await.unwrap();
    sqlx::query("INSERT INTO accounts (id, balance, version) VALUES (10, 500, 0)")
        .execute(&pool)
        .await
        .unwrap();

    assert_eq!(
        transfer(&pool, 10, 99, 125).await.unwrap(),
        TransferOutcome::MissingDestination
    );
    let balance: i64 = sqlx::query_scalar("SELECT balance FROM accounts WHERE id = 10")
        .fetch_one(&pool)
        .await
        .unwrap();
    assert_eq!(balance, 500);
}
