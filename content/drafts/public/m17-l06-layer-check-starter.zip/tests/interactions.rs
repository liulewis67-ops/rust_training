//! Tests the failure and success paths across auth, trace middleware and extractors.

use axum::body::{Body, to_bytes};
use axum::http::{Request, StatusCode};
use m17_l06_layer_check::{CheckState, app};
use tower::ServiceExt;

/// Sends a request through the complete challenge router.
async fn send(
    uri: &str,
    auth: Option<&str>,
    body: &str,
) -> (
    StatusCode,
    axum::http::HeaderMap,
    serde_json::Value,
    CheckState,
) {
    let (router, state) = app();
    let mut request = Request::builder()
        .method("POST")
        .uri(uri)
        .header("x-request-id", "check-77")
        .header("content-type", "application/json");
    if let Some(auth) = auth {
        request = request.header("authorization", auth);
    }
    let response = router
        .oneshot(request.body(Body::from(body.to_owned())).unwrap())
        .await
        .unwrap();
    let status = response.status();
    let headers = response.headers().clone();
    let bytes = to_bytes(response.into_body(), usize::MAX).await.unwrap();
    let value = serde_json::from_slice(&bytes).unwrap_or(serde_json::Value::Null);
    (status, headers, value, state)
}

/// Requires an authentication short circuit to retain its context ID and status event.
#[tokio::test]
async fn unauthorized_short_circuit_is_traced() {
    let (status, headers, body, trace) = send("/labels/orange", None, r#"{"name":"Orange"}"#).await;
    assert_eq!(status, StatusCode::UNAUTHORIZED);
    assert_eq!(body["code"], "unauthorized");
    assert_eq!(headers["x-request-id"], "check-77");
    assert!(
        trace
            .snapshot()
            .iter()
            .any(|event| event == "id=check-77 status=401")
    );
}

/// Keeps extractor rejection inside the outer request context.
#[tokio::test]
async fn malformed_json_is_still_correlated() {
    let (status, headers, _, trace) = send("/labels/orange", Some("Bearer check-token"), "{").await;
    assert_eq!(status, StatusCode::BAD_REQUEST);
    assert_eq!(headers["x-request-id"], "check-77");
    assert!(
        trace
            .snapshot()
            .iter()
            .any(|event| event == "id=check-77 status=400")
    );
}

/// Confirms a valid extractor path reaches the handler with the same context.
#[tokio::test]
async fn valid_create_reaches_handler_without_logging_token() {
    let (status, headers, body, trace) = send(
        "/labels/orange",
        Some("Bearer check-token"),
        r#"{"name":"Orange"}"#,
    )
    .await;
    assert_eq!(status, StatusCode::CREATED);
    assert_eq!(headers["x-request-id"], "check-77");
    assert_eq!(body["name"], "Orange");
    let output = trace.snapshot().join("|");
    assert!(output.contains("id=check-77 handler"));
    assert!(!output.contains("check-token"));
}
