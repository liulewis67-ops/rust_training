//! Starter for an independent extractor and middleware interaction check.

use axum::body::Body;
use axum::extract::{Extension, Path, Request, State};
use axum::http::{HeaderName, HeaderValue, StatusCode};
use axum::middleware::{self, Next};
use axum::response::{IntoResponse, Response};
use axum::routing::post;
use axum::{Json, Router};
use serde::{Deserialize, Serialize};
use std::sync::{Arc, Mutex};

const REQUEST_ID: HeaderName = HeaderName::from_static("x-request-id");
const AUTHORIZATION: HeaderName = HeaderName::from_static("authorization");

/// Shared request trace state used by both middleware layers and handlers.
#[derive(Clone, Default)]
pub struct CheckState(Arc<Mutex<Vec<String>>>);

impl CheckState {
    /// Returns events produced by actual Router requests.
    pub fn snapshot(&self) -> Vec<String> {
        self.0.lock().expect("trace lock poisoned").clone()
    }

    /// Records only validated context labels and response status.
    fn record(&self, event: String) {
        self.0.lock().expect("trace lock poisoned").push(event);
    }
}

/// Request-scoped correlation data installed by the outer middleware.
#[derive(Clone)]
struct TraceContext(String);

/// JSON input accepted by the Label creation route.
#[derive(Deserialize)]
pub struct LabelInput {
    /// Public label text.
    pub name: String,
}

/// Response resource created by the check handler.
#[derive(Serialize)]
pub struct Label {
    /// Identifier from the route path.
    pub id: String,
    /// User-visible label.
    pub name: String,
}

/// Builds a router whose layer order intentionally loses early auth responses.
pub fn app() -> (Router, CheckState) {
    let state = CheckState::default();
    let router = Router::new()
        .route("/labels/{id}", post(create_label))
        .layer(middleware::from_fn_with_state(state.clone(), request_trace))
        .layer(middleware::from_fn_with_state(state.clone(), require_auth))
        .with_state(state.clone());
    (router, state)
}

/// Adds the request context before inner work and records the final response status.
async fn request_trace(
    State(state): State<CheckState>,
    mut request: Request<Body>,
    next: Next,
) -> Response {
    let request_id = request
        .headers()
        .get(&REQUEST_ID)
        .and_then(|value| value.to_str().ok())
        .filter(|value| valid_id(value))
        .unwrap_or("check-missing")
        .to_owned();
    request
        .extensions_mut()
        .insert(TraceContext(request_id.clone()));
    let mut response = next.run(request).await;
    let value = HeaderValue::from_str(&request_id).expect("checked request ID");
    response.headers_mut().insert(REQUEST_ID.clone(), value);
    state.record(format!(
        "id={request_id} status={}",
        response.status().as_u16()
    ));
    response
}

/// Accepts bounded visible IDs to prevent log/header injection.
fn valid_id(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= 48
        && value
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || byte == b'-')
}

/// Short-circuits requests without the exact check token.
async fn require_auth(request: Request<Body>, next: Next) -> Response {
    let authorized = request
        .headers()
        .get(&AUTHORIZATION)
        .and_then(|value| value.to_str().ok())
        == Some("Bearer check-token");
    if authorized {
        next.run(request).await
    } else {
        (
            StatusCode::UNAUTHORIZED,
            Json(serde_json::json!({"code": "unauthorized"})),
        )
            .into_response()
    }
}

/// Creates a label after Axum has extracted path and JSON input.
async fn create_label(
    State(state): State<CheckState>,
    Extension(context): Extension<TraceContext>,
    Path(id): Path<String>,
    Json(input): Json<LabelInput>,
) -> (StatusCode, Json<Label>) {
    state.record(format!("id={} handler", context.0));
    (
        StatusCode::CREATED,
        Json(Label {
            id,
            name: input.name,
        }),
    )
}
