# M12-L05 parallel log statistics starter

Rust 2024 and the standard library only. This package parses `timestamp_ms|LEVEL|message` lines and compares serial aggregation with worker-based parallel aggregation.

## Reset and verify

1. Extract the starter ZIP into a new empty directory. Never overwrite the preserved baseline.
2. Compare every project file against `starter-manifest.json` before editing.
3. Run `cargo fmt -- --check`, `cargo check --locked --offline`, and `cargo test --locked --offline`.
4. The initial package compiles; exactly `parallel_does_not_silently_discard_worker_errors` should fail because a parse error becomes a successful partial total.
5. Fix the worker error collection, rerun all checks, and record the resulting snapshot separately.

Expected commands:

```text
cargo fmt -- --check
cargo check --locked --offline
cargo test --locked --offline
cargo clippy --all-targets --locked --offline -- -D warnings
cargo doc --no-deps --locked --offline
```

`fixtures/public.log` contains a blank line, a message with an extra delimiter, and Unicode. `fixtures/expected.txt` is the serial aggregate. This local starter does not claim R2 resource acceptance; use the course platform's fixed dataset and resource envelope for that gate.
