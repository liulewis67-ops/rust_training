//! Starter for parallel log aggregation; worker errors are intentionally lost.

use std::thread;

/// One class of input or worker failure.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LogError {
    /// A record failed to parse at this one-based input line.
    InvalidRecord { line: usize, kind: &'static str },
    /// A worker panicked while processing a chunk starting at this line.
    WorkerPanicked { chunk_start: usize },
    /// A checked counter or byte total overflowed.
    StatisticsOverflow,
}

/// Fixed-size aggregate independent of the number of input records.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct Statistics {
    pub records: usize,
    pub by_level: [usize; 4],
    pub message_bytes: usize,
    pub first_timestamp_ms: Option<u64>,
    pub last_timestamp_ms: Option<u64>,
}

impl Statistics {
    fn add(&mut self, timestamp: u64, level_index: usize, message: &str) -> Result<(), LogError> {
        self.records = self
            .records
            .checked_add(1)
            .ok_or(LogError::StatisticsOverflow)?;
        self.by_level[level_index] = self.by_level[level_index]
            .checked_add(1)
            .ok_or(LogError::StatisticsOverflow)?;
        self.message_bytes = self
            .message_bytes
            .checked_add(message.len())
            .ok_or(LogError::StatisticsOverflow)?;
        self.first_timestamp_ms = Some(
            self.first_timestamp_ms
                .map_or(timestamp, |first| first.min(timestamp)),
        );
        self.last_timestamp_ms = Some(
            self.last_timestamp_ms
                .map_or(timestamp, |last| last.max(timestamp)),
        );
        Ok(())
    }

    fn merge(&mut self, other: &Self) -> Result<(), LogError> {
        self.records = self
            .records
            .checked_add(other.records)
            .ok_or(LogError::StatisticsOverflow)?;
        for (total, part) in self.by_level.iter_mut().zip(other.by_level) {
            *total = total
                .checked_add(part)
                .ok_or(LogError::StatisticsOverflow)?;
        }
        self.message_bytes = self
            .message_bytes
            .checked_add(other.message_bytes)
            .ok_or(LogError::StatisticsOverflow)?;
        self.first_timestamp_ms = match (self.first_timestamp_ms, other.first_timestamp_ms) {
            (Some(left), Some(right)) => Some(left.min(right)),
            (left, right) => left.or(right),
        };
        self.last_timestamp_ms = match (self.last_timestamp_ms, other.last_timestamp_ms) {
            (Some(left), Some(right)) => Some(left.max(right)),
            (left, right) => left.or(right),
        };
        Ok(())
    }
}

fn parse_level(value: &str) -> Option<usize> {
    match value {
        "ERROR" => Some(0),
        "WARN" => Some(1),
        "INFO" => Some(2),
        "DEBUG" => Some(3),
        _ => None,
    }
}

fn accumulate(lines: &[String], start_line: usize) -> Result<Statistics, LogError> {
    let mut stats = Statistics::default();
    for (offset, line) in lines.iter().enumerate() {
        if line.is_empty() {
            continue;
        }
        let line_number = start_line + offset;
        let mut fields = line.splitn(3, '|');
        let timestamp = fields
            .next()
            .ok_or(LogError::InvalidRecord {
                line: line_number,
                kind: "missing timestamp",
            })?
            .parse::<u64>()
            .map_err(|_| LogError::InvalidRecord {
                line: line_number,
                kind: "invalid timestamp",
            })?;
        let level = fields
            .next()
            .and_then(parse_level)
            .ok_or(LogError::InvalidRecord {
                line: line_number,
                kind: "missing or unknown level",
            })?;
        let message = fields.next().ok_or(LogError::InvalidRecord {
            line: line_number,
            kind: "missing message field",
        })?;
        stats.add(timestamp, level, message)?;
    }
    Ok(stats)
}

/// Calculates the serial baseline and returns the first error in input order.
///
/// # Errors
/// Returns a parse or checked-statistics error.
pub fn serial_stats(lines: &[String]) -> Result<Statistics, LogError> {
    accumulate(lines, 1)
}

/// Calculates stats in parallel. The starter intentionally drops worker errors.
///
/// # Errors
/// Returns an aggregation overflow. Worker parse and panic failures are
/// intentionally discarded in this starter for the learner to repair.
pub fn parallel_stats(lines: &[String], requested_workers: usize) -> Result<Statistics, LogError> {
    let worker_count = requested_workers.max(1).min(lines.len().max(1));
    let chunk_size = lines.len().div_ceil(worker_count).max(1);

    thread::scope(|scope| {
        let handles = lines
            .chunks(chunk_size)
            .enumerate()
            .map(|(chunk_index, chunk)| {
                let start_line = chunk_index * chunk_size + 1;
                (
                    start_line,
                    scope.spawn(move || accumulate(chunk, start_line)),
                )
            })
            .collect::<Vec<_>>();

        let mut total = Statistics::default();
        for (_, handle) in handles {
            if let Ok(Ok(partial)) = handle.join() {
                total.merge(&partial)?;
            }
        }
        Ok(total)
    })
}
