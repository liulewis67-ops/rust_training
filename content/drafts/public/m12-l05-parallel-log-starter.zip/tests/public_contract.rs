use parallel_log_stats::{LogError, parallel_stats, serial_stats};

fn lines(input: &str) -> Vec<String> {
    input.lines().map(str::to_owned).collect()
}

#[test]
fn serial_stats_counts_levels_unicode_and_delimiters() {
    let input = lines("10|ERROR|disk\n20|WARN|warm\n30|INFO|你好|details\n40|DEBUG|");
    let stats = serial_stats(&input).unwrap();
    assert_eq!(stats.records, 4);
    assert_eq!(stats.by_level, [1, 1, 1, 1]);
    assert_eq!(
        stats.message_bytes,
        "disk".len() + "warm".len() + "你好|details".len()
    );
    assert_eq!(stats.first_timestamp_ms, Some(10));
    assert_eq!(stats.last_timestamp_ms, Some(40));
}

#[test]
fn parallel_matches_serial_for_multiple_worker_counts() {
    let input = lines(include_str!("../fixtures/public.log"));
    let expected = serial_stats(&input).unwrap();
    assert_eq!(
        expected,
        parallel_log_stats::Statistics {
            records: 5,
            by_level: [1, 1, 2, 1],
            message_bytes: 69,
            first_timestamp_ms: Some(100),
            last_timestamp_ms: Some(140),
        }
    );
    for workers in [0, 1, 2, 3, 8] {
        assert_eq!(parallel_stats(&input, workers).unwrap(), expected);
    }
}

#[test]
fn blank_lines_are_skipped_without_renumbering_later_errors() {
    let input = lines("1|INFO|ok\n\nnot-a-record\n2|WARN|later");
    assert_eq!(
        serial_stats(&input),
        Err(LogError::InvalidRecord {
            line: 3,
            kind: "invalid timestamp"
        })
    );
}

#[test]
fn parallel_does_not_silently_discard_worker_errors() {
    let input = lines("1|INFO|ok\n2|WARN|good\ninvalid|ERROR|bad\n4|INFO|later");
    assert_eq!(parallel_stats(&input, 2), serial_stats(&input));
}

#[test]
fn empty_input_has_zero_stats_in_both_modes() {
    let input = Vec::new();
    assert_eq!(serial_stats(&input), parallel_stats(&input, 4));
}
