//! Restore evidence and bounded admission contracts for M23-L04.

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RestoreEvidence {
    pub source_environment: String,
    pub target_environment: String,
    pub expected_checksum: String,
    pub observed_checksum: String,
    pub expected_rows: u64,
    pub observed_rows: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RestoreError {
    SameEnvironment,
    ChecksumMismatch,
    RowCountMismatch,
}

/// Verify restore integrity before an operator can approve a traffic switch.
pub fn verify_restore(evidence: &RestoreEvidence) -> Result<(), RestoreError> {
    if evidence.expected_checksum != evidence.observed_checksum {
        return Err(RestoreError::ChecksumMismatch);
    }
    Ok(())
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ResourceBudget {
    pub max_in_flight: usize,
    pub max_pending: usize,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct LoadState {
    pub in_flight: usize,
    pub pending: usize,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Admission {
    Started,
    Queued,
    Rejected,
}

/// Classify one request without mutating counts or allocating a queue.
pub fn admit_request(budget: ResourceBudget, state: LoadState) -> Admission {
    let _ = (budget, state);
    Admission::Started
}
