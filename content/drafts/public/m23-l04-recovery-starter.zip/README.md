# M23-L04 recovery and budget starter

This pure Rust starter checks fixed restore evidence and classifies one request against bounded in-flight and pending capacity. It does not connect to a database, backup system, cloud account, or container. The exercise sheet describes the expected contracts and the separate design review.
