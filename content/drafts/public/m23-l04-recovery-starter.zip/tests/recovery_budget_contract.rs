use m23_l04_recovery_starter::{
    Admission, LoadState, ResourceBudget, RestoreError, RestoreEvidence, admit_request,
    verify_restore,
};

/// Build correct evidence for a recovery into an isolated target.
fn valid_restore() -> RestoreEvidence {
    RestoreEvidence {
        source_environment: "source-a".into(),
        target_environment: "restore-b".into(),
        expected_checksum: "sha256:abc".into(),
        observed_checksum: "sha256:abc".into(),
        expected_rows: 500,
        observed_rows: 500,
    }
}

/// Accept matching data restored to a separate target.
#[test]
fn accepts_verified_restore_to_new_target() {
    assert_eq!(verify_restore(&valid_restore()), Ok(()));
}

/// Never use the source environment as the destructive restore target.
#[test]
fn rejects_restore_into_source_environment() {
    let mut evidence = valid_restore();
    evidence.target_environment = evidence.source_environment.clone();
    assert_eq!(
        verify_restore(&evidence),
        Err(RestoreError::SameEnvironment)
    );
}

/// Check expected row counts in addition to transport checksums.
#[test]
fn rejects_restore_with_wrong_row_count() {
    let mut evidence = valid_restore();
    evidence.observed_rows -= 1;
    assert_eq!(
        verify_restore(&evidence),
        Err(RestoreError::RowCountMismatch)
    );
}

/// Reject a checksum mismatch even when target and row count look valid.
#[test]
fn rejects_restore_with_wrong_checksum() {
    let mut evidence = valid_restore();
    evidence.observed_checksum = "sha256:other".into();
    assert_eq!(
        verify_restore(&evidence),
        Err(RestoreError::ChecksumMismatch)
    );
}

/// Fill execution and queue capacity in order, then reject excess work.
#[test]
fn admits_then_queues_then_rejects_at_fixed_capacity() {
    let budget = ResourceBudget {
        max_in_flight: 2,
        max_pending: 1,
    };
    assert_eq!(
        admit_request(
            budget,
            LoadState {
                in_flight: 0,
                pending: 0
            }
        ),
        Admission::Started
    );
    assert_eq!(
        admit_request(
            budget,
            LoadState {
                in_flight: 2,
                pending: 0
            }
        ),
        Admission::Queued
    );
    assert_eq!(
        admit_request(
            budget,
            LoadState {
                in_flight: 2,
                pending: 1
            }
        ),
        Admission::Rejected
    );
}
