//! Public starter for the M18-L05 persistent task API lab.

use std::str::FromStr;

use axum::extract::{Path, State};
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::routing::get;
use axum::{Json, Router};
use serde::{Deserialize, Serialize};
use sqlx::sqlite::{SqliteConnectOptions, SqlitePoolOptions};
use sqlx::{FromRow, SqlitePool};

static MIGRATOR: sqlx::migrate::Migrator = sqlx::migrate!();

/// A task persisted in the local application database.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq, FromRow)]
pub struct Task {
    /// Database-assigned identifier.
    pub id: i64,
    /// Required non-whitespace task title.
    pub title: String,
    /// Whether the task has been completed.
    pub completed: bool,
}

/// Fields accepted when creating or replacing a task.
#[derive(Debug, Deserialize)]
pub struct TaskInput {
    /// Required non-whitespace title.
    pub title: String,
    /// Completion state; omitted values default to false.
    #[serde(default)]
    pub completed: bool,
}

/// Opens the task database and applies all embedded migrations.
pub async fn open_pool(database_url: &str) -> Result<SqlitePool, sqlx::Error> {
    // BUG: The caller's file-backed URL is ignored, so reopening loses data.
    let _ = database_url;
    let options = SqliteConnectOptions::from_str("sqlite::memory:")?.create_if_missing(true);
    let pool = SqlitePoolOptions::new()
        .max_connections(1)
        .connect_with(options)
        .await?;
    MIGRATOR.run(&pool).await?;
    Ok(pool)
}

/// Builds the task API around an isolated application database pool.
pub fn app(pool: SqlitePool) -> Router {
    Router::new()
        .route("/tasks", get(list_tasks).post(create_task))
        .route(
            "/tasks/{id}",
            get(show_task).put(replace_task).delete(delete_task),
        )
        .with_state(pool)
}

async fn list_tasks(State(pool): State<SqlitePool>) -> Result<Json<Vec<Task>>, StatusCode> {
    sqlx::query_as::<_, Task>("SELECT id, title, completed FROM tasks ORDER BY id")
        .fetch_all(&pool)
        .await
        .map(Json)
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)
}

async fn create_task(
    State(pool): State<SqlitePool>,
    Json(input): Json<TaskInput>,
) -> Result<impl IntoResponse, StatusCode> {
    if input.title.trim().is_empty() {
        return Err(StatusCode::UNPROCESSABLE_ENTITY);
    }
    let result = sqlx::query("INSERT INTO tasks (title, completed) VALUES (?, ?)")
        .bind(input.title.trim())
        .bind(input.completed)
        .execute(&pool)
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    let task = sqlx::query_as::<_, Task>("SELECT id, title, completed FROM tasks WHERE id = ?")
        .bind(result.last_insert_rowid())
        .fetch_one(&pool)
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    Ok((StatusCode::CREATED, Json(task)))
}

async fn show_task(
    Path(id): Path<i64>,
    State(pool): State<SqlitePool>,
) -> Result<Json<Task>, StatusCode> {
    sqlx::query_as::<_, Task>("SELECT id, title, completed FROM tasks WHERE id = ?")
        .bind(id)
        .fetch_optional(&pool)
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?
        .map(Json)
        .ok_or(StatusCode::NOT_FOUND)
}

async fn replace_task(
    Path(id): Path<i64>,
    State(pool): State<SqlitePool>,
    Json(input): Json<TaskInput>,
) -> Result<Json<Task>, StatusCode> {
    if input.title.trim().is_empty() {
        return Err(StatusCode::UNPROCESSABLE_ENTITY);
    }
    let result = sqlx::query("UPDATE tasks SET title = ?, completed = ? WHERE id = ?")
        .bind(input.title.trim())
        .bind(input.completed)
        .bind(id)
        .execute(&pool)
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    if result.rows_affected() != 1 {
        return Err(StatusCode::NOT_FOUND);
    }
    show_task(Path(id), State(pool)).await
}

async fn delete_task(Path(id): Path<i64>, State(pool): State<SqlitePool>) -> StatusCode {
    match sqlx::query("DELETE FROM tasks WHERE id = ?")
        .bind(id)
        .execute(&pool)
        .await
    {
        Ok(result) if result.rows_affected() == 1 => StatusCode::NO_CONTENT,
        Ok(_) => StatusCode::NOT_FOUND,
        Err(_) => StatusCode::INTERNAL_SERVER_ERROR,
    }
}
