//! Request-level API and database persistence acceptance tests.

use std::sync::atomic::{AtomicU64, Ordering};

use axum::body::{Body, to_bytes};
use axum::http::{Method, Request, StatusCode};
use m18_l05_persistent_task_api::{app, open_pool};
use tower::ServiceExt;

static NEXT_DB: AtomicU64 = AtomicU64::new(0);

fn database_url() -> String {
    let directory = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("target");
    std::fs::create_dir_all(&directory).unwrap();
    let id = NEXT_DB.fetch_add(1, Ordering::Relaxed);
    let path = directory.join(format!("m18-l05-{}-{id}.sqlite", std::process::id()));
    format!(
        "sqlite://{}?mode=rwc",
        path.display().to_string().replace('\\', "/")
    )
}

async fn send(
    router: &axum::Router,
    method: Method,
    uri: &str,
    body: Body,
) -> axum::response::Response {
    router
        .clone()
        .oneshot(
            Request::builder()
                .method(method)
                .uri(uri)
                .header("content-type", "application/json")
                .body(body)
                .unwrap(),
        )
        .await
        .unwrap()
}

async fn json(response: axum::response::Response) -> serde_json::Value {
    let bytes = to_bytes(response.into_body(), usize::MAX).await.unwrap();
    serde_json::from_slice(&bytes).unwrap()
}

#[tokio::test]
async fn crud_and_invalid_input_follow_the_http_contract() {
    let pool = open_pool(&database_url()).await.unwrap();
    let router = app(pool);
    let invalid = send(
        &router,
        Method::POST,
        "/tasks",
        Body::from(r#"{"title":" "}"#),
    )
    .await;
    assert_eq!(invalid.status(), StatusCode::UNPROCESSABLE_ENTITY);

    let created = send(
        &router,
        Method::POST,
        "/tasks",
        Body::from(r#"{"title":"write migration"}"#),
    )
    .await;
    assert_eq!(created.status(), StatusCode::CREATED);
    let task = json(created).await;
    assert_eq!(task["title"], "write migration");
    let id = task["id"].as_i64().unwrap();

    let listed = send(&router, Method::GET, "/tasks", Body::empty()).await;
    assert_eq!(json(listed).await.as_array().unwrap().len(), 1);
    let updated = send(
        &router,
        Method::PUT,
        &format!("/tasks/{id}"),
        Body::from(r#"{"title":"ship migration","completed":true}"#),
    )
    .await;
    assert_eq!(updated.status(), StatusCode::OK);
    assert_eq!(json(updated).await["completed"], true);
    assert_eq!(
        send(&router, Method::GET, "/tasks/999999", Body::empty())
            .await
            .status(),
        StatusCode::NOT_FOUND
    );

    let deleted = send(
        &router,
        Method::DELETE,
        &format!("/tasks/{id}"),
        Body::empty(),
    )
    .await;
    assert_eq!(deleted.status(), StatusCode::NO_CONTENT);
    assert!(
        to_bytes(deleted.into_body(), usize::MAX)
            .await
            .unwrap()
            .is_empty()
    );
}

#[tokio::test]
async fn file_backed_data_survives_pool_restart() {
    let url = database_url();
    let first_pool = open_pool(&url).await.unwrap();
    let first_router = app(first_pool.clone());
    let created = send(
        &first_router,
        Method::POST,
        "/tasks",
        Body::from(r#"{"title":"survive restart"}"#),
    )
    .await;
    assert_eq!(created.status(), StatusCode::CREATED);
    drop(first_router);
    first_pool.close().await;

    let second_pool = open_pool(&url).await.unwrap();
    let second_router = app(second_pool);
    let listed = send(&second_router, Method::GET, "/tasks", Body::empty()).await;
    assert_eq!(json(listed).await[0]["title"], "survive restart");
}
