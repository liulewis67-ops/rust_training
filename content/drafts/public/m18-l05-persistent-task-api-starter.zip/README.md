# M18-L05 P3 persistent task API starter

This Axum 0.8.9 / SQLx 0.9.0 starter stores tasks in SQLite. One deliberate persistence bug remains in `open_pool`: it ignores the requested file URL and opens an in-memory database.

Run `cargo test` to observe the contract. The CRUD checks should pass; the restart check should fail until `open_pool` uses the supplied SQLite URL. Follow the lab brief for the API contract, reset procedure, and evidence boundary.
