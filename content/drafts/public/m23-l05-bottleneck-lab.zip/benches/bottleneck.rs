use std::hint::black_box;
use std::time::Duration;

use criterion::{Criterion, Throughput, criterion_group, criterion_main};
use m23_l05_bottleneck_lab::{Event, score_windows_indexed, score_windows_scan};

/// Build the same deterministic actor/event workload for each benchmark process.
fn fixed_workload() -> (Vec<Vec<Event>>, Vec<u32>) {
    let allowed = (0..500_u32).map(|id| (id * 71 + 13) % 20_000).collect();
    let windows = (0..8_u32)
        .map(|window| {
            (0..10_000_u32)
                .map(|row| Event {
                    actor_id: (row * 7_919 + window * 104_729) % 20_000,
                    units: u64::from(row % 7 + 1),
                })
                .collect()
        })
        .collect();
    (windows, allowed)
}

/// Compare whole-window scan and indexed pipelines with setup outside the timer.
fn bench_bottleneck(criterion: &mut Criterion) {
    let (windows, allowed) = fixed_workload();
    let event_count = windows.iter().map(Vec::len).sum::<usize>() as u64;
    let mut group = criterion.benchmark_group("authorization-window-pipeline");
    group.sample_size(20);
    group.warm_up_time(Duration::from_secs(1));
    group.measurement_time(Duration::from_secs(2));
    group.throughput(Throughput::Elements(event_count));

    group.bench_function("scan_baseline", |bencher| {
        bencher.iter(|| black_box(score_windows_scan(black_box(&windows), black_box(&allowed))))
    });
    group.bench_function("indexed_candidate", |bencher| {
        bencher.iter(|| {
            black_box(score_windows_indexed(
                black_box(&windows),
                black_box(&allowed),
            ))
        })
    });
    group.finish();
}

criterion_group!(benches, bench_bottleneck);
criterion_main!(benches);
