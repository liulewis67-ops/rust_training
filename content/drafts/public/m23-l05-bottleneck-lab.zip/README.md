# M23-L05 controlled bottleneck lab

Start with passing behavior contracts and the `scan_baseline` benchmark. The indexed candidate uses binary search against a deliberately unsorted actor list, so its contract tests fail until repaired. Save the initial baseline with `cargo bench --bench bottleneck -- scan_baseline --save-baseline before`. Run all correctness tests after the repair, then compare both whole-workload variants with `cargo bench --bench bottleneck -- --baseline before`; the candidate includes index construction. See the experiment brief for the R2/R3 procedure and reset steps.
