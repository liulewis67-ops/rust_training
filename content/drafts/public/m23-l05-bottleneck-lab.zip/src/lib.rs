//! Fixed-window authorization summary workload for the M23-L05 lab.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Event {
    pub actor_id: u32,
    pub units: u64,
}

/// Correct but potentially expensive reference that linearly scans allowed IDs per event.
pub fn score_windows_scan(windows: &[Vec<Event>], allowed_actor_ids: &[u32]) -> Vec<u64> {
    windows
        .iter()
        .map(|window| {
            window
                .iter()
                .filter(|event| allowed_actor_ids.contains(&event.actor_id))
                .map(|event| event.units)
                .sum()
        })
        .collect()
}

/// Candidate implementation whose binary search assumes an ordering the input does not promise.
pub fn score_windows_indexed(windows: &[Vec<Event>], allowed_actor_ids: &[u32]) -> Vec<u64> {
    windows
        .iter()
        .map(|window| {
            window
                .iter()
                .filter(|event| allowed_actor_ids.binary_search(&event.actor_id).is_ok())
                .map(|event| event.units)
                .sum()
        })
        .collect()
}
