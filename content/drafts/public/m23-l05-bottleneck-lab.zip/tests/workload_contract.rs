use m23_l05_bottleneck_lab::{Event, score_windows_indexed, score_windows_scan};

/// Construct fixed windows with an intentionally unsorted permission set.
fn fixture() -> (Vec<Vec<Event>>, Vec<u32>) {
    let windows = vec![
        vec![
            Event {
                actor_id: 7,
                units: 3,
            },
            Event {
                actor_id: 2,
                units: 5,
            },
            Event {
                actor_id: 9,
                units: 11,
            },
        ],
        vec![
            Event {
                actor_id: 2,
                units: 13,
            },
            Event {
                actor_id: 7,
                units: 17,
            },
        ],
    ];
    (windows, vec![9, 2, 7, 2])
}

/// Preserve the per-window authorization score.
#[test]
fn keeps_each_window_score_equal_to_the_reference() {
    let (windows, allowed) = fixture();
    assert_eq!(score_windows_scan(&windows, &allowed), vec![19, 30]);
    assert_eq!(score_windows_indexed(&windows, &allowed), vec![19, 30]);
}

/// Do not count an event twice when the permission list contains duplicates.
#[test]
fn duplicate_allowed_ids_do_not_duplicate_events() {
    let (windows, allowed) = fixture();
    assert_eq!(
        score_windows_scan(&windows, &allowed),
        score_windows_indexed(&windows, &allowed)
    );
}

/// Treat an empty event window as a zero score.
#[test]
fn handles_empty_windows_and_no_matches() {
    let windows = vec![
        Vec::new(),
        vec![Event {
            actor_id: 99,
            units: 123,
        }],
    ];
    assert_eq!(score_windows_scan(&windows, &[2, 1]), vec![0, 0]);
    assert_eq!(score_windows_indexed(&windows, &[2, 1]), vec![0, 0]);
}
