use std::process::Command;

/// Ensures the compiled command prints a successful public core report.
#[test]
fn runs_the_profile_cli_binary() {
    let output = Command::new(env!("CARGO_BIN_EXE_profile-cli"))
        .output()
        .expect("profile-cli binary should start");

    assert!(output.status.success());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        "profile=training_user\n"
    );
    assert!(output.stderr.is_empty());
}
