use m09_l06_error_presentation::{
    ApiPresentation, CliPresentation, ProfileHistoryError, present_api, present_cli,
};

/// Ensures CLI input feedback is actionable and does not echo the supplied value.
#[test]
fn cli_validation_error_is_actionable_and_redacted() {
    let error = ProfileHistoryError::InvalidRetentionDays {
        supplied: "400;token=private".to_owned(),
    };
    assert_eq!(
        present_cli(&error),
        CliPresentation {
            stderr: "error: retention-days must be an integer from 1 to 365\n".to_owned(),
            exit_code: 2,
        }
    );
}

/// Ensures CLI missing-profile feedback uses a failing process status.
#[test]
fn cli_missing_profile_is_not_success() {
    assert_eq!(
        present_cli(&ProfileHistoryError::ProfileNotFound),
        CliPresentation {
            stderr: "error: profile was not found\n".to_owned(),
            exit_code: 3,
        }
    );
}

/// Ensures CLI storage feedback hides SQL while the error retains diagnostics.
#[test]
fn cli_storage_failure_redacts_internal_details() {
    let error = ProfileHistoryError::StorageUnavailable {
        diagnostic: "db=private.internal SQL=SELECT * FROM history password=hunter2".to_owned(),
    };
    let shown = present_cli(&error);
    assert_eq!(
        shown,
        CliPresentation {
            stderr: "error: history service is temporarily unavailable; try again later\n"
                .to_owned(),
            exit_code: 1,
        }
    );
    assert!(!shown.stderr.contains("SELECT"));
    assert!(!shown.stderr.contains("hunter2"));
    assert_eq!(
        error.internal_diagnostic(),
        Some("db=private.internal SQL=SELECT * FROM history password=hunter2")
    );
}

/// Ensures API validation errors use a stable client contract and request ID.
#[test]
fn api_validation_error_uses_bad_request_contract() {
    assert_eq!(
        present_api(
            &ProfileHistoryError::InvalidRetentionDays {
                supplied: "400;token=private".to_owned(),
            },
            "req-17",
        ),
        ApiPresentation {
            status: 400,
            code: "invalid_retention_days",
            message: "retention_days must be an integer from 1 to 365.",
            retryable: false,
            request_id: "req-17".to_owned(),
        }
    );
}

/// Ensures API missing-profile errors do not reveal private identifiers.
#[test]
fn api_missing_profile_uses_not_found_contract() {
    assert_eq!(
        present_api(&ProfileHistoryError::ProfileNotFound, "req-18"),
        ApiPresentation {
            status: 404,
            code: "profile_not_found",
            message: "profile was not found.",
            retryable: false,
            request_id: "req-18".to_owned(),
        }
    );
}

/// Ensures API storage failures are retryable without exposing SQL or secrets.
#[test]
fn api_storage_failure_is_redacted_and_retryable() {
    let error = ProfileHistoryError::StorageUnavailable {
        diagnostic: "db=private.internal SQL=SELECT * FROM history password=hunter2".to_owned(),
    };
    let shown = present_api(&error, "req-19");
    assert_eq!(shown.status, 503);
    assert_eq!(shown.code, "history_unavailable");
    assert_eq!(
        shown.message,
        "history service is temporarily unavailable; retry later."
    );
    assert!(shown.retryable);
    assert_eq!(shown.request_id, "req-19");
    assert!(!format!("{} {} {}", shown.code, shown.message, shown.request_id).contains("SELECT"));
    assert!(!format!("{} {} {}", shown.code, shown.message, shown.request_id).contains("hunter2"));
}

/// Ensures CLI and API audiences receive distinct representations of one failure.
#[test]
fn cli_and_api_shapes_are_not_interchangeable() {
    let error = ProfileHistoryError::StorageUnavailable {
        diagnostic: "connection refused".to_owned(),
    };
    let cli = present_cli(&error);
    let api = present_api(&error, "req-20");
    assert_eq!(cli.exit_code, 1);
    assert!(cli.stderr.starts_with("error:"));
    assert_eq!(api.status, 503);
    assert_eq!(api.code, "history_unavailable");
    assert_ne!(cli.stderr.trim(), api.message);
}

/// Ensures non-storage failures do not invent internal diagnostics.
#[test]
fn non_storage_failures_have_no_internal_diagnostic() {
    assert_eq!(
        ProfileHistoryError::InvalidRetentionDays {
            supplied: "private-value".to_owned(),
        }
        .internal_diagnostic(),
        None
    );
    assert_eq!(
        ProfileHistoryError::ProfileNotFound.internal_diagnostic(),
        None
    );
}
