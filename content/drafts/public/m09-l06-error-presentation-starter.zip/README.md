# M09-L06 CLI/API 错误呈现独立检查

Edition 2024、无第三方依赖的 Rust 检查工作区，包版本 `0.1.0`。只阅读检查题面和本起始包，按固定函数签名实现两种边界的错误呈现；请勿检索或查看教师评测参考。

## 运行公开检查

```text
cargo test --offline
```

起始代码中的呈现函数为 `todo!()`，公开行为测试会失败。实现后按顺序运行：

```text
cargo fmt -- --check
cargo check --offline
cargo test --offline
```

## 提交设计说明

解释 CLI 用户消息/退出码与 API 状态码/稳定错误码的职责差异，指出哪些详情只能写入受控诊断，并说明何时可以重试。

## 重置

从 `content/drafts/public/m09-l06-error-presentation-starter.zip` 解压到全新目录。用根目录 `starter-manifest.json` 核对各文件 SHA-256 后再作答。保留未修改的原始解压副本，并把提交及构建目标放在独立副本/临时目录。本地重置步骤不替代 R2 对学习者快照、版本和评测结果的正式追溯。
