/// A profile-history failure with internal storage diagnostics kept separate.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ProfileHistoryError {
    /// The request supplied a retention period outside the accepted range.
    InvalidRetentionDays { supplied: String },
    /// The requested profile does not exist or is not visible to the caller.
    ProfileNotFound,
    /// The history store failed with details reserved for trusted diagnostics.
    StorageUnavailable { diagnostic: String },
}

impl ProfileHistoryError {
    /// Returns internal diagnostic detail for restricted server-side logging.
    #[must_use]
    pub fn internal_diagnostic(&self) -> Option<&str> {
        match self {
            Self::StorageUnavailable { diagnostic } => Some(diagnostic),
            Self::InvalidRetentionDays { .. } | Self::ProfileNotFound => None,
        }
    }
}

/// Captures a command-line error written to stderr and its process exit code.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CliPresentation {
    /// Contains user-facing text; internal database details never belong here.
    pub stderr: String,
    /// Uses a nonzero code so automation can detect the failed command.
    pub exit_code: i32,
}

/// Captures the stable HTTP error fields returned to an API caller.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ApiPresentation {
    /// Provides the HTTP status for this failure category.
    pub status: u16,
    /// Provides a stable machine-readable category code.
    pub code: &'static str,
    /// Provides a safe message without SQL, paths, or raw values.
    pub message: &'static str,
    /// Indicates whether a bounded retry may succeed.
    pub retryable: bool,
    /// Correlates the response with trusted server-side diagnostics.
    pub request_id: String,
}

/// Presents a profile-history error for a command-line user.
#[must_use]
pub fn present_cli(_error: &ProfileHistoryError) -> CliPresentation {
    // TODO: Map each failure to actionable stderr text and a nonzero exit code.
    todo!()
}

/// Presents a profile-history error using a stable API response contract.
#[must_use]
pub fn present_api(_error: &ProfileHistoryError, _request_id: &str) -> ApiPresentation {
    // TODO: Map status, code, message, and retryability without exposing internals.
    todo!()
}
