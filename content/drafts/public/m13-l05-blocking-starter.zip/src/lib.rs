//! Deterministic probe for a synchronous operation that can stall an async worker.

use std::sync::mpsc::{Receiver, SyncSender};
use std::time::Duration;

/// Result observed by the sibling task before the blocking gate is released.
#[derive(Debug, PartialEq, Eq)]
pub struct ProbeObservation {
    /// Whether the sibling reported progress while the operation gate was closed.
    pub sibling_progressed_before_release: bool,
    /// The result returned by the gated synchronous operation.
    pub output: u64,
}

/// Executes one gated operation and reports whether a sibling progresses first.
///
/// The `started` sender and `release` receiver are supplied by a controller that
/// opens the release gate only after the sibling has reported or its watchdog ends.
pub async fn run_gated_work(
    input: u64,
    started: SyncSender<()>,
    release: Receiver<()>,
    sibling_wakeup: tokio::sync::oneshot::Receiver<()>,
    sibling_report: SyncSender<()>,
    controller_status: Receiver<bool>,
) -> ProbeObservation {
    // The sibling is ready before gated work starts, then waits for controller input.
    let sibling = tokio::spawn(async move {
        let _ = sibling_wakeup.await;
        sibling_report.send(()).is_ok()
    });

    // This baseline intentionally blocks the runtime worker; the lab asks learners
    // to move this finite synchronous operation to Tokio's blocking pool.
    let output = gated_double(input, started, release);
    let sibling_progressed_before_release = controller_status
        .recv_timeout(Duration::from_secs(2))
        .unwrap_or(false);
    let _ = sibling.await;
    ProbeObservation {
        sibling_progressed_before_release,
        output,
    }
}

/// Signals that work started, waits for its explicit release, and doubles input.
/// Runs the synchronous part of the probe after notifying its controller.
fn gated_double(input: u64, started: SyncSender<()>, release: Receiver<()>) -> u64 {
    let _ = started.send(());
    let _ = release.recv_timeout(Duration::from_secs(2));
    // Close both probe channels when their controlled work interval is complete.
    drop(started);
    drop(release);
    input.saturating_mul(2)
}
