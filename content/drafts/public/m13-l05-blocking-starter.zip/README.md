# M13-L05 起始工作区

Rust edition 2024、Tokio 1.53.3。这个 crate 有意保留一个运行时阻塞缺陷：`run_gated_work` 直接调用同步等待函数。项目只用于本地课程练习，不执行学员上传程序，也不代表隔离平台。

## 开始

先查看 `starter-manifest.json`，记录工具链及快照，再运行：

```powershell
cargo fmt -- --check
cargo check --locked --offline
cargo test --locked --offline
```

基线预期：格式和构建通过，`sibling_progresses_before_release` 失败，因为唯一 runtime worker 被同步等待占用。测试的 watchdog 会自动打开门控，避免卡住。

只改 `src/lib.rs` 中标出的 `run_gated_work` 实现。保留公开类型、观察器、契约测试和数据；不增加 runtime worker，不删测试。修复后再运行同一组命令，并打开另一份全新解压副本复现基线。

课程之外不要把本地 cargo 结果当作正式检查成绩。教师参考实现不在此 ZIP 内。
