//! Public behavior contract for the blocking-runtime diagnostic lab.

use std::sync::mpsc;
use std::thread;
use std::time::Duration;

use m13_l05_blocking_starter::{ProbeObservation, run_gated_work};

/// The sibling should report progress while the synchronous operation is gated.
#[tokio::test(flavor = "current_thread")]
async fn sibling_progresses_before_release() {
    let (started_tx, started_rx) = mpsc::sync_channel(0);
    let (release_tx, release_rx) = mpsc::sync_channel(1);
    let (wakeup_tx, wakeup_rx) = tokio::sync::oneshot::channel();
    let (report_tx, report_rx) = mpsc::sync_channel(0);
    let (status_tx, status_rx) = mpsc::sync_channel(1);

    // The controller wakes the sibling, observes its report, and always releases work.
    let controller = thread::spawn(move || {
        let started = started_rx.recv_timeout(Duration::from_secs(2));
        let _ = wakeup_tx.send(());
        let sibling_progressed = matches!(report_rx.recv_timeout(Duration::from_secs(2)), Ok(()));
        let _ = status_tx.send(sibling_progressed);
        let _ = release_tx.send(());
        started
    });

    let observation =
        run_gated_work(21, started_tx, release_rx, wakeup_rx, report_tx, status_rx).await;
    let started = controller.join().expect("controller thread must join");
    let sibling_progressed = observation.sibling_progressed_before_release;

    assert!(started.is_ok(), "gated work must start");
    assert!(
        sibling_progressed,
        "sibling must report before gate release"
    );
    assert_eq!(
        observation,
        ProbeObservation {
            sibling_progressed_before_release: true,
            output: 42,
        }
    );
}
