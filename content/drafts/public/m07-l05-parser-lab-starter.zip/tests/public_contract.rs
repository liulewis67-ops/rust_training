use m07_l05_replaceable_parser::{
    ColonParser, EntryParser, EqualsParser, ParseError, render_label,
};

#[test]
fn both_parsers_extract_their_configured_format() {
    assert_eq!(
        EqualsParser.parse("mode=cache"),
        Ok(m07_l05_replaceable_parser::Entry {
            key: String::from("mode"),
            value: String::from("cache"),
        })
    );
    assert_eq!(
        ColonParser.parse("mode:cache"),
        Ok(m07_l05_replaceable_parser::Entry {
            key: String::from("mode"),
            value: String::from("cache"),
        })
    );
}

#[test]
fn only_the_first_delimiter_splits_the_input() {
    assert_eq!(
        ColonParser.parse("状态:缓存:东区"),
        Ok(m07_l05_replaceable_parser::Entry {
            key: String::from("状态"),
            value: String::from("缓存:东区"),
        })
    );
}

#[test]
fn missing_delimiter_reports_the_selected_format() {
    assert_eq!(
        ColonParser.parse("mode=cache"),
        Err(ParseError::MissingDelimiter(':'))
    );
    assert_eq!(
        EqualsParser.parse("mode:cache"),
        Err(ParseError::MissingDelimiter('='))
    );
    assert_eq!(
        EqualsParser.parse("no delimiter"),
        Err(ParseError::MissingDelimiter('='))
    );
}

#[test]
fn blank_fields_keep_distinct_errors() {
    assert_eq!(EqualsParser.parse("=cache"), Err(ParseError::EmptyKey));
    assert_eq!(EqualsParser.parse("mode=  "), Err(ParseError::EmptyValue));
    assert_eq!(ColonParser.parse("  : cache "), Err(ParseError::EmptyKey));
}

#[test]
fn generic_caller_produces_the_same_canonical_form() {
    assert_eq!(
        render_label(&EqualsParser, " mode = cache "),
        Ok(String::from("mode=cache"))
    );
    assert_eq!(
        render_label(&ColonParser, " mode : cache "),
        Ok(String::from("mode=cache"))
    );
}
