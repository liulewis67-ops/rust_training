# M07-L05 可替换解析器实验起始包

Edition 2024、无第三方依赖的 Rust 库实验。先查看 `tests/public_contract.rs`，再运行：

~~~text
cargo test --offline
~~~

预期起始状态：项目能编译，但至少一项公开契约测试失败，因为 `ColonParser` 使用了错误的分隔符。修复后运行：

~~~text
cargo fmt -- --check
cargo check --offline
cargo test --offline
~~~

测试核对两种解析器使用相同字段与错误契约、只按首个分隔符切分、保留额外分隔符、拒绝空字段、支持 UTF-8，并让泛型 `render_label` 对两种实现返回规范格式。

重置时从原始 `m07-l05-parser-lab-starter.zip` 解压到全新目录，并用 `starter-manifest.json` 核对项目文件哈希。不要把当前已修改目录当成起点。
