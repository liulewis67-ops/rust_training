/// Holds the parsed key and value as owned strings.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Entry {
    /// Stores the trimmed key text.
    pub key: String,
    /// Stores the trimmed value text after the first delimiter.
    pub value: String,
}

/// Describes a failure while parsing a delimited entry.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ParseError {
    /// The input did not contain the parser's configured delimiter.
    MissingDelimiter(char),
    /// The key was empty or contained only whitespace.
    EmptyKey,
    /// The value was empty or contained only whitespace.
    EmptyValue,
}

/// Provides one replaceable parsing behavior for delimited entries.
pub trait EntryParser {
    /// Parses one entry according to this implementation's delimiter.
    fn parse(&self, input: &str) -> Result<Entry, ParseError>;
}

/// Parses key-value entries separated by an equals sign.
pub struct EqualsParser;

/// Implements the parser contract for equals-delimited input.
impl EntryParser for EqualsParser {
    /// Parses the input using the equals sign.
    fn parse(&self, input: &str) -> Result<Entry, ParseError> {
        parse_delimited(input, '=')
    }
}

/// Parses key-value entries separated by a colon.
pub struct ColonParser;

/// Implements the parser contract for colon-delimited input.
impl EntryParser for ColonParser {
    /// Parses the input using the configured colon delimiter.
    fn parse(&self, input: &str) -> Result<Entry, ParseError> {
        // TODO: Use this parser's colon delimiter instead of the equals sign.
        parse_delimited(input, '=')
    }
}

/// Splits at the first delimiter and validates both trimmed fields.
fn parse_delimited(input: &str, delimiter: char) -> Result<Entry, ParseError> {
    let (key, value) = input
        .split_once(delimiter)
        .ok_or(ParseError::MissingDelimiter(delimiter))?;
    let key = key.trim();
    let value = value.trim();
    if key.is_empty() {
        return Err(ParseError::EmptyKey);
    }
    if value.is_empty() {
        return Err(ParseError::EmptyValue);
    }
    Ok(Entry {
        key: key.to_owned(),
        value: value.to_owned(),
    })
}

/// Renders one entry in a canonical form through any parser implementation.
pub fn render_label<P: EntryParser>(parser: &P, input: &str) -> Result<String, ParseError> {
    let entry = parser.parse(input)?;
    Ok(format!("{}={}", entry.key, entry.value))
}
