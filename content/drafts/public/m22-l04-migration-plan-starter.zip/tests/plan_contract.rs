use m22_l04_migration_plan::{MigrationPlan, MigrationStep, PlanError, validate};

fn safe_steps() -> Vec<MigrationStep> {
    vec![
        MigrationStep::Expand,
        MigrationStep::DeployCompatible,
        MigrationStep::Backfill,
        MigrationStep::VerifyBackfill,
        MigrationStep::SwitchReads,
        MigrationStep::CloseRollbackWindow,
        MigrationStep::Contract,
    ]
}

/// An explicit expand-contract plan validates when each stage is ordered.
#[test]
fn accepts_compatible_expand_contract_plan() {
    assert_eq!(
        validate(&MigrationPlan {
            steps: safe_steps()
        }),
        Ok(())
    );
}

/// Destructive contract must wait until the application rollback window closes.
#[test]
fn rejects_contract_before_rollback_window_closes() {
    let mut steps = safe_steps();
    steps.swap(5, 6);

    assert_eq!(
        validate(&MigrationPlan { steps }),
        Err(PlanError::OutOfOrder {
            before: MigrationStep::CloseRollbackWindow,
            after: MigrationStep::Contract,
        }),
    );
}

/// New reads must not switch before backfill verification.
#[test]
fn rejects_switch_before_backfill_verification() {
    let mut steps = safe_steps();
    steps.swap(3, 4);

    assert_eq!(
        validate(&MigrationPlan { steps }),
        Err(PlanError::OutOfOrder {
            before: MigrationStep::VerifyBackfill,
            after: MigrationStep::SwitchReads,
        }),
    );
}

/// The compatibility release cannot be omitted from a mixed-version rollout.
#[test]
fn rejects_missing_compatible_application_step() {
    let mut steps = safe_steps();
    steps.remove(1);

    assert_eq!(
        validate(&MigrationPlan { steps }),
        Err(PlanError::Missing(MigrationStep::DeployCompatible)),
    );
}
