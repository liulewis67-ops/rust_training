//! M22-L04 expand/backfill/switch/contract migration-plan exercise.

/// Ordered stages for a backward-compatible schema change.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum MigrationStep {
    /// Add new schema while retaining the old schema.
    Expand,
    /// Deploy code that works with both schema representations.
    DeployCompatible,
    /// Populate the new representation in bounded, restartable batches.
    Backfill,
    /// Check that old and new representations satisfy domain invariants.
    VerifyBackfill,
    /// Move reads to the new representation while compatibility remains.
    SwitchReads,
    /// Retire binaries that require the old schema and close their rollback window.
    CloseRollbackWindow,
    /// Remove the old schema in a separate destructive change.
    Contract,
}

/// A proposed release sequence for an application/schema transition.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationPlan {
    /// Planned stages in the order operators intend to execute them.
    pub steps: Vec<MigrationStep>,
}

/// A deterministic migration plan validation error.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum PlanError {
    /// The plan omitted a required stage.
    Missing(MigrationStep),
    /// The plan repeats a stage, obscuring which execution it describes.
    Duplicate(MigrationStep),
    /// A required earlier stage occurs after a dependent later stage.
    OutOfOrder {
        /// The earlier stage that must run first.
        before: MigrationStep,
        /// The dependent stage that currently appears first.
        after: MigrationStep,
    },
}

/// Validates that expand, compatibility, backfill, verification, and contract stages are ordered.
///
/// This starter intentionally accepts every plan without enforcing the migration window.
///
/// # Errors
///
/// Returns `Missing`, `Duplicate`, or `OutOfOrder` when the plan cannot preserve the
/// declared application compatibility window.
pub fn validate(_plan: &MigrationPlan) -> Result<(), PlanError> {
    Ok(())
}
