# M22-L04 schema migration plan starter

Run `cargo test --locked` on Windows to find plans accepted despite breaking the compatibility window or omitting backfill verification. The validator operates only on a synthetic ordered plan. It does not parse SQL, connect to PostgreSQL, execute migrations, estimate locks, or restore data.
