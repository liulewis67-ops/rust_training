//! M21-L04 minimal reproduction for a threshold regression.

/// One fixed-window signal snapshot used by the minimal reproduction.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct SignalSnapshot {
    /// Query latency p95 in milliseconds.
    pub query_p95_ms: u64,
    /// Pool acquisition latency p95 in milliseconds.
    pub acquire_wait_p95_ms: u64,
    /// Number of queued jobs.
    pub queue_depth: u32,
    /// Maximum number of queue slots, or zero when unobserved.
    pub queue_capacity: u32,
    /// Number of checked-out database connections.
    pub pool_in_use: u32,
    /// Maximum database pool connections.
    pub pool_max: u32,
}

/// A contract-level finding from the snapshot.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Finding {
    /// Query latency met or exceeded the lesson's threshold.
    SlowQuery,
    /// Pool acquisition is slow while all configured connections are in use.
    PoolPressure,
    /// Queue depth reached 80 percent of known capacity.
    QueueBacklog,
}

/// Returns whether query latency crossed the configured inclusive threshold.
#[must_use]
pub fn query_breached_threshold(query_p95_ms: u64, threshold_ms: u64) -> bool {
    query_p95_ms > threshold_ms
}

/// Returns each finding that the snapshot independently supports.
#[must_use]
pub fn findings(snapshot: SignalSnapshot) -> Vec<Finding> {
    let mut findings = Vec::new();
    if query_breached_threshold(snapshot.query_p95_ms, 250) {
        findings.push(Finding::SlowQuery);
    }
    if snapshot.acquire_wait_p95_ms >= 50
        && snapshot.pool_max > 0
        && snapshot.pool_in_use >= snapshot.pool_max
    {
        findings.push(Finding::PoolPressure);
    }
    if snapshot.queue_capacity > 0
        && u64::from(snapshot.queue_depth) * 100 >= u64::from(snapshot.queue_capacity) * 80
    {
        findings.push(Finding::QueueBacklog);
    }
    findings
}
