use m21_l04_reproduction::{Finding, SignalSnapshot, findings, query_breached_threshold};

/// Builds a healthy snapshot around which one regression boundary can be varied.
fn healthy_snapshot() -> SignalSnapshot {
    SignalSnapshot {
        query_p95_ms: 249,
        acquire_wait_p95_ms: 8,
        queue_depth: 2,
        queue_capacity: 100,
        pool_in_use: 4,
        pool_max: 16,
    }
}

/// The contract excludes the value immediately below its inclusive threshold.
#[test]
fn value_below_threshold_is_not_a_breach() {
    assert!(!query_breached_threshold(249, 250));
}

/// The exact threshold is a breach and pins the reported bug.
#[test]
fn exact_threshold_is_a_breach() {
    assert!(query_breached_threshold(250, 250));
}

/// Values above threshold continue to trigger after a boundary repair.
#[test]
fn value_above_threshold_is_a_breach() {
    assert!(query_breached_threshold(251, 250));
}

/// A finding remains visible in the complete diagnostic output.
#[test]
fn threshold_finding_is_preserved_in_snapshot() {
    let snapshot = SignalSnapshot {
        query_p95_ms: 250,
        ..healthy_snapshot()
    };
    assert_eq!(findings(snapshot), vec![Finding::SlowQuery]);
}

/// The fixture is otherwise healthy so this regression stays minimal.
#[test]
fn healthy_snapshot_has_no_findings() {
    assert!(findings(healthy_snapshot()).is_empty());
}
