# M21-L04 minimal reproduction starter

Run the exact boundary test first, record its failing input/output, and then repair the comparison. The fixture is pure Rust and uses the contract threshold of 250 ms. Restore a new attempt from `../m21-l04-reproduction-starter.zip` and verify `starter-manifest.json`. No database or Linux container is used.
