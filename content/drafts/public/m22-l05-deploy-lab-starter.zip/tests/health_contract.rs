use axum::body::Body;
use axum::http::{Request, StatusCode};
use m22_l05_deploy_lab::{AppState, app};
use tower::ServiceExt;

/// A ready revision passes liveness, readiness, and version checks.
#[tokio::test]
async fn reports_ready_revision_and_build_id() {
    let router = app(AppState {
        build_id: "snapshot-42".to_owned(),
        ready: true,
    });
    let ready = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/health/ready")
                .body(Body::empty())
                .expect("valid request"),
        )
        .await
        .expect("router response");
    let version = router
        .oneshot(
            Request::builder()
                .uri("/version")
                .body(Body::empty())
                .expect("valid request"),
        )
        .await
        .expect("router response");

    assert_eq!(ready.status(), StatusCode::OK);
    assert_eq!(version.status(), StatusCode::OK);
}

/// A failed readiness check stops traffic without making liveness fail.
#[tokio::test]
async fn blocked_revision_is_live_but_not_ready() {
    let router = app(AppState {
        build_id: "candidate-bad".to_owned(),
        ready: false,
    });
    let ready = router
        .clone()
        .oneshot(
            Request::builder()
                .uri("/health/ready")
                .body(Body::empty())
                .expect("valid request"),
        )
        .await
        .expect("router response");
    let live = router
        .oneshot(
            Request::builder()
                .uri("/health/live")
                .body(Body::empty())
                .expect("valid request"),
        )
        .await
        .expect("router response");

    assert_eq!(ready.status(), StatusCode::SERVICE_UNAVAILABLE);
    assert_eq!(live.status(), StatusCode::OK);
}
