//! Starts the M22-L05 sample service for the isolated deployment environment.

use std::error::Error;
use std::net::SocketAddr;

use m22_l05_deploy_lab::{AppState, app};
use tokio::net::TcpListener;

/// Reads non-secret build metadata and serves the health endpoints.
async fn run() -> Result<(), Box<dyn Error>> {
    let bind_addr = std::env::var("APP_ADDR")
        .unwrap_or_else(|_| "0.0.0.0:8080".to_owned())
        .parse::<SocketAddr>()
        .map_err(|_| "APP_ADDR must be a socket address")?;
    let build_id = std::env::var("APP_BUILD_ID").unwrap_or_else(|_| "local-dev".to_owned());
    let ready = !matches!(std::env::var("APP_READINESS").as_deref(), Ok("blocked"));
    let listener = TcpListener::bind(bind_addr).await?;
    axum::serve(listener, app(AppState { build_id, ready })).await?;
    Ok(())
}

/// Exits with an error when configuration or the HTTP server cannot start.
#[tokio::main]
async fn main() {
    if let Err(error) = run().await {
        eprintln!("deployment lab service failed to start: {error}");
        std::process::exit(1);
    }
}
