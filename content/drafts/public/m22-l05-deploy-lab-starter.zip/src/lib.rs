//! HTTP health and revision endpoints used by the M22-L05 deployment lab.

use axum::extract::State;
use axum::http::StatusCode;
use axum::routing::get;
use axum::{Json, Router};
use serde::Serialize;

/// Non-secret metadata for one running source revision.
#[derive(Clone)]
pub struct AppState {
    /// Build identifier recorded by the deployment platform.
    pub build_id: String,
    /// Whether this revision can receive application traffic.
    pub ready: bool,
}

/// Minimal health response without deployment credentials or host details.
#[derive(Debug, Serialize)]
pub struct HealthResponse {
    /// Stable health state label.
    pub status: &'static str,
    /// Non-secret build identifier.
    pub build_id: String,
}

/// Builds the HTTP routes checked by the isolated deployment environment.
pub fn app(state: AppState) -> Router {
    Router::new()
        .route("/health/live", get(live))
        .route("/health/ready", get(ready))
        .route("/version", get(version))
        .with_state(state)
}

/// Reports that the process can answer requests, independent of traffic readiness.
async fn live(State(state): State<AppState>) -> Json<HealthResponse> {
    Json(HealthResponse {
        status: "live",
        build_id: state.build_id,
    })
}

/// Reports whether this instance can receive traffic in the current revision.
async fn ready(State(state): State<AppState>) -> (StatusCode, Json<HealthResponse>) {
    let status = if state.ready {
        StatusCode::OK
    } else {
        StatusCode::SERVICE_UNAVAILABLE
    };
    let label = if state.ready { "ready" } else { "not_ready" };
    (
        status,
        Json(HealthResponse {
            status: label,
            build_id: state.build_id,
        }),
    )
}

/// Returns the immutable non-secret build identifier for revision comparison.
async fn version(State(state): State<AppState>) -> Json<HealthResponse> {
    Json(HealthResponse {
        status: "version",
        build_id: state.build_id,
    })
}
