# M22-L05 isolated deployment lab starter

This crate is the source artifact for the M22-L05 deployment lab. Build and run it only in the course-provided isolated environment after that environment supplies immutable builder/runtime image digests and target settings. The Dockerfile and deployment manifest are templates; no image, cluster, cloud account, or real secret is included. The local contract tests can run on Windows and do not prove a target image or deployment works.
