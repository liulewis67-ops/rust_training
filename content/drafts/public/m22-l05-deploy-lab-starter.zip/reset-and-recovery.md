# Reset and recovery

## Before a run

- Verify the runner-issued attempt ID, isolated namespace, expiration time, CPU/memory/replica/network caps, and cleanup operation.
- Record the runner-provided builder and runtime image references by digest. Stop if either is missing or platform/architecture is inconsistent with the selected Rust target.
- Confirm the source archive hash and preserve it read-only. Each attempt uses a fresh working copy.

## Candidate failure

- Stop rollout advancement when readiness does not pass. Do not bypass readiness or raise failure thresholds to force promotion.
- Record candidate revision, image digest, events, live/readiness statuses, and old healthy revision.
- Invoke rollback for the exact baseline revision recorded in the report. Confirm the baseline is Ready and serves its original build ID and digest.

## Teardown

- Ask the runner to stop deployments, revoke attempt-scoped credentials, remove the namespace and temporary networking, and wait for a final cleanup status.
- Save the cleanup receipt, then verify the runner reports zero remaining workloads/resources for the attempt.
- If rollback or cleanup fails, mark the attempt `platform_error`, isolate the namespace, and stop. Do not start another run in that namespace.

## Local reset

Delete only the attempt's extracted working copy, re-extract a fresh copy from the original ZIP, and compare each file against `starter-manifest.json`. Never overwrite the original archive or include build output in the evidence bundle.
