# M22-L05 deployment experiment report

## Attempt and environment

- Attempt ID / runner environment ID:
- Namespace and expiration:
- Resource quotas and allowed network targets:
- Runner, builder/runtime image digests, and target platform:
- Rust/Cargo versions:
- Starter archive SHA-256 / source snapshot / Cargo.lock SHA-256:

## Baseline deployment

- Build command and exit status:
- Release artifact SHA-256 / OCI image digest:
- Deployment revision and replicas:
- `/health/live`, `/health/ready`, `/version` evidence:
- Which revision and digest received traffic:

## Successful candidate

- One source change and why it is reversible:
- Candidate snapshot, artifact hash, image digest and revision:
- Ready count / rollout events / version endpoint:
- Evidence that the candidate received traffic only after readiness:

## Known-bad readiness candidate

- Patch and candidate snapshot identity:
- Expected live/readiness result:
- Observed rollout block and baseline retention evidence:
- Any unexpected traffic or controller behavior:

## Rollback and recovery

- Exact baseline revision/digest selected:
- Rollback command or runner operation ID:
- Post-rollback live/readiness/version output:
- Confirmation that the baseline receives traffic:

## Cleanup and evidence limits

- Teardown operation ID and final cleanup receipt:
- Remaining workloads/resources reported:
- Local tests, static template checks and live-environment checks listed separately:
- Deviations, platform errors and unresolved issues:
