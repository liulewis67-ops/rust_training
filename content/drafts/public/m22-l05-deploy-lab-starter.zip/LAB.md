# Isolated deployment task

## Starting snapshot

Use the source files and Cargo.lock in this directory as the baseline snapshot. Keep the source archive read-only; create a per-run working copy. The course runner must provide its exact builder/runtime image digests, target platform, resource quota, deployment namespace, and cleanup API before any deployment attempt.

## Tasks

1. Build the locked release artifact and record the source snapshot, target, profile, artifact hash, image digest, and deployment revision.
2. Deploy the baseline with two replicas. Verify `/health/live`, `/health/ready`, and `/version`; confirm both instances report the expected build ID before traffic is routed.
3. Make one non-secret source change, build a second immutable snapshot, and roll it out. Verify the new revision and digest are serving before the runner removes old replicas.
4. Inject the non-secret `APP_READINESS=blocked` setting from `known-bad/readiness-blocked.env` into a new candidate attempt. Build and request deployment. The failed readiness condition must block promotion and retain the healthy baseline.
5. Roll back to the exact recorded baseline revision and digest. Verify ready replicas, serving build ID, and the deployment controller's healthy status.
6. Follow `reset-and-recovery.md`; save the runner's cleanup result and confirm the namespace has no remaining workload.

## Required report

Copy `report-template.md` for the attempt. An experiment is incomplete if it has no live environment IDs, immutable artifact identity, probe output, failed-candidate observation, rollback proof, or teardown confirmation. A locally compiled executable or static YAML check fills none of those environment fields.
