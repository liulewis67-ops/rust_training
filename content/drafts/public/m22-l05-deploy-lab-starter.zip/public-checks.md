# Public lab checks

These checks describe observable outcomes; only the isolated course runner can produce the authoritative deployment evidence.

- Build metadata links the exact source snapshot, lockfile hash, declared Rust target/profile, artifact hash, image digest, and deployment revision.
- Baseline `/health/live`, `/health/ready`, and `/version` return expected status/build metadata; requests contain no secrets or host paths.
- A ready candidate is promoted only after readiness passes and uses the exact recorded image digest.
- With `APP_READINESS=blocked`, liveness stays successful while readiness returns `503`; rollout stops and baseline revision remains serving.
- Rollback selects the recorded baseline revision and digest; subsequent health/version observations match that baseline.
- Teardown revokes attempt credentials and returns a runner cleanup receipt with no remaining attempt workload.

Local Rust tests cover only route status behavior. YAML/template checks, `cargo test`, and `cargo build` do not satisfy the isolated deployment checks above.
