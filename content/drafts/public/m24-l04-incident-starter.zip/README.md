# M24-L04 incident and maintenance contracts

Implement complete action validation and the declared deterministic maintenance ordering. The ordering is a teaching contract, not a universal risk score.
