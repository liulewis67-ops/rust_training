//! Incident action and maintenance ordering contracts.

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct CorrectiveAction {
    pub title: String,
    pub owner_role: String,
    pub due_date: String,
    pub priority: String,
    pub evidence_ids: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ActionError {
    MissingTitle,
    MissingOwnerRole,
    MissingDueDate,
    MissingPriority,
    MissingEvidence,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MaintenanceCandidate {
    pub item_id: String,
    pub customer_impact: u8,
    pub repeat_likelihood: u8,
    pub effort_points: u16,
}

/// Validate that an incident action can be assigned and its completion verified.
pub fn validate_action(action: &CorrectiveAction) -> Result<(), ActionError> {
    if action.title.trim().is_empty() {
        return Err(ActionError::MissingTitle);
    }
    if action.priority.trim().is_empty() {
        return Err(ActionError::MissingPriority);
    }
    let _ = action;
    Ok(())
}

/// Rank a copy by impact, recurrence likelihood, effort, and stable ID tie-breaks.
pub fn rank_maintenance(candidates: &[MaintenanceCandidate]) -> Vec<MaintenanceCandidate> {
    let mut ranked = candidates.to_vec();
    ranked.sort_by(|left, right| {
        right
            .customer_impact
            .cmp(&left.customer_impact)
            .then_with(|| right.repeat_likelihood.cmp(&left.repeat_likelihood))
            .then_with(|| left.effort_points.cmp(&right.effort_points))
            .then_with(|| left.item_id.cmp(&right.item_id))
    });
    ranked
}
