use m24_l04_incident_starter::{
    ActionError, CorrectiveAction, MaintenanceCandidate, rank_maintenance, validate_action,
};

/// Build an action with an owner, deadline, and completion evidence.
fn valid_action() -> CorrectiveAction {
    CorrectiveAction {
        title: "Add queue claim timeout histogram".into(),
        owner_role: "service-owner".into(),
        due_date: "2026-11-01".into(),
        priority: "high".into(),
        evidence_ids: vec!["METRIC-QUEUE-17".into()],
    }
}

/// Accept a complete action item.
#[test]
fn accepts_complete_action() {
    assert_eq!(validate_action(&valid_action()), Ok(()));
}

/// Reject an action without an owner or due date.
#[test]
fn rejects_missing_owner_and_due_date() {
    let mut action = valid_action();
    action.owner_role = "   ".into();
    assert_eq!(validate_action(&action), Err(ActionError::MissingOwnerRole));
    let mut action = valid_action();
    action.due_date.clear();
    assert_eq!(validate_action(&action), Err(ActionError::MissingDueDate));
}

/// Reject actions without evidence that completion can be verified.
#[test]
fn rejects_missing_completion_evidence() {
    let mut action = valid_action();
    action.evidence_ids.clear();
    assert_eq!(validate_action(&action), Err(ActionError::MissingEvidence));
}

/// Sort by the documented tuple and leave the input order untouched.
#[test]
fn ranks_maintenance_deterministically() {
    let low = MaintenanceCandidate {
        item_id: "MNT-03".into(),
        customer_impact: 2,
        repeat_likelihood: 4,
        effort_points: 1,
    };
    let high = MaintenanceCandidate {
        item_id: "MNT-02".into(),
        customer_impact: 5,
        repeat_likelihood: 2,
        effort_points: 8,
    };
    let tie = MaintenanceCandidate {
        item_id: "MNT-01".into(),
        customer_impact: 5,
        repeat_likelihood: 2,
        effort_points: 3,
    };
    assert_eq!(
        rank_maintenance(&[low.clone(), high, tie]),
        vec![
            MaintenanceCandidate {
                item_id: "MNT-01".into(),
                customer_impact: 5,
                repeat_likelihood: 2,
                effort_points: 3,
            },
            MaintenanceCandidate {
                item_id: "MNT-02".into(),
                customer_impact: 5,
                repeat_likelihood: 2,
                effort_points: 8,
            },
            low,
        ]
    );
}
