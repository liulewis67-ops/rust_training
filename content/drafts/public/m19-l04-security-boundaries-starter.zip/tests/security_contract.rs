use axum::body::Body;
use axum::http::{Request, StatusCode};
use http_body_util::BodyExt;
use m19_l04_security_boundaries::{
    MAX_BODY_BYTES, StoredPassword, app, load_secret, validate_password,
};
use std::fmt::Debug;
use std::sync::{Arc, Mutex};
use tower::ServiceExt;
use tracing::field::{Field, Visit};
use tracing::{Event, Id, Metadata, Subscriber};

#[derive(Clone)]
struct CaptureSubscriber(Arc<Mutex<Vec<String>>>);

impl Subscriber for CaptureSubscriber {
    fn enabled(&self, _: &Metadata<'_>) -> bool {
        true
    }

    fn new_span(&self, _: &tracing::span::Attributes<'_>) -> Id {
        Id::from_u64(1)
    }

    fn record(&self, _: &Id, _: &tracing::span::Record<'_>) {}

    fn record_follows_from(&self, _: &Id, _: &Id) {}

    fn event(&self, event: &Event<'_>) {
        let mut visitor = FieldCapture::default();
        event.record(&mut visitor);
        if let Ok(mut fields) = self.0.lock() {
            fields.extend(visitor.0);
        }
    }

    fn enter(&self, _: &Id) {}

    fn exit(&self, _: &Id) {}
}

#[derive(Default)]
struct FieldCapture(Vec<String>);

impl Visit for FieldCapture {
    fn record_debug(&mut self, field: &Field, value: &dyn Debug) {
        self.0.push(format!("{}={value:?}", field.name()));
    }
}

#[test]
fn password_policy_has_minimum_maximum_and_byte_ceiling() {
    assert!(validate_password("twelve chars").is_ok());
    assert!(validate_password(&"a".repeat(128)).is_ok());
    assert_eq!(validate_password("short"), Err("invalid_password"));
    assert_eq!(validate_password(&"a".repeat(129)), Err("invalid_password"));
    assert_eq!(
        validate_password(&"界".repeat(171)),
        Err("invalid_password")
    );
}

#[test]
fn stored_password_is_not_plaintext_and_verifies_only_the_candidate() {
    let stored = StoredPassword::new("correct horse battery").expect("valid fixture");
    assert!(!format!("{stored:?}").contains("correct horse battery"));
    assert!(stored.verify("correct horse battery"));
    assert!(!stored.verify("wrong password value"));
}

#[test]
fn hashing_same_password_uses_independent_salts() {
    let first = StoredPassword::new("correct horse battery").expect("valid fixture");
    let second = StoredPassword::new("correct horse battery").expect("valid fixture");
    assert_ne!(first, second);
}

#[test]
fn secret_debug_and_configuration_error_redact_values() {
    let sentinel = "smtp-password-sentinel";
    let secret = load_secret("SMTP_PASSWORD", Some(sentinel)).expect("present secret");
    assert_eq!(secret.expose(), sentinel);
    assert!(!format!("{secret:?}").contains(sentinel));
    let error = load_secret("SMTP_PASSWORD", None).expect_err("missing secret");
    assert!(!error.contains(sentinel));
    assert!(error.contains("SMTP_PASSWORD"));
}

#[tokio::test]
async fn router_rejects_oversized_body_before_json_handler() {
    let body = format!("{{\"password\":\"{}\"}}", "x".repeat(MAX_BODY_BYTES + 1));
    let response = app()
        .oneshot(
            Request::post("/api/v1/password/check-input")
                .header("content-type", "application/json")
                .body(Body::from(body))
                .expect("request"),
        )
        .await
        .expect("response");
    assert_eq!(response.status(), StatusCode::PAYLOAD_TOO_LARGE);
}

#[tokio::test]
async fn router_accepts_policy_valid_json_input() {
    let response = app()
        .oneshot(
            Request::post("/api/v1/password/check-input")
                .header("content-type", "application/json")
                .body(Body::from(r#"{"password":"a sufficiently long password"}"#))
                .expect("request"),
        )
        .await
        .expect("response");
    assert_eq!(response.status(), StatusCode::OK);
}

#[tokio::test]
async fn handler_does_not_emit_secret_sentinel_in_response_body() {
    let sentinel = "password-log-sentinel";
    let captured = Arc::new(Mutex::new(Vec::new()));
    let guard = tracing::subscriber::set_default(CaptureSubscriber(Arc::clone(&captured)));
    let response = app()
        .oneshot(
            Request::post("/api/v1/password/check-input")
                .header("content-type", "application/json")
                .body(Body::from(format!(r#"{{"password":"{sentinel}"}}"#)))
                .expect("request"),
        )
        .await
        .expect("response");
    let body = response
        .into_body()
        .collect()
        .await
        .expect("body")
        .to_bytes();
    drop(guard);
    assert!(!String::from_utf8_lossy(&body).contains(sentinel));
    let fields = captured.lock().expect("captured log fields").join(" ");
    assert!(
        !fields.contains(sentinel),
        "tracing fields leaked a password sentinel"
    );
}
