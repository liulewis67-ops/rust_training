# M19-L04 public starter

This intentionally incomplete Rust package is a teaching fixture, not an authentication service. Run `cargo test --locked` after the author supplies the missing boundaries. The password endpoint accepts no account or session and must not be deployed.

The starter currently stores plaintext, has an incomplete password policy, exposes secret values through `Debug`, and logs a password. Those are deliberate repair targets.
