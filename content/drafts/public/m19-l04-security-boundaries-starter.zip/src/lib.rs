//! Starter for password, secret, input, and logging boundaries.

use axum::extract::DefaultBodyLimit;
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::routing::post;
use axum::{Json, Router};
use serde::{Deserialize, Serialize};

/// Maximum accepted JSON body for the small boundary demonstration.
pub const MAX_BODY_BYTES: usize = 1024;

/// Validates the lesson password length contract: 12–128 Unicode scalar values and at most 512 bytes.
///
/// # Errors
///
/// Returns `invalid_password` when the input violates the lesson contract.
pub fn validate_password(password: &str) -> Result<(), &'static str> {
    // TODO: enforce both the UTF-8 byte ceiling and the character-count interval.
    if password.is_empty() {
        Err("invalid_password")
    } else {
        Ok(())
    }
}

/// Stores a password for later verification.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct StoredPassword(pub String);

impl StoredPassword {
    /// Creates a stored password from user input.
    ///
    /// # Errors
    ///
    /// Returns `invalid_password` when the password violates the lesson contract.
    pub fn new(password: &str) -> Result<Self, &'static str> {
        validate_password(password)?;
        // TODO: replace plaintext storage with a maintained Argon2id PHC hash and unique salt.
        Ok(Self(password.to_owned()))
    }

    /// Checks a candidate password against the stored representation.
    #[must_use]
    pub fn verify(&self, candidate: &str) -> bool {
        self.0 == candidate
    }
}

/// A secret that must not appear when debug-formatted.
#[derive(Clone, PartialEq, Eq)]
pub struct SecretValue(String);

impl SecretValue {
    /// Returns the secret only for an explicitly authorized use site.
    #[must_use]
    pub fn expose(&self) -> &str {
        &self.0
    }
}

impl std::fmt::Debug for SecretValue {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        // TODO: do not include the underlying value in Debug output.
        formatter.debug_tuple("SecretValue").field(&self.0).finish()
    }
}

/// Loads a required secret without echoing a supplied value in errors.
///
/// # Errors
///
/// Returns an error naming the configuration key when its value is absent or empty.
pub fn load_secret(name: &str, value: Option<&str>) -> Result<SecretValue, String> {
    match value.filter(|value| !value.is_empty()) {
        Some(value) => Ok(SecretValue(value.to_owned())),
        None => Err(format!("required secret {name} is missing")),
    }
}

/// Creates a router whose only route demonstrates a bounded, validated request body.
pub fn app() -> Router {
    Router::new()
        .route("/api/v1/password/check-input", post(check_input))
        .layer(DefaultBodyLimit::max(MAX_BODY_BYTES))
}

#[derive(Debug, Deserialize)]
struct PasswordRequest {
    password: String,
}

#[derive(Debug, Serialize)]
struct InputAccepted {
    accepted: bool,
}

async fn check_input(Json(request): Json<PasswordRequest>) -> Response {
    let valid = validate_password(&request.password).is_ok();
    // TODO: emit only allow-listed fields; never interpolate request data or credentials.
    tracing::info!(password = %request.password, valid, "password input checked");
    if valid {
        (StatusCode::OK, Json(InputAccepted { accepted: true })).into_response()
    } else {
        (
            StatusCode::UNPROCESSABLE_ENTITY,
            Json(InputAccepted { accepted: false }),
        )
            .into_response()
    }
}
