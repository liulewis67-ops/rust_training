//! Axum Server-sent events connection lifecycle exercise.

use std::convert::Infallible;
use std::future;
use std::sync::Arc;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};

use axum::extract::State;
use axum::response::sse::{Event, KeepAlive, Sse};
use axum::routing::get;
use axum::{Router, response::IntoResponse};
use futures_util::stream;
use tokio::sync::broadcast;

/// An event with a stable connection-visible sequence identifier.
#[derive(Clone, Debug)]
struct PublishedEvent {
    /// Monotonic process-local identifier for this teaching fixture.
    sequence: u64,
    /// Public event body sent to the SSE subscriber.
    payload: String,
}

/// Shared state for the SSE route and deterministic lifecycle assertions.
#[derive(Clone, Debug)]
struct AppState {
    /// Broadcast bus shared by independent SSE streams.
    events: broadcast::Sender<PublishedEvent>,
    /// Number of live subscription resources owned by response streams.
    active_subscriptions: Arc<AtomicUsize>,
}

/// Test control handle for publishing events and observing live subscriptions.
#[derive(Clone, Debug)]
pub struct TestControl {
    /// Broadcast publisher for deterministic integration tests.
    events: broadcast::Sender<PublishedEvent>,
    /// Counter read by tests to prove each stream releases its subscription.
    active_subscriptions: Arc<AtomicUsize>,
    /// Next process-local event sequence number.
    next_sequence: Arc<AtomicU64>,
}

impl TestControl {
    /// Publishes one test event and returns its assigned sequence number.
    ///
    /// # Errors
    /// Returns a safe message when no stream currently subscribes.
    pub fn publish(&self, payload: impl Into<String>) -> Result<u64, String> {
        let sequence = self.next_sequence.fetch_add(1, Ordering::SeqCst) + 1;
        let event = PublishedEvent {
            sequence,
            payload: payload.into(),
        };
        self.events
            .send(event)
            .map(|_| sequence)
            .map_err(|_| String::from("no active SSE subscriber"))
    }

    /// Returns the number of stream-owned subscription resources that are alive.
    #[must_use]
    pub fn active_subscriptions(&self) -> usize {
        self.active_subscriptions.load(Ordering::SeqCst)
    }
}

/// Counts one SSE subscription and releases it when the guard is dropped.
#[derive(Debug)]
struct SubscriptionGuard {
    /// Shared live subscription counter used only by this local teaching fixture.
    active_subscriptions: Arc<AtomicUsize>,
}

impl SubscriptionGuard {
    /// Registers one active stream resource.
    fn new(active_subscriptions: Arc<AtomicUsize>) -> Self {
        active_subscriptions.fetch_add(1, Ordering::SeqCst);
        Self {
            active_subscriptions,
        }
    }
}

impl Drop for SubscriptionGuard {
    /// Releases the subscription counter when the owning stream is cancelled or dropped.
    fn drop(&mut self) {
        self.active_subscriptions.fetch_sub(1, Ordering::SeqCst);
    }
}

/// Creates an SSE router and a test control for deterministic event publishing.
pub fn app() -> (Router, TestControl) {
    let (events, _) = broadcast::channel(32);
    let active_subscriptions = Arc::new(AtomicUsize::new(0));
    let next_sequence = Arc::new(AtomicU64::new(0));
    let state = AppState {
        events: events.clone(),
        active_subscriptions: Arc::clone(&active_subscriptions),
    };
    let control = TestControl {
        events,
        active_subscriptions,
        next_sequence,
    };
    let router = Router::new()
        .route("/events", get(sse_handler))
        .with_state(state);
    (router, control)
}

/// Opens a Server-sent events response for one independently tracked subscriber.
async fn sse_handler(State(state): State<AppState>) -> impl IntoResponse {
    let receiver = state.events.subscribe();
    let guard = SubscriptionGuard::new(Arc::clone(&state.active_subscriptions));

    // TODO(M20-L03): keep the subscription guard inside the response stream so body drop cancels it.
    tokio::spawn(async move {
        let _guard = guard;
        future::pending::<()>().await;
    });

    let event_stream = stream::unfold(receiver, |mut receiver| async move {
        loop {
            match receiver.recv().await {
                Ok(event) => {
                    let frame = Event::default()
                        .id(event.sequence.to_string())
                        .data(event.payload);
                    return Some((Ok::<Event, Infallible>(frame), receiver));
                }
                // Broadcast lag is tolerated in this ephemeral stream; durable replay is a later unit.
                Err(broadcast::error::RecvError::Lagged(_)) => (),
                Err(broadcast::error::RecvError::Closed) => return None,
            }
        }
    });

    Sse::new(event_stream).keep_alive(KeepAlive::default())
}
