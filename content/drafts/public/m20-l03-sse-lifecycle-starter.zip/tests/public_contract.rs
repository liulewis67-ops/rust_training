//! Public HTTP contracts for SSE subscription lifetime and event framing.

use axum::body::Body;
use axum::http::header::CONTENT_TYPE;
use axum::http::{Request, Response};
use http_body_util::BodyExt;
use m20_l03_sse_lifecycle::{TestControl, app};
use tokio::time::{Duration, timeout};
use tower::ServiceExt;

/// Creates a valid GET request for the SSE endpoint.
fn event_request() -> Request<Body> {
    Request::builder()
        .uri("/events")
        .body(Body::empty())
        .expect("the static SSE test request should be valid")
}

/// Opens one response body and verifies the service accepted the request.
async fn open_events(router: axum::Router) -> Response<Body> {
    router
        .oneshot(event_request())
        .await
        .expect("the in-process SSE router should answer")
}

/// Confirms the route uses the browser event-stream media type.
#[tokio::test]
async fn responds_with_event_stream_content_type() {
    let (router, _) = app();
    let response = open_events(router).await;

    assert_eq!(
        response
            .headers()
            .get(CONTENT_TYPE)
            .and_then(|value| value.to_str().ok()),
        Some("text/event-stream"),
    );
}

/// Dropping the HTTP response body must release the connection's subscription resource.
#[tokio::test]
async fn disconnect_releases_subscription_resource() {
    let (router, control) = app();
    let response = open_events(router).await;
    assert_eq!(control.active_subscriptions(), 1);

    drop(response);

    assert_eq!(control.active_subscriptions(), 0);
}

/// Two connections own independent subscriptions and dropping one leaves the other alive.
#[tokio::test]
async fn disconnect_only_releases_its_own_subscription() {
    let (router, control) = app();
    let first = open_events(router.clone()).await;
    let second = open_events(router).await;
    assert_eq!(control.active_subscriptions(), 2);

    drop(first);
    assert_eq!(control.active_subscriptions(), 1);

    drop(second);
    assert_eq!(control.active_subscriptions(), 0);
}

/// A connected client receives an SSE frame with its sequence ID and data.
#[tokio::test]
async fn emits_an_identified_event_frame() {
    let (router, control): (_, TestControl) = app();
    let mut response = open_events(router).await;
    assert_eq!(control.publish("task.updated"), Ok(1));

    let frame = timeout(Duration::from_secs(1), response.body_mut().frame())
        .await
        .expect("an active subscriber should receive the event before its deadline")
        .expect("the SSE body should yield a frame")
        .expect("the SSE frame should not contain an error")
        .into_data()
        .expect("an SSE event should be sent as data");
    let text = String::from_utf8_lossy(&frame);

    assert!(text.contains("id: 1"));
    assert!(text.contains("data: task.updated"));
}
