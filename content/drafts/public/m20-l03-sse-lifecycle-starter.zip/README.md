# M20-L03 SSE Lifecycle Starter

This Axum 0.8.9 crate opens an SSE route and instruments one resource per live response body. The baseline intentionally moves its subscription guard into an untracked background task; dropping the client body therefore leaves the task and resource alive. Complete the TODO so the response stream owns the guard and cancellation drops it.

Run with `cargo test --locked`. The tests use in-process Router requests, a broadcast fixture, and a bounded receive timeout. They do not start a server or depend on Linux/PostgreSQL. Durable replay and event authorization are separate contracts in the I10-F02 package.
