//! Public retry policy contracts for M20-L02.

use m20_l02_retry_policy::{
    FailureClass, OperationSafety, RetryPolicy, attempt_timeout_ms, backoff_cap_ms, may_retry,
    next_delay_ms,
};

/// Creates the fixed API retry contract used by all public cases.
fn policy() -> RetryPolicy {
    RetryPolicy {
        max_attempts: 4,
        per_attempt_ms: 300,
        max_delay_ms: 800,
        base_delay_ms: 100,
    }
}

/// Permanent request errors must stop without another call.
#[test]
fn stops_on_permanent_failure() {
    assert!(!may_retry(
        FailureClass::Permanent,
        OperationSafety::ReadOnly,
        1,
        policy().max_attempts,
    ));
}

/// A write without idempotency protection must not repeat after an uncertain timeout.
#[test]
fn stops_on_unsafe_write_timeout() {
    assert!(!may_retry(
        FailureClass::Timeout,
        OperationSafety::NonIdempotent,
        1,
        policy().max_attempts,
    ));
}

/// A retry-safe write can retry a transient failure while attempts remain.
#[test]
fn retries_idempotency_protected_transient_failure() {
    assert!(may_retry(
        FailureClass::Transient,
        OperationSafety::IdempotencyProtected,
        1,
        policy().max_attempts,
    ));
}

/// The configured maximum includes the initial call.
#[test]
fn stops_after_maximum_attempts() {
    assert!(!may_retry(
        FailureClass::Transient,
        OperationSafety::ReadOnly,
        4,
        policy().max_attempts,
    ));
}

/// The caller-provided jitter sample determines the first bounded delay.
#[test]
fn uses_jitter_sample_within_first_backoff_window() {
    assert_eq!(next_delay_ms(policy(), 0, 60, None, 500), Some(60));
}

/// A server delay that cannot fit the total deadline must stop instead of retrying early.
#[test]
fn stops_when_retry_after_exceeds_remaining_budget() {
    assert_eq!(next_delay_ms(policy(), 0, 40, Some(2_000), 1_000), None);
}

/// The delay must be at least the server's requested minimum when it fits the budget.
#[test]
fn honors_retry_after_minimum() {
    assert_eq!(next_delay_ms(policy(), 0, 40, Some(300), 500), Some(300));
}

/// Each attempt is bounded by both its configured timeout and remaining operation time.
#[test]
fn limits_attempt_to_remaining_budget() {
    assert_eq!(attempt_timeout_ms(policy(), 100), 100);
}

/// Exponential delay ceilings grow and stop at the configured maximum.
#[test]
fn grows_exponential_backoff_to_cap() {
    assert_eq!(backoff_cap_ms(policy(), 0), 100);
    assert_eq!(backoff_cap_ms(policy(), 3), 800);
}

/// Invalid jitter samples must be rejected instead of creating an unbounded delay.
#[test]
fn rejects_jitter_above_backoff_ceiling() {
    assert_eq!(next_delay_ms(policy(), 0, 101, None, 500), None);
}
