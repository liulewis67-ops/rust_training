//! Deterministic retry classification and delay policy exercise.

/// Describes a failure class that the caller has already mapped from its API.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FailureClass {
    /// The unchanged request is invalid or permanently denied.
    Permanent,
    /// The remote outcome is unknown because an attempt timed out.
    Timeout,
    /// A dependency failure is considered temporary by the API contract.
    Transient,
    /// The server asked the caller to slow down for a bounded interval.
    RateLimited,
}

/// States whether repeating the logical operation can duplicate a side effect.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum OperationSafety {
    /// Repeating this operation has no business side effect.
    ReadOnly,
    /// The write is protected by a stable idempotency key.
    IdempotencyProtected,
    /// Repeating this write can create another business effect.
    NonIdempotent,
}

/// Holds explicit bounds used by the retry scheduler.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct RetryPolicy {
    /// Maximum total calls, including the first attempt.
    pub max_attempts: u32,
    /// Maximum time allowed for one call, in milliseconds.
    pub per_attempt_ms: u64,
    /// Maximum delay between calls, in milliseconds.
    pub max_delay_ms: u64,
    /// Initial exponential backoff ceiling, in milliseconds.
    pub base_delay_ms: u64,
}

/// Decides whether another call is safe and fits within the attempt limit.
///
/// `attempts_made` includes the initial call. The caller must also check the
/// total operation deadline before starting the returned retry.
#[must_use]
pub fn may_retry(
    failure: FailureClass,
    safety: OperationSafety,
    attempts_made: u32,
    max_attempts: u32,
) -> bool {
    // TODO(M20-L02): classify permanent failures and unsafe side effects before retrying.
    let _ = (failure, safety, attempts_made, max_attempts);
    true
}

/// Selects a bounded delay or stops when the server delay exceeds the remaining budget.
///
/// `retry_index` is zero for the first retry. `jitter_sample_ms` must be within
/// the computed exponential ceiling; invalid samples return `None`.
#[must_use]
pub fn next_delay_ms(
    policy: RetryPolicy,
    retry_index: u32,
    jitter_sample_ms: u64,
    retry_after_ms: Option<u64>,
    remaining_budget_ms: u64,
) -> Option<u64> {
    // TODO(M20-L02): apply capped exponential jitter, Retry-After, and the total deadline.
    let _ = (policy, retry_index, retry_after_ms, remaining_budget_ms);
    Some(jitter_sample_ms)
}

/// Limits one attempt to the time left in the complete logical operation.
#[must_use]
pub fn attempt_timeout_ms(policy: RetryPolicy, remaining_budget_ms: u64) -> u64 {
    // TODO(M20-L02): do not let a single attempt exceed the remaining deadline.
    let _ = remaining_budget_ms;
    policy.per_attempt_ms
}

/// Calculates the capped exponential ceiling without overflowing for large retry indices.
#[must_use]
pub fn backoff_cap_ms(policy: RetryPolicy, retry_index: u32) -> u64 {
    // TODO(M20-L02): use checked/saturating growth and stop at the configured maximum.
    let _ = retry_index;
    policy.base_delay_ms.min(policy.max_delay_ms)
}
