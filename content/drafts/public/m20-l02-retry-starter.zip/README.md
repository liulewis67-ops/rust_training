# M20-L02 Retry Policy Starter

This crate is a deterministic policy exercise, not a production HTTP client. Its baseline intentionally retries permanent errors and unsafe writes, ignores the configured deadline, and does not cap exponential delay. Complete the TODOs in `src/lib.rs` without weakening `tests/public_contract.rs`.

Run locally with `cargo test --locked`. The pure delay function accepts an injected jitter sample, so tests do not sleep, use randomness, or contact a service. The reference solution and hidden variations remain outside the public starter.
