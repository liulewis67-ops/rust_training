# Lab task

1. Keep `baseline.json` unchanged and copy one entry from `scenarios.json` into a new attempt directory.
2. Complete `report-template.md` with observed deltas, one falsifiable hypothesis, alternatives and one changed variable.
3. Compare `after_injection` and `after_single_change`; state which prediction held and which signals stayed stable.
4. Verify the input JSON and starter manifest still match the original snapshot.
5. Repeat from a new extraction for each scenario. Do not claim any synthetic card is a real service fault injection.

Reset: extract the original ZIP into a different empty directory, verify the manifest, and start with a fresh copy of `baseline.json`. The archive is the immutable source of truth.
