# M21-L05 fault lab starter

This package contains fixed synthetic scenario cards and a report template. It does not start services or inject a real database/queue failure. Run `cargo` only if your separate implementation requires it; this author-side teaching pack is documentation plus JSON evidence data. For a new attempt, extract `../m21-l05-fault-lab-starter.zip` to a new folder and verify every file in `starter-manifest.json`. Never edit `scenarios.json` in the original archive.
