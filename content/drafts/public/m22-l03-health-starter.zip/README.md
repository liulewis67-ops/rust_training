# M22-L03 health and rollout starter

Run `cargo test --locked` on Windows to find the health endpoint baseline that reports every probe as successful. The fixture is a pure in-memory model: it does not start an HTTP server, CI workflow, container, Kubernetes cluster, or rollout. Use the lesson's static workflow only to reason about job dependencies.
