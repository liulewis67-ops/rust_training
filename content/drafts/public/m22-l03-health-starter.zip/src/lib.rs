//! M22-L03 startup, readiness, liveness, and rollout contract exercise.

/// Simplified internal state used to reason about probe behavior.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ServiceState {
    /// The process is loading configuration and initializing resources.
    Starting,
    /// The process can accept normal requests.
    Ready,
    /// A dependency prevents useful requests, but the process can recover.
    DependencyUnavailable,
    /// The process cannot make progress and needs a restart.
    Stalled,
}

/// The three independently interpreted probe results.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ProbeReport {
    /// Whether startup has completed.
    pub startup_complete: bool,
    /// Whether the instance should receive new traffic.
    pub ready: bool,
    /// Whether the process can make progress without restart.
    pub live: bool,
}

/// Returns probe results for the current service state.
///
/// This starter intentionally treats every process state as healthy.
#[must_use]
pub const fn probe_report(_state: ServiceState) -> ProbeReport {
    ProbeReport {
        startup_complete: true,
        ready: true,
        live: true,
    }
}
