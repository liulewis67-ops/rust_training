use m22_l03_health::{ProbeReport, ServiceState, probe_report};

/// Initialization cannot receive traffic before startup is complete.
#[test]
fn starting_instance_is_not_ready() {
    assert_eq!(
        probe_report(ServiceState::Starting),
        ProbeReport {
            startup_complete: false,
            ready: false,
            live: true,
        },
    );
}

/// A fully initialized and responsive instance passes all probes.
#[test]
fn ready_instance_passes_all_probes() {
    assert_eq!(
        probe_report(ServiceState::Ready),
        ProbeReport {
            startup_complete: true,
            ready: true,
            live: true,
        },
    );
}

/// A temporary dependency outage removes traffic without restarting the process.
#[test]
fn dependency_outage_is_not_a_liveness_failure() {
    assert_eq!(
        probe_report(ServiceState::DependencyUnavailable),
        ProbeReport {
            startup_complete: true,
            ready: false,
            live: true,
        },
    );
}

/// A stuck process is removed from traffic and becomes eligible for restart.
#[test]
fn stalled_instance_fails_readiness_and_liveness() {
    assert_eq!(
        probe_report(ServiceState::Stalled),
        ProbeReport {
            startup_complete: true,
            ready: false,
            live: false,
        },
    );
}
