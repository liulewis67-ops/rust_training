# M10-L05 起始项目：P1 日志分析 CLI

本工作区是四阶段 P1 项目的可重置起点。请先阅读实验题面，再按 P1.1 到 P1.4 完成解析核心、CLI、流式处理与可复现交付。不要把教师参考实现复制到本目录。

## 项目契约

每条非空记录格式为 `timestamp_ms|LEVEL|message`。级别为 `ERROR`、`WARN`、`INFO` 或 `DEBUG`；消息可为空、包含额外竖线或 Unicode。完全空行跳过，格式错误须报告 1-based 行号并使整次运行失败，不得向 stdout 输出部分汇总。

CLI 支持文件或 stdin、重复 `--level`、含下界 `--from-ms`、不含上界 `--until-ms`、区分大小写的 `--contains` 和 `--format text|json`。参数错误退出 2；文件、I/O 与解析错误退出 1。成功报告写 stdout，诊断写 stderr。

`fixtures/public.log` 是公开样本；`fixtures/expected.txt` 与 `fixtures/expected.json` 是无筛选汇总。P1.3 还需在课程指定的 R2 环境、固定数据规模和内存预算下完成资源验收；本地测试不替代该验收。

## 起步与验证

```text
cargo fmt --all -- --check
cargo check --workspace --locked --offline
cargo test --workspace --locked --offline
cargo clippy --workspace --all-targets --locked --offline -- -D warnings
cargo doc --workspace --no-deps --locked --offline
```

基线预期能编译，并有一项公开行为断言因 message 内额外竖线未被保留而失败。定位并修复契约问题，补充回归测试，然后依次交付四个阶段。使用 `starter-manifest.json` 中的 SHA-256 校验原始文件；重置时从本 ZIP 重新解压到新目录，不要覆盖唯一的起始快照。

运行示例：

```text
cargo run -p log-cli --locked --offline -- --input fixtures/public.log --format json
```

详细任务、步骤、重置和证据要求见配套的 M10-L05 实验题面。公开 ZIP 不包含参考答案。
