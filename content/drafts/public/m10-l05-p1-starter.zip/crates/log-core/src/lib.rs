//! Parses log records, applies filters, and aggregates counts independently of the CLI.

use std::error::Error;
use std::fmt::{self, Display, Formatter};
use std::io::{self, BufRead};

/// The supported severity levels in their stable output order.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Level {
    /// An error event.
    Error,
    /// A warning event.
    Warn,
    /// An informational event.
    Info,
    /// A debugging event.
    Debug,
}

impl Level {
    /// Parses the exact uppercase name used by the log input format.
    #[must_use]
    pub fn parse(raw: &str) -> Option<Self> {
        match raw {
            "ERROR" => Some(Self::Error),
            "WARN" => Some(Self::Warn),
            "INFO" => Some(Self::Info),
            "DEBUG" => Some(Self::Debug),
            _ => None,
        }
    }

    /// Returns the stable uppercase spelling for reports.
    #[must_use]
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Error => "ERROR",
            Self::Warn => "WARN",
            Self::Info => "INFO",
            Self::Debug => "DEBUG",
        }
    }
}

/// One parsed log event with an owned message.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct LogRecord {
    /// Milliseconds since the Unix epoch.
    pub timestamp_ms: u64,
    /// Severity assigned to the event.
    pub level: Level,
    /// Message text after the second delimiter, including later delimiters.
    pub message: String,
}

/// A stable category for invalid log rows.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ParseErrorKind {
    /// The row is missing a timestamp, level, or message field.
    MissingField,
    /// The timestamp field is not an unsigned integer.
    InvalidTimestamp,
    /// The level field is not ERROR, WARN, INFO, or DEBUG.
    InvalidLevel,
}

/// Identifies a malformed row and its reason.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ParseError {
    /// One-based input line number.
    pub line: usize,
    /// The parsing failure category.
    pub kind: ParseErrorKind,
}

/// A filter applied before an event contributes to the report.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct LogFilter {
    /// If nonempty, only these severity levels are included.
    pub levels: Vec<Level>,
    /// Inclusive lower timestamp bound.
    pub from_ms: Option<u64>,
    /// Exclusive upper timestamp bound.
    pub until_ms: Option<u64>,
    /// Optional case-sensitive substring required in the message.
    pub contains: Option<String>,
}

impl LogFilter {
    /// Returns whether a parsed record satisfies every configured filter.
    fn accepts(&self, record: &LogRecord) -> bool {
        (self.levels.is_empty() || self.levels.contains(&record.level))
            && self
                .from_ms
                .is_none_or(|lower_bound| record.timestamp_ms >= lower_bound)
            && self
                .until_ms
                .is_none_or(|upper_bound| record.timestamp_ms < upper_bound)
            && self
                .contains
                .as_ref()
                .is_none_or(|needle| record.message.contains(needle))
    }
}

/// Counts accepted events and keeps a stable count for every severity.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Summary {
    /// Number of records accepted by the filter.
    pub records: u64,
    /// Accepted ERROR records.
    pub errors: u64,
    /// Accepted WARN records.
    pub warnings: u64,
    /// Accepted INFO records.
    pub infos: u64,
    /// Accepted DEBUG records.
    pub debugs: u64,
}

impl Summary {
    /// Adds one accepted record to the aggregate.
    fn observe(&mut self, record: &LogRecord) {
        self.records += 1;
        match record.level {
            Level::Error => self.errors += 1,
            Level::Warn => self.warnings += 1,
            Level::Info => self.infos += 1,
            Level::Debug => self.debugs += 1,
        }
    }
}

/// A failure while reading, parsing, or aggregating an input stream.
#[derive(Debug)]
pub enum ProcessError {
    /// The input stream failed while reading the indicated one-based line.
    Read {
        /// One-based input line number.
        line: usize,
        /// The underlying I/O cause.
        source: io::Error,
    },
    /// A log row violated the public input format.
    Parse(ParseError),
}

impl Display for ProcessError {
    /// Formats a concise diagnostic that does not echo untrusted input.
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        match self {
            Self::Read { line, source } => {
                write!(formatter, "read error at line {line}: {source}")
            }
            Self::Parse(error) => write!(
                formatter,
                "parse error at line {}: {}",
                error.line, error.kind
            ),
        }
    }
}

impl Display for ParseErrorKind {
    /// Formats the stable short reason used by CLI diagnostics.
    fn fmt(&self, formatter: &mut Formatter<'_>) -> fmt::Result {
        match self {
            Self::MissingField => formatter.write_str("missing field"),
            Self::InvalidTimestamp => formatter.write_str("invalid timestamp"),
            Self::InvalidLevel => formatter.write_str("invalid level"),
        }
    }
}

impl Error for ProcessError {
    /// Exposes only the underlying I/O error as the causal source.
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        match self {
            Self::Read { source, .. } => Some(source),
            Self::Parse(_) => None,
        }
    }
}

/// Parses one row; an exactly empty line is ignored.
///
/// # Errors
/// Returns the line number and failure category when the row is malformed.
pub fn parse_line(line: usize, raw: &str) -> Result<Option<LogRecord>, ParseError> {
    if raw.is_empty() {
        return Ok(None);
    }

    let mut fields = raw.split('|');
    let Some(timestamp) = fields.next() else {
        return Err(ParseError {
            line,
            kind: ParseErrorKind::MissingField,
        });
    };
    let Some(level) = fields.next() else {
        return Err(ParseError {
            line,
            kind: ParseErrorKind::MissingField,
        });
    };
    let Some(message) = fields.next() else {
        return Err(ParseError {
            line,
            kind: ParseErrorKind::MissingField,
        });
    };
    let timestamp_ms = timestamp.parse().map_err(|_| ParseError {
        line,
        kind: ParseErrorKind::InvalidTimestamp,
    })?;
    let level = Level::parse(level).ok_or(ParseError {
        line,
        kind: ParseErrorKind::InvalidLevel,
    })?;

    Ok(Some(LogRecord {
        timestamp_ms,
        level,
        message: message.to_owned(),
    }))
}

/// Streams records, applies filters, and retains only fixed-size counters.
///
/// # Errors
/// Returns the first I/O or parsing failure and its one-based line number.
pub fn process_reader<R: BufRead>(reader: R, filter: &LogFilter) -> Result<Summary, ProcessError> {
    let mut summary = Summary::default();
    for (index, line_result) in reader.lines().enumerate() {
        let line_number = index + 1;
        let line = line_result.map_err(|source| ProcessError::Read {
            line: line_number,
            source,
        })?;
        let record = parse_line(line_number, &line).map_err(ProcessError::Parse)?;
        if let Some(record) = record {
            if filter.accepts(&record) {
                summary.observe(&record);
            }
        }
    }
    Ok(summary)
}

#[cfg(test)]
mod tests {
    use super::{Level, LogFilter, LogRecord};

    /// Verifies stable level names and rejects lower-case aliases.
    #[test]
    fn parses_only_the_documented_uppercase_levels() {
        assert_eq!(Level::parse("ERROR"), Some(Level::Error));
        assert_eq!(Level::parse("info"), None);
    }

    /// Verifies timestamp bounds and keyword filters compose conjunctively.
    #[test]
    fn applies_inclusive_start_exclusive_end_and_keyword_filters() {
        let filter = LogFilter {
            levels: vec![Level::Info],
            from_ms: Some(10),
            until_ms: Some(20),
            contains: Some("ready".to_owned()),
        };
        let accepted = LogRecord {
            timestamp_ms: 10,
            level: Level::Info,
            message: "worker ready".to_owned(),
        };
        let excluded_at_end = LogRecord {
            timestamp_ms: 20,
            level: Level::Info,
            message: "worker ready".to_owned(),
        };

        assert!(filter.accepts(&accepted));
        assert!(!filter.accepts(&excluded_at_end));
    }
}
