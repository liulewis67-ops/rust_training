use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader, Write};
use std::path::PathBuf;
use std::process;

use log_core::{Level, LogFilter, ProcessError, Summary, process_reader};

/// Selects a stable output representation for the aggregated report.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum OutputFormat {
    /// Human-readable one-line-per-counter output.
    Text,
    /// Deterministic JSON with a fixed field order.
    Json,
}

/// Holds parsed CLI options before the selected input is opened.
struct Options {
    /// Whether to print help without reading an input.
    help: bool,
    /// Optional path; a missing path or dash means standard input.
    input: Option<PathBuf>,
    /// Filters applied before counters are incremented.
    filter: LogFilter,
    /// Format used for the successful summary.
    format: OutputFormat,
}

/// Parses arguments, processes exactly one input stream, and writes its result.
fn main() {
    let status = run(
        env::args().skip(1),
        io::stdin().lock(),
        io::stdout().lock(),
        io::stderr().lock(),
    );
    if status != 0 {
        process::exit(status);
    }
}

/// Runs the CLI with injectable streams so process behavior stays testable.
fn run<I, R, O, E>(args: I, stdin: R, mut stdout: O, mut stderr: E) -> i32
where
    I: IntoIterator<Item = String>,
    R: BufRead,
    O: Write,
    E: Write,
{
    let options = match parse_args(args) {
        Ok(options) => options,
        Err(message) => {
            let _ = writeln!(stderr, "log-analyzer: {message}");
            return 2;
        }
    };

    if options.help {
        if stdout.write_all(HELP.as_bytes()).is_err() {
            let _ = writeln!(stderr, "log-analyzer: cannot write help");
            return 1;
        }
        return 0;
    }

    let result = match options.input.as_deref() {
        None => process_reader(stdin, &options.filter),
        Some(path) if path == std::path::Path::new("-") => process_reader(stdin, &options.filter),
        Some(path) => match File::open(path) {
            Ok(file) => process_reader(BufReader::new(file), &options.filter),
            Err(error) => {
                let _ = writeln!(
                    stderr,
                    "log-analyzer: cannot open {}: {error}",
                    path.display()
                );
                return 1;
            }
        },
    };
    let summary = match result {
        Ok(summary) => summary,
        Err(error) => {
            report_processing_error(&mut stderr, &error);
            return 1;
        }
    };

    let output = render_summary(&summary, options.format);
    if stdout.write_all(output.as_bytes()).is_err() {
        let _ = writeln!(stderr, "log-analyzer: cannot write report");
        return 1;
    }
    0
}

/// Writes a process or parse diagnostic without emitting partial report data.
fn report_processing_error<E: Write>(stderr: &mut E, error: &ProcessError) {
    let _ = writeln!(stderr, "log-analyzer: {error}");
}

/// Parses documented flags and validates their cross-field constraints.
fn parse_args<I>(args: I) -> Result<Options, String>
where
    I: IntoIterator<Item = String>,
{
    let mut help = false;
    let mut input = None;
    let mut filter = LogFilter::default();
    let mut format = OutputFormat::Text;
    let mut from_was_set = false;
    let mut until_was_set = false;
    let mut contains_was_set = false;
    let mut format_was_set = false;

    let mut args = args.into_iter();
    while let Some(flag) = args.next() {
        match flag.as_str() {
            "--help" if !help => help = true,
            "--input" if input.is_none() => {
                input = Some(PathBuf::from(next_value(&mut args, &flag)?));
            }
            "--level" => {
                let value = next_value(&mut args, &flag)?;
                let level = Level::parse(&value).ok_or_else(|| {
                    format!("unknown level {value}; use ERROR, WARN, INFO, or DEBUG")
                })?;
                if !filter.levels.contains(&level) {
                    filter.levels.push(level);
                }
            }
            "--from-ms" if !from_was_set => {
                let value = next_value(&mut args, &flag)?;
                filter.from_ms = Some(parse_timestamp(&flag, &value)?);
                from_was_set = true;
            }
            "--until-ms" if !until_was_set => {
                let value = next_value(&mut args, &flag)?;
                filter.until_ms = Some(parse_timestamp(&flag, &value)?);
                until_was_set = true;
            }
            "--contains" if !contains_was_set => {
                filter.contains = Some(next_value(&mut args, &flag)?);
                contains_was_set = true;
            }
            "--format" if !format_was_set => {
                format = match next_value(&mut args, &flag)?.as_str() {
                    "text" => OutputFormat::Text,
                    "json" => OutputFormat::Json,
                    value => return Err(format!("unknown format {value}; use text or json")),
                };
                format_was_set = true;
            }
            "--help" => return Err("repeated option --help".to_owned()),
            "--input" => return Err("repeated option --input".to_owned()),
            "--from-ms" => return Err("repeated option --from-ms".to_owned()),
            "--until-ms" => return Err("repeated option --until-ms".to_owned()),
            "--contains" => return Err("repeated option --contains".to_owned()),
            "--format" => return Err("repeated option --format".to_owned()),
            _ => return Err(format!("unknown option {flag}")),
        }
    }

    if let (Some(from_ms), Some(until_ms)) = (filter.from_ms, filter.until_ms) {
        if from_ms >= until_ms {
            return Err("--from-ms must be less than --until-ms".to_owned());
        }
    }

    Ok(Options {
        help,
        input,
        filter,
        format,
    })
}

/// Reads one required value that follows a named CLI flag.
fn next_value<I>(args: &mut I, flag: &str) -> Result<String, String>
where
    I: Iterator<Item = String>,
{
    args.next()
        .ok_or_else(|| format!("missing value for {flag}"))
}

/// Parses an unsigned timestamp argument and includes its flag in diagnostics.
fn parse_timestamp(flag: &str, value: &str) -> Result<u64, String> {
    value
        .parse::<u64>()
        .map_err(|_| format!("{flag} expects an unsigned integer"))
}

/// Renders a stable report without depending on map iteration order.
fn render_summary(summary: &Summary, format: OutputFormat) -> String {
    match format {
        OutputFormat::Text => format!(
            "records={}\nERROR={}\nWARN={}\nINFO={}\nDEBUG={}\n",
            summary.records, summary.errors, summary.warnings, summary.infos, summary.debugs
        ),
        OutputFormat::Json => format!(
            "{{\"records\":{},\"levels\":{{\"ERROR\":{},\"WARN\":{},\"INFO\":{},\"DEBUG\":{}}}}}\n",
            summary.records, summary.errors, summary.warnings, summary.infos, summary.debugs
        ),
    }
}

const HELP: &str = "Usage: log-analyzer [OPTIONS]\n\nOptions:\n  --input PATH       Read PATH; omitted or - reads stdin\n  --level LEVEL      Include ERROR, WARN, INFO, or DEBUG (repeatable)\n  --from-ms N        Inclusive lower timestamp bound\n  --until-ms N       Exclusive upper timestamp bound\n  --contains TEXT    Case-sensitive message substring\n  --format FORMAT    text (default) or json\n  --help             Print this help\n\nInput rows: timestamp_ms|LEVEL|message\n";

#[cfg(test)]
mod tests {
    use super::{OutputFormat, parse_args, render_summary};
    use log_core::Summary;

    /// Verifies report fields have a deterministic order in JSON output.
    #[test]
    fn renders_fixed_json_field_order() {
        let rendered = render_summary(
            &Summary {
                records: 2,
                infos: 1,
                errors: 1,
                ..Summary::default()
            },
            OutputFormat::Json,
        );

        assert_eq!(
            rendered,
            "{\"records\":2,\"levels\":{\"ERROR\":1,\"WARN\":0,\"INFO\":1,\"DEBUG\":0}}\n"
        );
    }

    /// Verifies invalid reversed time bounds are rejected before I/O begins.
    #[test]
    fn rejects_reversed_time_bounds() {
        let result = parse_args(
            ["--from-ms", "20", "--until-ms", "10"]
                .into_iter()
                .map(str::to_owned),
        );

        assert!(result.is_err());
    }
}
