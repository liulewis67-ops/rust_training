use std::io::Write;
use std::process::{Command, Output, Stdio};

/// Runs log-analyzer with a controlled stdin pipe and returns its process output.
fn run_cli(arguments: &[&str], input: &str) -> Output {
    let mut child = Command::new(env!("CARGO_BIN_EXE_log-analyzer"))
        .args(arguments)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("log-analyzer should start");
    let mut stdin = child.stdin.take().expect("child stdin should be piped");
    stdin
        .write_all(input.as_bytes())
        .expect("fixture should reach child stdin");
    drop(stdin);
    child.wait_with_output().expect("log-analyzer should exit")
}

/// Creates a unique input file for a real binary integration test.
fn create_log_file(contents: &str) -> std::path::PathBuf {
    let name = format!(
        "m10-l05-logs-{}-{}.log",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("clock should follow the Unix epoch")
            .as_nanos()
    );
    let path = std::env::temp_dir().join(name);
    std::fs::write(&path, contents).expect("fixture file should be writable");
    path
}

/// Verifies help is successful and written only to stdout.
#[test]
fn prints_help_without_reading_input() {
    let output = run_cli(&["--help"], "");

    assert!(output.status.success());
    assert!(String::from_utf8_lossy(&output.stdout).contains("Usage: log-analyzer"));
    assert!(output.stderr.is_empty());
}

/// Verifies file filters and deterministic JSON output through the process.
#[test]
fn filters_file_records_into_json_report() {
    let path = create_log_file(
        "9|ERROR|too early\n10|ERROR|request failed\n15|INFO|request failed\n20|ERROR|end bound\n",
    );
    let path_text = path.to_string_lossy().into_owned();
    let output = run_cli(
        &[
            "--input",
            &path_text,
            "--level",
            "ERROR",
            "--from-ms",
            "10",
            "--until-ms",
            "20",
            "--contains",
            "failed",
            "--format",
            "json",
        ],
        "",
    );
    std::fs::remove_file(path).expect("fixture file should be removable");

    assert!(output.status.success());
    assert_eq!(
        output.stdout,
        b"{\"records\":1,\"levels\":{\"ERROR\":1,\"WARN\":0,\"INFO\":0,\"DEBUG\":0}}\n"
    );
    assert!(output.stderr.is_empty());
}

/// Verifies omitted input reads a pipe and writes a text report to stdout.
#[test]
fn reads_stdin_and_writes_text_report() {
    let output = run_cli(&[], "1|WARN|slow request\n2|WARN|retry\n");

    assert!(output.status.success());
    assert_eq!(
        output.stdout,
        b"records=2\nERROR=0\nWARN=2\nINFO=0\nDEBUG=0\n"
    );
    assert!(output.stderr.is_empty());
}

/// Verifies malformed input fails without leaking a partial summary to stdout.
#[test]
fn reports_bad_row_and_suppresses_partial_output() {
    let output = run_cli(&[], "1|INFO|valid\n2|TRACE|bad\n");

    assert_eq!(output.status.code(), Some(1));
    assert!(output.stdout.is_empty());
    let error = String::from_utf8_lossy(&output.stderr);
    assert!(error.contains("line 2"));
    assert!(error.contains("invalid level"));
}

/// Verifies CLI usage failures have status two and an empty stdout.
#[test]
fn rejects_unknown_option_with_usage_status() {
    let output = run_cli(&["--format", "yaml"], "");

    assert_eq!(output.status.code(), Some(2));
    assert!(output.stdout.is_empty());
    assert!(String::from_utf8_lossy(&output.stderr).contains("unknown format"));
}

/// Verifies an unavailable file is an input failure on stderr.
#[test]
fn reports_a_missing_file_without_stdout() {
    let path = std::env::temp_dir().join(format!(
        "m10-l05-missing-{}-{}.log",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("clock should follow the Unix epoch")
            .as_nanos()
    ));
    let path_text = path.to_string_lossy().into_owned();
    let output = run_cli(&["--input", &path_text], "");

    assert_eq!(output.status.code(), Some(1));
    assert!(output.stdout.is_empty());
    assert!(String::from_utf8_lossy(&output.stderr).contains("cannot open"));
}
