# Rc and Arc shared policy

This dependency-free Edition 2024 example shares one immutable policy across consumers. It uses `Rc` for a local pair and `Arc` for two worker threads. Integration tests observe pointer identity, strong-count changes, and one final destructor call.

From this directory run:

```text
cargo fmt -- --check
cargo test --offline --locked
cargo clippy --all-targets --offline --locked -- -D warnings
cargo doc --no-deps --offline --locked
```

The crate also contains a compile-fail doctest showing that atomic ownership does not make `Arc<RefCell<T>>` thread-safe. Sharing is immutable here; mutation and lock policy are outside this example.
