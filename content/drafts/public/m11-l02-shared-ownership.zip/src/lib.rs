//! Shares one immutable policy using thread-appropriate reference counting.
//!
//! An atomic counter protects Arc's shared ownership, not arbitrary inner state.
//!
//! ```compile_fail
//! use std::cell::RefCell;
//! use std::sync::Arc;
//!
//! let shared = Arc::new(RefCell::new(4));
//! std::thread::spawn(move || *shared.borrow())
//!     .join()
//!     .expect("worker should finish");
//! ```

use std::rc::Rc;
use std::sync::Arc;
use std::thread;

/// Immutable settings shared by jobs that follow the same retry policy.
#[derive(Debug, PartialEq, Eq)]
pub struct Policy {
    /// Maximum retry attempts made by one job.
    pub retries: u8,
}

/// Builds two additional local owners of one shared policy allocation.
#[must_use]
pub fn local_pair(policy: Rc<Policy>) -> (Rc<Policy>, Rc<Policy>) {
    let second = Rc::clone(&policy);
    (policy, second)
}

/// Reads one Arc-owned policy from two worker threads without mutating it.
///
/// # Panics
/// Panics if either worker thread panics before returning its retry count.
#[must_use]
pub fn parallel_read(policy: Arc<Policy>) -> (u8, u8) {
    let first_policy = Arc::clone(&policy);
    let second_policy = policy;
    let first = thread::spawn(move || first_policy.retries);
    let second = thread::spawn(move || second_policy.retries);

    (
        first.join().expect("first worker should finish"),
        second.join().expect("second worker should finish"),
    )
}
