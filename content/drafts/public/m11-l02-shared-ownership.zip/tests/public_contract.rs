use std::cell::Cell;
use std::rc::Rc;
use std::sync::Arc;

use shared_policy_owners::{Policy, local_pair, parallel_read};

struct DropProbe(Rc<Cell<usize>>);

impl Drop for DropProbe {
    fn drop(&mut self) {
        self.0.set(self.0.get() + 1);
    }
}

/// Verifies Rc clones share one allocation and drop the value at zero owners.
#[test]
fn local_rc_owners_share_and_release_one_policy() {
    let policy = Rc::new(Policy { retries: 3 });
    let (first, second) = local_pair(Rc::clone(&policy));

    assert!(Rc::ptr_eq(&first, &second));
    assert_eq!(Rc::strong_count(&policy), 3);
    drop(first);
    assert_eq!(Rc::strong_count(&policy), 2);
    drop(policy);
    assert_eq!(Rc::strong_count(&second), 1);
    drop(second);

    let drops = Rc::new(Cell::new(0));
    let probe = Rc::new(DropProbe(Rc::clone(&drops)));
    let other_owner = Rc::clone(&probe);
    drop(probe);
    assert_eq!(drops.get(), 0);
    drop(other_owner);
    assert_eq!(drops.get(), 1);
}

/// Verifies Arc allows multiple worker threads to read the same allocation.
#[test]
fn arc_shares_immutable_policy_across_workers() {
    let policy = Arc::new(Policy { retries: 5 });
    let readers = parallel_read(Arc::clone(&policy));

    assert_eq!(readers, (5, 5));
    assert_eq!(Arc::strong_count(&policy), 1);
    assert_eq!(policy.retries, 5);
}
