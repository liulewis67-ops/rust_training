use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::PathBuf;
use std::process;

use profile_core::render_profile_report;

/// Holds parsed command-line values before their sources are resolved.
struct Options {
    /// An explicitly selected profile name, if supplied by the caller.
    name: Option<String>,
    /// The optional configuration path that must be read when present.
    config_path: Option<PathBuf>,
}

/// Carries a user-facing message and the process status for a CLI failure.
struct CliError {
    /// The nonzero status code returned to the shell.
    exit_code: i32,
    /// The diagnostic written to stderr.
    message: String,
}

/// Runs the CLI and reports any failure on stderr with its contract status.
fn main() {
    if let Err(error) = run(env::args().skip(1)) {
        eprintln!("profile-cli: {}", error.message);
        process::exit(error.exit_code);
    }
}

/// Resolves name sources, formats the report, and writes only successful output to stdout.
fn run<I>(args: I) -> Result<(), CliError>
where
    I: IntoIterator<Item = String>,
{
    let options = parse_args(args)?;
    let config_name = match options.config_path {
        Some(path) => {
            let contents = fs::read_to_string(&path).map_err(|error| CliError {
                exit_code: 2,
                message: format!("cannot read config {}: {error}", path.display()),
            })?;
            parse_config(&contents).map_err(|message| CliError {
                exit_code: 2,
                message: format!("invalid config: {message}"),
            })?
        }
        None => None,
    };
    let environment_name = env::var("PROFILE_NAME").ok();
    let stdin_name =
        if options.name.is_some() || config_name.is_some() || environment_name.is_some() {
            None
        } else {
            Some(io::read_to_string(io::stdin()).map_err(|error| CliError {
                exit_code: 2,
                message: format!("cannot read stdin: {error}"),
            })?)
        };
    let raw_name = options
        .name
        .or(config_name)
        .or(environment_name)
        .or(stdin_name)
        .unwrap_or_default();
    let report = render_profile_report(&raw_name).map_err(|error| CliError {
        exit_code: 1,
        message: format!("invalid profile name: {error:?}"),
    })?;
    writeln!(io::stdout().lock(), "{report}").map_err(|error| CliError {
        exit_code: 2,
        message: format!("cannot write stdout: {error}"),
    })?;
    Ok(())
}

/// Parses supported flags and rejects unknown, repeated, or valueless options.
fn parse_args<I>(args: I) -> Result<Options, CliError>
where
    I: IntoIterator<Item = String>,
{
    let mut name = None;
    let mut config_path = None;
    let mut args = args.into_iter();

    while let Some(flag) = args.next() {
        let value = args.next().ok_or_else(|| CliError {
            exit_code: 2,
            message: format!("missing value for {flag}"),
        })?;
        match flag.as_str() {
            "--name" if name.is_none() => name = Some(value),
            "--config" if config_path.is_none() => config_path = Some(PathBuf::from(value)),
            "--name" | "--config" => {
                return Err(CliError {
                    exit_code: 2,
                    message: format!("repeated option {flag}"),
                });
            }
            _ => {
                return Err(CliError {
                    exit_code: 2,
                    message: format!("unknown option {flag}"),
                });
            }
        }
    }

    Ok(Options { name, config_path })
}

/// Parses one `profile_name` setting while rejecting duplicate and unknown keys.
fn parse_config(contents: &str) -> Result<Option<String>, String> {
    let mut profile_name = None;

    for (index, line) in contents.lines().enumerate() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }

        let Some((key, value)) = line.split_once('=') else {
            return Err(format!("line {} must use key = value", index + 1));
        };
        if key.trim() != "profile_name" {
            return Err(format!("unknown key on line {}", index + 1));
        }
        if profile_name.is_some() {
            return Err(format!("duplicate profile_name on line {}", index + 1));
        }
        profile_name = Some(value.trim().to_owned());
    }

    Ok(profile_name)
}
