use std::io::Write;
use std::process::{Command, Output, Stdio};

/// Runs the real CLI with isolated source values and a closed stdin pipe.
fn run_cli(arguments: &[&str], environment_name: Option<&str>, stdin_text: &str) -> Output {
    let mut command = Command::new(env!("CARGO_BIN_EXE_profile-cli"));
    command
        .args(arguments)
        .env_remove("PROFILE_NAME")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped());
    if let Some(name) = environment_name {
        command.env("PROFILE_NAME", name);
    }

    let mut child = command.spawn().expect("profile-cli should start");
    let mut stdin = child.stdin.take().expect("stdin pipe should be present");
    stdin
        .write_all(stdin_text.as_bytes())
        .expect("test input should reach the child process");
    drop(stdin);

    child.wait_with_output().expect("profile-cli should finish")
}

/// Creates a unique valid config file for a real process-level test.
fn create_config(contents: &str) -> std::path::PathBuf {
    let unique = format!(
        "m10-l03-config-{}-{}.conf",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("system clock should be after the Unix epoch")
            .as_nanos()
    );
    let path = std::env::temp_dir().join(unique);
    std::fs::write(&path, contents).expect("test config should be writable");
    path
}

/// Confirms the command-line value wins over config, environment, and stdin.
#[test]
fn command_line_has_highest_precedence() {
    let path = create_config("profile_name = from_config\n");
    let path_text = path.to_string_lossy().into_owned();
    let output = run_cli(
        &["--config", &path_text, "--name", "from_cli"],
        Some("from_env"),
        "from_stdin\n",
    );
    std::fs::remove_file(path).expect("test config should be removable");

    assert!(output.status.success());
    assert_eq!(output.stdout, b"profile=from_cli\n");
    assert!(output.stderr.is_empty());
}

/// Confirms a valid config value wins over environment and stdin.
#[test]
fn config_has_precedence_over_environment_and_stdin() {
    let path = create_config("profile_name = from_config\n");
    let path_text = path.to_string_lossy().into_owned();
    let output = run_cli(&["--config", &path_text], Some("from_env"), "from_stdin\n");
    std::fs::remove_file(path).expect("test config should be removable");

    assert!(output.status.success());
    assert_eq!(output.stdout, b"profile=from_config\n");
    assert!(output.stderr.is_empty());
}

/// Confirms the environment value wins when CLI and config are absent.
#[test]
fn environment_has_precedence_over_stdin() {
    let output = run_cli(&[], Some("from_env"), "from_stdin\n");

    assert!(output.status.success());
    assert_eq!(output.stdout, b"profile=from_env\n");
    assert!(output.stderr.is_empty());
}

/// Confirms stdin is read through EOF only when earlier sources are absent.
#[test]
fn standard_input_is_the_fallback_source() {
    let output = run_cli(&[], None, "from_stdin\n");

    assert!(output.status.success());
    assert_eq!(output.stdout, b"profile=from_stdin\n");
    assert!(output.stderr.is_empty());
}

/// Confirms an unreadable explicit config fails without writing to stdout.
#[test]
fn missing_config_file_is_an_error() {
    let path = std::env::temp_dir().join(format!(
        "m10-l03-missing-{}-{}.conf",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("system clock should be after the Unix epoch")
            .as_nanos()
    ));
    let path_text = path.to_string_lossy().into_owned();
    let output = run_cli(&["--config", &path_text], Some("from_env"), "from_stdin\n");

    assert_eq!(output.status.code(), Some(2));
    assert!(output.stdout.is_empty());
    assert!(String::from_utf8_lossy(&output.stderr).contains("cannot read config"));
}

/// Confirms an invalid config is not ignored in favor of lower sources.
#[test]
fn malformed_config_file_is_not_silently_ignored() {
    let path = create_config("unknown_key = value\n");
    let path_text = path.to_string_lossy().into_owned();
    let output = run_cli(
        &["--config", &path_text],
        Some("valid_fallback"),
        "also_valid\n",
    );
    std::fs::remove_file(path).expect("test config should be removable");

    assert_eq!(output.status.code(), Some(2));
    assert!(output.stdout.is_empty());
    assert!(String::from_utf8_lossy(&output.stderr).contains("invalid config"));
}

/// Confirms a higher-priority name does not hide a broken explicit config path.
#[test]
fn command_line_does_not_hide_an_unreadable_config() {
    let path = std::env::temp_dir().join(format!(
        "m10-l03-missing-cli-{}-{}.conf",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("system clock should be after the Unix epoch")
            .as_nanos()
    ));
    let path_text = path.to_string_lossy().into_owned();
    let output = run_cli(
        &["--config", &path_text, "--name", "from_cli"],
        Some("from_env"),
        "from_stdin\n",
    );

    assert_eq!(output.status.code(), Some(2));
    assert!(output.stdout.is_empty());
    assert!(String::from_utf8_lossy(&output.stderr).contains("cannot read config"));
}

/// Confirms an explicit empty name is validated rather than falling back.
#[test]
fn empty_command_line_name_does_not_fall_back() {
    let output = run_cli(&["--name", ""], Some("valid_fallback"), "also_valid\n");

    assert_eq!(output.status.code(), Some(1));
    assert!(output.stdout.is_empty());
    assert!(String::from_utf8_lossy(&output.stderr).contains("Empty"));
}
