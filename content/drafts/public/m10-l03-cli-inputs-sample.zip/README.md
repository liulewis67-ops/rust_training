# M10-L03 示例：CLI 输入来源和进程契约

本 Edition 2024 workspace 从命令参数、配置文件、环境变量和标准输入中解析 profile name。优先级为 CLI > config > PROFILE_NAME > stdin。明确传入 config path 后，程序总会读取并检查该文件；文件错误不会被 CLI 值掩盖。

成功时 stdout 是单行 profile 报告，stderr 为空，退出码为 0。参数/配置错误返回 2；缺少输入或领域名称不合法返回 1。所有错误写 stderr，不污染 stdout。

配置文件示例：

~~~text
# profile settings
profile_name = from_config
~~~

从 workspace 根目录运行：

~~~text
cargo test --workspace --offline
$env:PROFILE_NAME = "from_env"
cargo run -p profile-cli --offline -- --config settings.conf
Remove-Item Env:PROFILE_NAME
cargo run -p profile-cli --offline -- --name from_cli
"from_stdin" | cargo run -p profile-cli --offline
~~~

workspace 集成测试会启动实际编译的 profile-cli 二进制，用子进程参数、环境变量、配置文件和已关闭的 stdin 管道验证选择优先级、错误退出码及 stdout/stderr。
