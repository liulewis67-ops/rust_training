//! M21-L02 availability classification starter.

/// A finite route dimension intended for bounded metric labels.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Route {
    /// The fixed user lookup route.
    Users,
    /// The fixed task submission route.
    Runs,
}

/// An API result under the lesson's explicit request contract.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ApiResult {
    /// The API completed the request successfully.
    Success,
    /// The API returned an expected business rejection.
    ExpectedRejection,
    /// The API failed to serve the request.
    ServerFailure,
}

/// A result from the isolated execution platform.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RunnerResult {
    /// The platform delivered the requested execution result.
    Completed,
    /// Learner code did not compile or pass its contract.
    LearnerRejected,
    /// The platform could not start or return the execution.
    PlatformFailure,
}

/// A timestamped signal for either the API or its execution platform.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Observation {
    /// A response produced by the API.
    Api {
        /// UTC seconds from the fixture epoch.
        at: u64,
        /// Stable route template dimension.
        route: Route,
        /// Contractual API outcome.
        result: ApiResult,
    },
    /// A result produced by the execution platform.
    Runner {
        /// UTC seconds from the fixture epoch.
        at: u64,
        /// Platform delivery outcome.
        result: RunnerResult,
    },
}

/// The service boundary whose availability objective is being calculated.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Objective {
    /// API request availability.
    Api,
    /// Runner execution availability.
    Runner,
}

/// A half-open time range `[start, end)`.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Window {
    /// Inclusive UTC start second.
    pub start: u64,
    /// Exclusive UTC end second.
    pub end: u64,
}

/// Aggregate counts used to explain one SLI window.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct SliSummary {
    /// Number of eligible observations in the selected window.
    pub eligible: u64,
    /// Number of observations meeting the objective's good-event definition.
    pub good: u64,
}

impl SliSummary {
    /// Returns the floored good-event ratio in parts per million, or `None` for no data.
    #[must_use]
    pub fn ratio_ppm(self) -> Option<u32> {
        if self.eligible == 0 || self.good > self.eligible {
            return None;
        }
        let ratio = u128::from(self.good) * 1_000_000 / u128::from(self.eligible);
        u32::try_from(ratio).ok()
    }

    /// Reports whether the SLI meets a target in parts per million.
    #[must_use]
    pub fn meets_target(self, target_ppm: u32) -> Option<bool> {
        if target_ppm > 1_000_000 || self.eligible == 0 || self.good > self.eligible {
            return None;
        }
        Some(
            u128::from(self.good) * 1_000_000 >= u128::from(target_ppm) * u128::from(self.eligible),
        )
    }
}

/// Returns the timestamp for an observation without discarding its domain.
fn timestamp(observation: Observation) -> u64 {
    match observation {
        Observation::Api { at, .. } | Observation::Runner { at, .. } => at,
    }
}

/// Determines whether an observation belongs to the selected objective.
fn is_eligible(observation: Observation, objective: Objective) -> bool {
    matches!(
        (observation, objective),
        (Observation::Api { .. }, Objective::Api) | (Observation::Runner { .. }, Objective::Runner)
    )
}

/// Counts good events in a half-open window for exactly one service boundary.
#[must_use]
pub fn summarize(observations: &[Observation], window: Window, objective: Objective) -> SliSummary {
    if window.start >= window.end {
        return SliSummary::default();
    }
    observations
        .iter()
        .copied()
        .filter(|observation| {
            let at = timestamp(*observation);
            is_eligible(*observation, objective) && window.start <= at && at < window.end
        })
        .fold(SliSummary::default(), |mut summary, observation| {
            summary.eligible += 1;
            let good = match observation {
                Observation::Api { result, .. } => result == ApiResult::Success,
                Observation::Runner { result, .. } => result == RunnerResult::Completed,
            };
            if good {
                summary.good += 1;
            }
            summary
        })
}

/// Returns the current label pairs, including the known high-cardinality leak.
#[must_use]
pub fn metric_labels(
    route: Route,
    result: ApiResult,
    request_id: &str,
) -> Vec<(&'static str, String)> {
    let route_name = match route {
        Route::Users => "/users/{id}".to_owned(),
        Route::Runs => "/runs".to_owned(),
    };
    let outcome = match result {
        ApiResult::Success => "success",
        ApiResult::ExpectedRejection => "expected_rejection",
        ApiResult::ServerFailure => "server_error",
    };
    vec![
        ("route", route_name),
        ("outcome", outcome.to_owned()),
        ("request_id", request_id.to_owned()),
    ]
}
