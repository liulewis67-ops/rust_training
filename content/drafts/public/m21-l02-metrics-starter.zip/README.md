# M21-L02 metrics and SLO starter

Run `cargo test --locked` on Windows to observe the deliberately incorrect classification and label contract. The clean baseline should include failures for expected business rejection, learner code failures, and unbounded metric labels. The original archive is `../m21-l02-metrics-starter.zip`; restore from it and check `starter-manifest.json` before a new attempt. The fixture is local and in-memory; it starts no Linux container, database, metrics SDK, or collector.
