use m21_l02_metrics::{
    ApiResult, Objective, Observation, Route, RunnerResult, Window, metric_labels, summarize,
};

/// Builds a user-route API observation for the contract tests.
fn api(at: u64, result: ApiResult) -> Observation {
    Observation::Api {
        at,
        route: Route::Users,
        result,
    }
}

/// Builds an execution-platform observation for the contract tests.
fn runner(at: u64, result: RunnerResult) -> Observation {
    Observation::Runner { at, result }
}

/// API and runner windows use separate event populations and half-open bounds.
#[test]
fn applies_half_open_window_and_separates_service_boundaries() {
    let events = [
        api(100, ApiResult::Success),
        api(199, ApiResult::ServerFailure),
        api(200, ApiResult::ServerFailure),
        runner(101, RunnerResult::Completed),
    ];
    let api_summary = summarize(
        &events,
        Window {
            start: 100,
            end: 200,
        },
        Objective::Api,
    );
    assert_eq!(api_summary.eligible, 2);
    assert_eq!(api_summary.good, 1);
    let runner_summary = summarize(
        &events,
        Window {
            start: 100,
            end: 200,
        },
        Objective::Runner,
    );
    assert_eq!(runner_summary.eligible, 1);
    assert_eq!(runner_summary.good, 1);
}

/// Expected resource absence is a good API event under this explicit contract.
#[test]
fn expected_business_rejection_is_good_api_availability() {
    let summary = summarize(
        &[api(120, ApiResult::ExpectedRejection)],
        Window {
            start: 100,
            end: 200,
        },
        Objective::Api,
    );
    assert_eq!(summary.good, 1);
}

/// API server failures consume the API availability objective.
#[test]
fn server_failure_is_bad_api_availability() {
    let summary = summarize(
        &[api(120, ApiResult::ServerFailure)],
        Window {
            start: 100,
            end: 200,
        },
        Objective::Api,
    );
    assert_eq!(summary.good, 0);
}

/// Learner feedback still proves that the runner successfully delivered execution.
#[test]
fn learner_code_failure_is_good_runner_availability() {
    let summary = summarize(
        &[runner(120, RunnerResult::LearnerRejected)],
        Window {
            start: 100,
            end: 200,
        },
        Objective::Runner,
    );
    assert_eq!(summary.good, 1);
}

/// Runner infrastructure failure consumes the runner availability objective.
#[test]
fn platform_failure_is_bad_runner_availability() {
    let summary = summarize(
        &[runner(120, RunnerResult::PlatformFailure)],
        Window {
            start: 100,
            end: 200,
        },
        Objective::Runner,
    );
    assert_eq!(summary.good, 0);
}

/// Metric dimensions exclude request-specific identifiers and raw path values.
#[test]
fn metric_labels_use_only_bounded_dimensions() {
    let labels = metric_labels(Route::Users, ApiResult::Success, "req-user-specific-739");
    assert!(!labels.iter().any(|(key, _)| *key == "request_id"));
    assert!(!labels.iter().any(|(_, value)| value.contains("739")));
}
