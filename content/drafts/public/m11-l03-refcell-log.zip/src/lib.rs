//! A single-threaded event log that exposes shared reads and checked writes.
//!
//! `RefCell` detects conflicting borrows at runtime. It is not a synchronization
//! primitive for sharing mutable state between threads.

use std::cell::{BorrowMutError, RefCell};

/// Collects events through a shared reference using single-threaded interior mutability.
#[derive(Debug, Default)]
pub struct EventLog {
    events: RefCell<Vec<String>>,
}

impl EventLog {
    /// Creates an empty event log.
    #[must_use]
    pub fn new() -> Self {
        Self::default()
    }

    /// Appends one event through the shared interface.
    ///
    /// # Panics
    /// Panics if a mutable borrow is already active or any shared borrow is active.
    pub fn record(&self, event: String) {
        self.events.borrow_mut().push(event);
    }

    /// Runs `inspect` while a shared borrow of the events remains active.
    pub fn with_events<R>(&self, inspect: impl FnOnce(&[String]) -> R) -> R {
        let events = self.events.borrow();
        inspect(&events)
    }

    /// Appends an event unless another borrow currently prevents mutable access.
    ///
    /// # Errors
    /// Returns `BorrowMutError` if a shared or mutable borrow is currently active.
    pub fn try_record(&self, event: String) -> Result<(), BorrowMutError> {
        self.events
            .try_borrow_mut()
            .map(|mut events| events.push(event))
    }
}
