use refcell_event_log::EventLog;

#[test]
fn records_and_reads_events_in_order() {
    let log = EventLog::new();
    log.record("opened".to_owned());
    log.record("saved".to_owned());

    log.with_events(|events| {
        assert_eq!(events, ["opened", "saved"]);
    });
}

#[test]
fn reports_a_write_conflict_then_allows_write_after_reader_drops() {
    let log = EventLog::new();
    log.record("opened".to_owned());

    log.with_events(|events| {
        assert_eq!(events, ["opened"]);
        assert!(log.try_record("blocked".to_owned()).is_err());
        assert_eq!(events, ["opened"]);
    });

    assert!(log.try_record("saved".to_owned()).is_ok());
    log.with_events(|events| assert_eq!(events, ["opened", "saved"]));
}
