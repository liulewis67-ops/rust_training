# RefCell Event Log

This small crate demonstrates `RefCell<T>` in a single-threaded event recorder. `with_events` keeps a shared `Ref` guard alive while its callback runs, so a write attempted inside that callback returns `BorrowMutError` through `try_record`. The write succeeds after the callback ends and its guard drops.

`RefCell` performs runtime borrow checks; it does not coordinate access between threads. Use `Mutex<T>`, `RwLock<T>`, or an appropriate atomic type when state must be shared and mutated across threads. Wrapping a `RefCell<T>` in `Arc` does not make it thread-safe.

Run `cargo fmt -- --check`, `cargo check --offline`, `cargo test --offline`, `cargo clippy --all-targets --offline -- -D warnings`, and `cargo doc --no-deps --offline`.
