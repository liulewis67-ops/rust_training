//! Models parent-to-child ownership with a non-owning weak parent link.

use std::cell::{Cell, RefCell};
use std::rc::{Rc, Weak};

/// Why an attempted parent-child link would no longer form a tree.
#[derive(Debug, PartialEq, Eq)]
pub enum TreeLinkError {
    /// The child already has a live parent.
    AlreadyHasParent,
    /// The new edge would make the node its own ancestor.
    Cycle,
}

/// A tree node whose parent link does not keep the parent alive.
pub struct TreeNode {
    name: String,
    parent: RefCell<Option<Weak<Self>>>,
    children: RefCell<Vec<Rc<Self>>>,
    drop_count: Rc<Cell<usize>>,
}

impl TreeNode {
    /// Creates a node that increments `drop_count` when its value is destroyed.
    #[must_use]
    pub fn new(name: impl Into<String>, drop_count: Rc<Cell<usize>>) -> Rc<Self> {
        Rc::new(Self {
            name: name.into(),
            parent: RefCell::new(None),
            children: RefCell::new(Vec::new()),
            drop_count,
        })
    }

    /// Adds `child` as a strongly owned child and gives it a weak parent link.
    ///
    /// # Errors
    /// Returns an error if `child` already has a parent or this edge would form a cycle.
    pub fn attach(parent: &Rc<Self>, child: &Rc<Self>) -> Result<(), TreeLinkError> {
        let mut ancestor = Some(Rc::clone(parent));
        while let Some(node) = ancestor {
            if Rc::ptr_eq(&node, child) {
                return Err(TreeLinkError::Cycle);
            }
            ancestor = node.parent.borrow().as_ref().and_then(Weak::upgrade);
        }

        if child.parent.borrow().is_some() {
            return Err(TreeLinkError::AlreadyHasParent);
        }

        *child.parent.borrow_mut() = Some(Rc::downgrade(parent));
        parent.children.borrow_mut().push(Rc::clone(child));
        Ok(())
    }

    /// Returns the name of the parent if it still has a strong owner.
    #[must_use]
    pub fn parent_name(&self) -> Option<String> {
        self.parent
            .borrow()
            .as_ref()
            .and_then(Weak::upgrade)
            .map(|parent| parent.name.clone())
    }

    /// Returns the number of children currently strongly owned by this node.
    #[must_use]
    pub fn child_count(&self) -> usize {
        self.children.borrow().len()
    }
}

impl Drop for TreeNode {
    fn drop(&mut self) {
        self.drop_count.set(self.drop_count.get() + 1);
    }
}
