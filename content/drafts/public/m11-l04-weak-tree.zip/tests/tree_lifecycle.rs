use std::cell::Cell;
use std::rc::Rc;
use weak_tree_lifecycle::{TreeLinkError, TreeNode};

#[test]
fn weak_parent_does_not_keep_parent_alive() {
    let drops = Rc::new(Cell::new(0));
    let root = TreeNode::new("root", Rc::clone(&drops));
    let child = TreeNode::new("child", Rc::clone(&drops));
    TreeNode::attach(&root, &child).unwrap();

    assert_eq!(root.child_count(), 1);
    assert_eq!(child.parent_name().as_deref(), Some("root"));

    drop(root);
    assert_eq!(drops.get(), 1);
    assert_eq!(child.parent_name(), None);

    drop(child);
    assert_eq!(drops.get(), 2);
}

#[test]
fn rejects_reparenting_and_cycles() {
    let drops = Rc::new(Cell::new(0));
    let root = TreeNode::new("root", Rc::clone(&drops));
    let child = TreeNode::new("child", Rc::clone(&drops));
    let other = TreeNode::new("other", Rc::clone(&drops));
    TreeNode::attach(&root, &child).unwrap();

    assert_eq!(
        TreeNode::attach(&other, &child),
        Err(TreeLinkError::AlreadyHasParent)
    );
    assert_eq!(TreeNode::attach(&child, &root), Err(TreeLinkError::Cycle));
    assert_eq!(root.child_count(), 1);
    assert_eq!(child.child_count(), 0);
}
