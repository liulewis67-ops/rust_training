# Weak Parent Links and Drop

`TreeNode` strongly owns children and stores a `Weak<TreeNode>` back to its parent. The integration test keeps a child alive after dropping its root, observes that upgrading the parent link returns `None`, then checks that both nodes have been dropped exactly once.

The `strong_cycle` example intentionally creates a two-node `Rc` cycle. It prints `drop_count=0` and confirms both weak observers can still upgrade after the local owners are dropped. This example intentionally leaks its two nodes; run it as a separate short-lived process only. The cycle is memory-safe but its resources are not reclaimed through normal reference-count teardown.

Run `cargo run --offline --example strong_cycle` to observe the leak demonstration. For the normal tree crate, run `cargo fmt -- --check`, `cargo check --offline`, `cargo test --offline`, `cargo clippy --all-targets --offline -- -D warnings`, and `cargo doc --no-deps --offline`.
