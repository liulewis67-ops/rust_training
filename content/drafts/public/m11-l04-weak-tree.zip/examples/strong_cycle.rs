use std::cell::{Cell, RefCell};
use std::rc::Rc;

struct CycleNode {
    next: RefCell<Option<Rc<Self>>>,
    drops: Rc<Cell<usize>>,
}

impl Drop for CycleNode {
    fn drop(&mut self) {
        self.drops.set(self.drops.get() + 1);
    }
}

fn main() {
    let drops = Rc::new(Cell::new(0));
    let left = Rc::new(CycleNode {
        next: RefCell::new(None),
        drops: Rc::clone(&drops),
    });
    let right = Rc::new(CycleNode {
        next: RefCell::new(None),
        drops: Rc::clone(&drops),
    });
    *left.next.borrow_mut() = Some(Rc::clone(&right));
    *right.next.borrow_mut() = Some(Rc::clone(&left));
    let left_observer = Rc::downgrade(&left);
    let right_observer = Rc::downgrade(&right);

    drop(left);
    drop(right);
    println!("drop_count={}", drops.get());
    let left_points_to_right = left_observer
        .upgrade()
        .is_some_and(|node| node.next.borrow().is_some());
    let right_points_to_left = right_observer
        .upgrade()
        .is_some_and(|node| node.next.borrow().is_some());
    println!("left_points_to_right={left_points_to_right}");
    println!("right_points_to_left={right_points_to_left}");
}
