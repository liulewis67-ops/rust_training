//! A deliberately flawed cache ownership graph for the M11-L05 lab.

use std::cell::{Cell, RefCell};
use std::collections::HashMap;
use std::rc::Rc;

type EntryMap = RefCell<HashMap<String, Rc<Entry>>>;

/// A cache that strongly owns each entry in its map.
pub struct Cache {
    entries: Rc<EntryMap>,
}

impl Cache {
    /// Creates an empty cache.
    #[must_use]
    pub fn new() -> Self {
        Self {
            entries: Rc::new(RefCell::new(HashMap::new())),
        }
    }

    /// Inserts an entry and returns an additional strong handle to it.
    pub fn insert(&self, key: impl Into<String>, drops: Rc<Cell<usize>>) -> Rc<Entry> {
        let key = key.into();
        let entry = Rc::new(Entry {
            key: key.clone(),
            owner: Rc::clone(&self.entries),
            drops,
        });
        self.entries.borrow_mut().insert(key, Rc::clone(&entry));
        entry
    }
}

impl Default for Cache {
    fn default() -> Self {
        Self::new()
    }
}

/// One cache entry with a deliberately strong back-reference to its cache.
pub struct Entry {
    key: String,
    owner: Rc<EntryMap>,
    drops: Rc<Cell<usize>>,
}

impl Entry {
    /// Returns the cache key stored in this entry.
    #[must_use]
    pub fn key(&self) -> &str {
        &self.key
    }

    /// Reports whether the owning cache still contains this key.
    #[must_use]
    pub fn cache_has_key(&self) -> bool {
        self.owner.borrow().contains_key(&self.key)
    }
}

impl Drop for Entry {
    fn drop(&mut self) {
        self.drops.set(self.drops.get() + 1);
    }
}
