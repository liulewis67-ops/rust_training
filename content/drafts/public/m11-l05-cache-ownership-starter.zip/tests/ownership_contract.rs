use cache_ownership_lab::Cache;
use std::cell::Cell;
use std::rc::Rc;

#[test]
fn entry_can_check_cache_while_cache_is_alive() {
    let cache = Cache::new();
    let entry = cache.insert("settings", Rc::new(Cell::new(0)));

    assert_eq!(entry.key(), "settings");
    assert!(entry.cache_has_key());
}

#[test]
fn entry_does_not_keep_the_cache_alive() {
    let drops = Rc::new(Cell::new(0));
    let cache = Cache::new();
    let entry = cache.insert("settings", Rc::clone(&drops));

    drop(cache);
    assert!(!entry.cache_has_key());
}

#[test]
fn final_entry_owner_releases_entry_once() {
    let drops = Rc::new(Cell::new(0));
    let cache = Cache::new();
    let entry = cache.insert("settings", Rc::clone(&drops));

    drop(cache);
    drop(entry);
    assert_eq!(drops.get(), 1);
}
