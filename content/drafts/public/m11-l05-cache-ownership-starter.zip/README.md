# Cache Ownership Lab Starter

This crate compiles but intentionally fails two ownership lifecycle tests. The cache map strongly owns each entry, and each entry also strongly owns the map. Run `cargo test --offline` to record the failing behavior before editing.

The starting ZIP includes `SHA256SUMS.txt`. Verify the listed files before the baseline run. Keep an untouched extracted copy or extract the archive again into a new empty directory to reset. Do not use a previously repaired tree to record baseline results.

The task sheet is `LAB.md`. The public archive contains only the starter implementation, public tests, and reset/readme materials; no reference answers are included.
