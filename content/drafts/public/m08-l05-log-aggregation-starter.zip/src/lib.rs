use std::collections::HashMap;

/// One parsed log event with a borrowed service name and byte count.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct LogEvent<'a> {
    /// Names the service or subsystem that produced the event.
    pub service: &'a str,
    /// Stores the number of bytes attributed to this event.
    pub bytes: u64,
}

/// Summarizes all events attributed to one service.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ServiceSummary<'a> {
    /// Borrows the service name from one of the input events.
    pub service: &'a str,
    /// Counts all input events with this service name.
    pub event_count: usize,
    /// Adds byte counts from all input events with this service name.
    pub total_bytes: u64,
}

/// Aggregates events by borrowed service name and sorts the public result.
pub fn aggregate<'a>(events: &[LogEvent<'a>]) -> Vec<ServiceSummary<'a>> {
    let mut totals: HashMap<&'a str, (usize, u64)> = HashMap::new();

    for event in events {
        // TODO: Repeated names must update their existing count and byte total.
        totals.insert(event.service, (1, event.bytes));
    }

    let mut summaries: Vec<ServiceSummary<'a>> = totals
        .into_iter()
        .map(|(service, (event_count, total_bytes))| ServiceSummary {
            service,
            event_count,
            total_bytes,
        })
        .collect();

    summaries.sort_by(|left, right| left.service.cmp(right.service));
    summaries
}
