use m08_l05_log_aggregation::{LogEvent, ServiceSummary, aggregate};

/// Ensures empty input produces an empty report.
#[test]
fn empty_input_has_no_service_rows() {
    assert!(aggregate(&[]).is_empty());
}

/// Ensures repeated keys accumulate every event and its byte count.
#[test]
fn duplicate_services_accumulate_counts_and_bytes() {
    let events = [
        LogEvent {
            service: "api",
            bytes: 12,
        },
        LogEvent {
            service: "worker",
            bytes: 8,
        },
        LogEvent {
            service: "api",
            bytes: 5,
        },
    ];

    assert_eq!(
        aggregate(&events),
        vec![
            ServiceSummary {
                service: "api",
                event_count: 2,
                total_bytes: 17,
            },
            ServiceSummary {
                service: "worker",
                event_count: 1,
                total_bytes: 8,
            },
        ]
    );
}

/// Ensures Unicode names aggregate exactly and use a documented sort order.
#[test]
fn unicode_services_are_kept_and_sorted_lexicographically() {
    let events = [
        LogEvent {
            service: "缓存",
            bytes: 4,
        },
        LogEvent {
            service: "api",
            bytes: 7,
        },
        LogEvent {
            service: "缓存",
            bytes: 6,
        },
        LogEvent {
            service: "数据",
            bytes: 3,
        },
    ];

    let summaries = aggregate(&events);
    assert_eq!(
        summaries
            .iter()
            .map(|summary| summary.service)
            .collect::<Vec<_>>(),
        vec!["api", "数据", "缓存"]
    );
    assert_eq!(summaries[2].event_count, 2);
    assert_eq!(summaries[2].total_bytes, 10);
}
