# M08-L05 日志聚合统计起始包

Edition 2024、无第三方依赖的 Rust 库实验。数据已经解析成 `LogEvent`；本实验专注于按服务键聚合、所有权/借用和稳定报告顺序。

## 开始实验

先读 `tests/public_contract.rs` 与 `src/lib.rs`，再运行：

```text
cargo test --offline
```

起始包应能编译，但重复服务的公开契约测试会失败：当前 `insert` 为同名服务覆盖先前累计值。修复后运行：

```text
cargo fmt -- --check
cargo check --offline
cargo test --offline
```

聚合结果的顺序契约为服务名按 Rust `str` 的字典序升序；`HashMap` 只作为内部查找结构，不能直接决定输出顺序。服务名借自输入事件，不要求 `String::clone()` 或分配新键；结果的生命周期因此受输入切片中的服务名约束。

## 重置与追溯

重置时从 `content/drafts/public/m08-l05-log-aggregation-starter.zip` 解压到一个**全新**目录。先核对 `starter-manifest.json` 列出的每个文件 SHA-256，再运行起始测试。不要把修复后的工作目录重新打包成起始包。课程制作版本为 `0.1.0`；存档哈希记录在实施证据中。

本地验证可将 Cargo 目标目录指向项目外部目录，以免构建产物污染 ZIP 内容：

```powershell
$env:CARGO_TARGET_DIR = Join-Path $env:TEMP 'm08-l05-cargo-target'
cargo test --offline
cargo fmt -- --check
cargo check --offline
cargo test --offline
```
