//! A small uniquely owned expression tree backed by recursive `Box` edges.

/// One arithmetic expression whose child expressions have single owners.
#[derive(Debug, PartialEq, Eq)]
pub enum Expr {
    /// An integer leaf that terminates a recursive branch.
    Number(i64),
    /// The sum of two uniquely owned child expressions.
    Add(Box<Self>, Box<Self>),
}

impl Expr {
    /// Constructs an integer leaf.
    #[must_use]
    pub const fn number(value: i64) -> Self {
        Self::Number(value)
    }

    /// Constructs an addition node and takes ownership of both children.
    #[must_use]
    pub fn addition(left: Self, right: Self) -> Self {
        Self::Add(Box::new(left), Box::new(right))
    }

    /// Evaluates the tree through shared borrows without consuming it.
    #[must_use]
    pub fn evaluate(&self) -> i64 {
        match self {
            Self::Number(value) => *value,
            Self::Add(left, right) => left.evaluate() + right.evaluate(),
        }
    }
}
