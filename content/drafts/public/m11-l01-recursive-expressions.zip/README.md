# Boxed expression tree

This dependency-free Edition 2024 sample represents an expression tree with uniquely owned children. `Box<Expr>` supplies an indirection at each recursive edge; `evaluate(&self)` borrows the existing tree and does not consume it.

From this directory run:

```text
cargo fmt -- --check
cargo test --offline --locked
cargo clippy --all-targets --offline --locked -- -D warnings
cargo doc --no-deps --offline --locked
```

The test demonstrates `Box::new`, method-call auto-dereferencing, and two immutable evaluations of the same tree. `Box<T>` is single-owner; this sample does not imply that a `Vec<T>` needs boxed elements to represent a recursive container.
