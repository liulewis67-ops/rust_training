use recursive_expressions::Expr;

/// Verifies boxed children can be built and the borrowed tree reused.
#[test]
fn evaluates_nested_additions_without_consuming_the_tree() {
    let expression = Expr::addition(
        Expr::number(4),
        Expr::addition(Expr::number(5), Expr::number(6)),
    );

    assert_eq!(expression.evaluate(), 15);
    assert_eq!(expression.evaluate(), 15);
}

/// Verifies Box owns one child and method calls dereference it automatically.
#[test]
fn box_owns_a_leaf_and_can_move_its_value_out() {
    let boxed = Box::new(Expr::number(7));
    assert_eq!(boxed.evaluate(), 7);

    let owned_expression = *boxed;
    assert_eq!(owned_expression, Expr::Number(7));
}
