//! Full-router behavior for login rotation, cookie policy, CSRF, and server-side logout.

use axum::body::{Body, to_bytes};
use axum::http::header::{COOKIE, SET_COOKIE};
use axum::http::{Method, Request, StatusCode};
use axum::response::Response;
use m19_l02_session::{ErrorBody, LoginView, VerifiedIdentity, app};
use serde_json::Value;
use tower::ServiceExt;

const SESSION_COOKIE: &str = "__Host-session";
const PRE_AUTH_SESSION_ID: &str = "fixture-anonymous-session";
const AUTH_SESSION_ID: &str = "fixture-authenticated-session";
const CSRF_TOKEN: &str = "fixture-session-bound-csrf-token";

/// Builds a complete Router request using the test adapter's verified identity and cookie.
fn request(
    method: Method,
    uri: &str,
    session_id: Option<&str>,
    csrf_header: Option<&str>,
    identity: Option<VerifiedIdentity>,
) -> Request<Body> {
    let mut builder = Request::builder().method(method).uri(uri);
    if let Some(session_id) = session_id {
        builder = builder.header(COOKIE, format!("{SESSION_COOKIE}={session_id}"));
    }
    if let Some(csrf_header) = csrf_header {
        builder = builder.header("x-csrf-token", csrf_header);
    }
    let mut request = builder.body(Body::empty()).expect("valid exercise request");
    if let Some(identity) = identity {
        request.extensions_mut().insert(identity);
    }
    request
}

/// Sends one request through the supplied complete Router.
async fn send(
    router: axum::Router,
    method: Method,
    uri: &str,
    session_id: Option<&str>,
    csrf_header: Option<&str>,
    identity: Option<VerifiedIdentity>,
) -> Response {
    router
        .oneshot(request(method, uri, session_id, csrf_header, identity))
        .await
        .expect("router response")
}

/// Decodes a small JSON body within a fixed test limit.
async fn response_json(response: Response) -> Value {
    let bytes = to_bytes(response.into_body(), 8 * 1024)
        .await
        .expect("bounded JSON response");
    serde_json::from_slice(&bytes).expect("valid JSON response")
}

/// Login requires the trusted adapter to provide a verified identity.
#[tokio::test]
async fn login_requires_verified_identity() {
    let response = send(
        app(),
        Method::POST,
        "/api/v1/session/login",
        None,
        None,
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    let body: ErrorBody = serde_json::from_value(response_json(response).await)
        .expect("stable authentication error contract");
    assert_eq!(body.code, "authentication_required");
}

/// Authentication replaces the pre-authentication session and invalidates its old identifier.
#[tokio::test]
async fn login_rotates_preauthentication_session() {
    let router = app();
    let response = send(
        router.clone(),
        Method::POST,
        "/api/v1/session/login",
        Some(PRE_AUTH_SESSION_ID),
        None,
        Some(VerifiedIdentity::new(7)),
    )
    .await;
    assert_eq!(response.status(), StatusCode::OK);
    let cookie = response
        .headers()
        .get(SET_COOKIE)
        .expect("session cookie")
        .to_str()
        .expect("valid header");
    assert!(cookie.starts_with("__Host-session=fixture-authenticated-session"));

    let old_session = send(
        router.clone(),
        Method::GET,
        "/api/v1/session",
        Some(PRE_AUTH_SESSION_ID),
        None,
        None,
    )
    .await;
    assert_eq!(old_session.status(), StatusCode::UNAUTHORIZED);

    let current_session = send(
        router,
        Method::GET,
        "/api/v1/session",
        Some(AUTH_SESSION_ID),
        None,
        None,
    )
    .await;
    assert_eq!(current_session.status(), StatusCode::OK);
    assert_eq!(response_json(current_session).await["user_id"], 7);
}

/// The login cookie carries the required browser-side security attributes and no Domain scope.
#[tokio::test]
async fn login_cookie_has_secure_host_scope() {
    let response = send(
        app(),
        Method::POST,
        "/api/v1/session/login",
        Some(PRE_AUTH_SESSION_ID),
        None,
        Some(VerifiedIdentity::new(7)),
    )
    .await;
    let cookie = response
        .headers()
        .get(SET_COOKIE)
        .expect("session cookie")
        .to_str()
        .expect("valid header");
    assert!(cookie.contains("; Path=/"));
    assert!(cookie.contains("; Secure"));
    assert!(cookie.contains("; HttpOnly"));
    assert!(cookie.contains("; SameSite=Lax"));
    assert!(!cookie.to_ascii_lowercase().contains("domain="));
    assert!(!cookie.contains(CSRF_TOKEN));
    let body: LoginView = serde_json::from_value(response_json(response).await)
        .expect("login returns the synchronizer token outside the cookie");
    assert_eq!(body.csrf_token, CSRF_TOKEN);
}

/// Missing CSRF proof rejects logout without revoking the active server session.
#[tokio::test]
async fn logout_rejects_missing_csrf_token() {
    let router = app();
    let response = send(
        router.clone(),
        Method::POST,
        "/api/v1/session/logout",
        Some(AUTH_SESSION_ID),
        None,
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
    assert_eq!(response_json(response).await["code"], "csrf_failed");
    let session = send(
        router,
        Method::GET,
        "/api/v1/session",
        Some(AUTH_SESSION_ID),
        None,
        None,
    )
    .await;
    assert_eq!(session.status(), StatusCode::OK);
}

/// A CSRF proof from another value cannot authorize the logout request.
#[tokio::test]
async fn logout_rejects_wrong_csrf_token() {
    let response = send(
        app(),
        Method::POST,
        "/api/v1/session/logout",
        Some(AUTH_SESSION_ID),
        Some("attacker-controlled-value"),
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
}

/// A cookie-only CSRF value is not accepted as the synchronizer header proof.
#[tokio::test]
async fn csrf_value_in_cookie_does_not_authorize_logout() {
    let request = Request::builder()
        .method(Method::POST)
        .uri("/api/v1/session/logout")
        .header(
            COOKIE,
            format!("{SESSION_COOKIE}={AUTH_SESSION_ID}; csrf={CSRF_TOKEN}"),
        )
        .body(Body::empty())
        .expect("valid exercise request");
    let response = app().oneshot(request).await.expect("router response");
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
}

/// Valid logout revokes server state and expires the matching browser cookie.
#[tokio::test]
async fn valid_logout_revokes_session_and_expires_cookie() {
    let router = app();
    let response = send(
        router.clone(),
        Method::POST,
        "/api/v1/session/logout",
        Some(AUTH_SESSION_ID),
        Some(CSRF_TOKEN),
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::NO_CONTENT);
    let expired_cookie = response
        .headers()
        .get(SET_COOKIE)
        .expect("expired session cookie")
        .to_str()
        .expect("valid header");
    assert!(expired_cookie.starts_with("__Host-session="));
    assert!(expired_cookie.contains("Max-Age=0"));

    let session = send(
        router,
        Method::GET,
        "/api/v1/session",
        Some(AUTH_SESSION_ID),
        None,
        None,
    )
    .await;
    assert_eq!(session.status(), StatusCode::UNAUTHORIZED);
}

/// Logout is a state-changing POST; a GET to that path cannot revoke the session.
#[tokio::test]
async fn get_logout_is_not_registered_or_state_changing() {
    let router = app();
    let response = send(
        router.clone(),
        Method::GET,
        "/api/v1/session/logout",
        Some(AUTH_SESSION_ID),
        None,
        None,
    )
    .await;
    assert_eq!(response.status(), StatusCode::METHOD_NOT_ALLOWED);
    let session = send(
        router,
        Method::GET,
        "/api/v1/session",
        Some(AUTH_SESSION_ID),
        None,
        None,
    )
    .await;
    assert_eq!(session.status(), StatusCode::OK);
}
