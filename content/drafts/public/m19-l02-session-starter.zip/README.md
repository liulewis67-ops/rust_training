# M19-L02 session and CSRF exercise

This exercise uses Axum Extra `CookieJar` for cookie parsing and response updates. Session IDs and CSRF values are deterministic test fixtures supplied by an in-memory session adapter; they are not a session protocol and must never be deployed. Real applications should use a maintained framework or identity/session provider that issues opaque unpredictable identifiers and enforces expiry and revocation.

The public baseline intentionally reuses a pre-authentication fixture ID, omits cookie security attributes, and accepts logout without checking a CSRF token. The public HTTP contract tests identify those gaps.

Run from this directory:

```text
cargo test --locked --no-fail-fast
cargo clippy --locked --all-targets -- -D warnings
```

The Linux R3 container is deliberately not launched for this author-side package.
