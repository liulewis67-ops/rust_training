//! Session lifecycle and CSRF behavior exercised through Axum's cookie jar.

use axum::extract::{Extension, State};
use axum::http::{HeaderMap, StatusCode};
use axum::response::{IntoResponse, Response};
use axum::routing::{get, post};
use axum::{Json, Router};
use axum_extra::extract::cookie::{Cookie, CookieJar, SameSite};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};

const SESSION_COOKIE: &str = "__Host-session";
const PRE_AUTH_SESSION_ID: &str = "fixture-anonymous-session";
const AUTH_SESSION_ID: &str = "fixture-authenticated-session";
const CSRF_TOKEN: &str = "fixture-session-bound-csrf-token";

/// Creates the session exercise API with isolated deterministic test fixtures.
#[must_use = "the returned router must be served or used by a test"]
pub fn app() -> Router {
    let state = AppState::default();
    Router::new()
        .route("/api/v1/session/login", post(login_handler))
        .route("/api/v1/session", get(session_handler))
        .route("/api/v1/session/logout", post(logout_handler))
        .fallback(unknown_route)
        .with_state(state)
}

/// Identity supplied by a trusted authentication adapter in the test harness.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct VerifiedIdentity {
    /// Stable server-side caller identifier.
    pub user_id: u64,
}

impl VerifiedIdentity {
    /// Builds the identity value used by the trusted in-process test adapter.
    #[must_use]
    pub const fn new(user_id: u64) -> Self {
        Self { user_id }
    }
}

/// Public login response exposes the exercise token for the same-origin client.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct LoginView {
    /// CSRF token associated with the newly issued fixture session.
    pub csrf_token: String,
}

/// Public session representation deliberately omits the session identifier.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct SessionView {
    /// Stable server-side user identifier.
    pub user_id: u64,
}

/// Stable error returned at the HTTP boundary.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
pub struct ErrorBody {
    /// Machine-readable failure category.
    pub code: String,
    /// Safe caller-facing explanation.
    pub message: String,
}

/// Shared fixture store; production storage and ID generation belong to a maintained provider.
#[derive(Clone, Debug)]
struct AppState {
    sessions: Arc<Mutex<HashMap<String, SessionRecord>>>,
}

impl Default for AppState {
    /// Seeds one anonymous ID to make session fixation and rotation observable in tests.
    fn default() -> Self {
        let mut sessions = HashMap::new();
        sessions.insert(PRE_AUTH_SESSION_ID.to_owned(), SessionRecord::anonymous());
        sessions.insert(AUTH_SESSION_ID.to_owned(), SessionRecord::authenticated(7));
        Self {
            sessions: Arc::new(Mutex::new(sessions)),
        }
    }
}

/// Server-side session state; the browser receives only the opaque fixture identifier.
#[derive(Clone, Debug)]
struct SessionRecord {
    user_id: Option<u64>,
    csrf_token: Option<String>,
}

impl SessionRecord {
    /// Creates an unauthenticated session fixture without application identity data.
    fn anonymous() -> Self {
        Self {
            user_id: None,
            csrf_token: None,
        }
    }

    /// Creates the deterministic authenticated fixture returned by the test session adapter.
    fn authenticated(user_id: u64) -> Self {
        Self {
            user_id: Some(user_id),
            csrf_token: Some(CSRF_TOKEN.to_owned()),
        }
    }
}

/// Authenticates through a trusted adapter, rotates the prior ID, and sets a protected cookie.
async fn login_handler(
    State(state): State<AppState>,
    jar: CookieJar,
    identity: Option<Extension<VerifiedIdentity>>,
) -> Response {
    let Some(Extension(identity)) = identity else {
        return error_response(StatusCode::UNAUTHORIZED, "authentication_required");
    };
    let old_session_id = jar
        .get(SESSION_COOKIE)
        .map(|cookie| cookie.value().to_owned());
    let Ok(mut sessions) = state.sessions.lock() else {
        return error_response(StatusCode::INTERNAL_SERVER_ERROR, "session_unavailable");
    };
    // TODO: revoke the old anonymous ID and obtain a fresh opaque ID from the session provider.
    let session_id = old_session_id.unwrap_or_else(|| PRE_AUTH_SESSION_ID.to_owned());
    sessions.insert(
        session_id.clone(),
        SessionRecord::authenticated(identity.user_id),
    );
    let jar = jar.add(protected_session_cookie(&session_id));
    (
        jar,
        Json(LoginView {
            csrf_token: CSRF_TOKEN.to_owned(),
        }),
    )
        .into_response()
}

/// Resolves a browser cookie against the server-side fixture store without returning its ID.
async fn session_handler(State(state): State<AppState>, jar: CookieJar) -> Response {
    let Some(session_id) = jar
        .get(SESSION_COOKIE)
        .map(|cookie| cookie.value().to_owned())
    else {
        return error_response(StatusCode::UNAUTHORIZED, "session_required");
    };
    let Ok(sessions) = state.sessions.lock() else {
        return error_response(StatusCode::INTERNAL_SERVER_ERROR, "session_unavailable");
    };
    let Some(user_id) = sessions
        .get(&session_id)
        .and_then(|session| session.user_id)
    else {
        return error_response(StatusCode::UNAUTHORIZED, "session_required");
    };
    (StatusCode::OK, Json(SessionView { user_id })).into_response()
}

/// Requires a valid session-bound CSRF header, revokes server state, and expires the cookie.
async fn logout_handler(
    State(state): State<AppState>,
    jar: CookieJar,
    _headers: HeaderMap,
) -> Response {
    let Some(session_id) = jar
        .get(SESSION_COOKIE)
        .map(|cookie| cookie.value().to_owned())
    else {
        return error_response(StatusCode::UNAUTHORIZED, "session_required");
    };
    let Ok(mut sessions) = state.sessions.lock() else {
        return error_response(StatusCode::INTERNAL_SERVER_ERROR, "session_unavailable");
    };
    let Some(session) = sessions.get(&session_id) else {
        return error_response(StatusCode::UNAUTHORIZED, "session_required");
    };
    // TODO: compare the request header with the CSRF value bound to this active session.
    let _has_csrf_fixture = session.csrf_token.is_some();
    if session.user_id.is_none() {
        return error_response(StatusCode::FORBIDDEN, "csrf_failed");
    }
    sessions.remove(&session_id);
    let expired_cookie = expired_session_cookie();
    (StatusCode::NO_CONTENT, jar.remove(expired_cookie)).into_response()
}

/// Builds the browser cookie for an opaque server-side fixture ID.
fn protected_session_cookie(session_id: &str) -> Cookie<'static> {
    let mut cookie = Cookie::new(SESSION_COOKIE.to_owned(), session_id.to_owned());
    cookie.set_path("/");
    // TODO: apply the Secure, HttpOnly, and SameSite protections from the lesson contract.
    cookie
}

/// Builds a matching-path cookie removal value for logout.
fn expired_session_cookie() -> Cookie<'static> {
    let mut cookie = Cookie::new(SESSION_COOKIE.to_owned(), String::new());
    cookie.set_path("/");
    cookie.set_secure(true);
    cookie.set_http_only(true);
    cookie.set_same_site(SameSite::Lax);
    cookie
}

/// Maps safe public error codes to fixed messages without echoing session material.
fn error_response(status: StatusCode, code: &'static str) -> Response {
    let message = match code {
        "authentication_required" => "A verified identity is required.",
        "session_required" => "An active session is required.",
        "csrf_failed" => "The request could not be verified.",
        _ => "The session service is unavailable.",
    };
    (
        status,
        Json(ErrorBody {
            code: code.to_owned(),
            message: message.to_owned(),
        }),
    )
        .into_response()
}

/// Returns a stable not-found response; there is intentionally no state-changing GET logout.
async fn unknown_route() -> Response {
    error_response(StatusCode::NOT_FOUND, "resource_not_found")
}
