use m23_l02_allocation_starter::{
    Record, encode_json_direct, encode_json_via_string, has_match, has_match_borrowed,
    matching_labels_borrowed, matching_labels_owned,
};

fn records() -> Vec<Record> {
    vec![
        Record {
            id: 1,
            category: "match".into(),
            label: "你好 \"Rust\"".into(),
        },
        Record {
            id: 2,
            category: "skip".into(),
            label: "other".into(),
        },
        Record {
            id: 3,
            category: "match".into(),
            label: "allocation".into(),
        },
    ]
}

#[test]
fn owned_and_borrowed_query_paths_have_the_same_result() {
    let input = records();
    for query in ["你好 \"Rust\"", "absent", "你好 \"rust\"", ""] {
        assert_eq!(has_match(&input, query), has_match_borrowed(&input, query));
    }
    assert!(has_match(&input, "你好 \"Rust\""));
    assert!(!has_match(&input, "你好 \"rust\""));
}

#[test]
fn owned_and_borrowed_filtered_labels_match_in_order() {
    let input = records();
    let owned = matching_labels_owned(&input, "match");
    let borrowed = matching_labels_borrowed(&input, "match");
    assert_eq!(owned, borrowed);
    assert_eq!(
        matching_labels_borrowed(&input, "absent"),
        Vec::<&str>::new()
    );
}

#[test]
fn direct_serialization_matches_reference_bytes_and_round_trips() {
    let input = records();
    let reference = encode_json_via_string(&input).unwrap();
    let direct = encode_json_direct(&input).unwrap();
    assert_eq!(direct, reference);
    assert_eq!(
        serde_json::from_slice::<Vec<Record>>(&direct).unwrap(),
        input
    );
}

#[test]
fn empty_input_serializes_to_an_empty_json_array() {
    assert_eq!(encode_json_direct(&[]).unwrap(), b"[]");
}
