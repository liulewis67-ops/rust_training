//! Small record pipeline used by the M23-L02 allocation exercise.

use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Deserialize, PartialEq, Eq, Serialize)]
pub struct Record {
    pub id: u64,
    pub category: String,
    pub label: String,
}

/// Reference query that currently allocates a temporary owned label per visit.
pub fn has_match(records: &[Record], expected_label: &str) -> bool {
    records
        .iter()
        .any(|record| record.label.clone().as_str() == expected_label)
}

/// Borrowed comparison supplied as a behaviorally equivalent measurement baseline.
pub fn has_match_borrowed(records: &[Record], expected_label: &str) -> bool {
    records
        .iter()
        .any(|record| record.label.as_str() == expected_label)
}

/// Collect matching labels into independently owned strings.
pub fn matching_labels_owned(records: &[Record], category: &str) -> Vec<String> {
    records
        .iter()
        .filter(|record| record.category == category)
        .map(|record| record.label.clone())
        .collect()
}

/// Collect matching label views tied to the lifetime of the input records.
pub fn matching_labels_borrowed<'a>(records: &'a [Record], category: &str) -> Vec<&'a str> {
    records
        .iter()
        .filter(|record| record.category == category)
        .map(|record| record.label.as_str())
        .collect()
}

/// Encode through a JSON String before converting its UTF-8 bytes to a Vec.
pub fn encode_json_via_string(records: &[Record]) -> Result<Vec<u8>, serde_json::Error> {
    Ok(serde_json::to_string(records)?.into_bytes())
}

/// Exercise stub: return the direct JSON byte representation.
pub fn encode_json_direct(records: &[Record]) -> Result<Vec<u8>, serde_json::Error> {
    let _ = records;
    Ok(Vec::new())
}
