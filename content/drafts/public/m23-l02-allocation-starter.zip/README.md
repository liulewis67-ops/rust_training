# M23-L02 allocation and serialization starter

This public starter contains two intentional exercise points:

1. `has_match` clones each candidate label before comparing it.
2. `encode_json_direct` is a stub and must emit the same bytes as the String-based reference path.

`benches/allocation_hotspots.rs` compares owned and borrowed query/serialization paths on one fixed input. It is an experiment harness, not a promise that one path wins on every target. Follow the M23-L02 course package instructions and do not present Windows results as R2/R3 evidence.
