use std::hint::black_box;
use std::time::Duration;

use criterion::{Criterion, Throughput, criterion_group, criterion_main};
use m23_l02_allocation_starter::{
    Record, encode_json_direct, encode_json_via_string, has_match, has_match_borrowed,
    matching_labels_borrowed, matching_labels_owned,
};

/// Build the fixed record fixture outside measured iterations.
fn fixed_records() -> Vec<Record> {
    (0..10_000)
        .map(|id| Record {
            id,
            category: if id % 4 == 0 { "match" } else { "other" }.into(),
            label: format!("label-{id:05}-with-payload"),
        })
        .collect()
}

/// Run the clone/borrow and String/bytes comparisons over one identical fixture.
fn allocation_hotspots(criterion: &mut Criterion) {
    let records = fixed_records();
    let mut group = criterion.benchmark_group("record-pipeline");
    group.sample_size(20);
    group.warm_up_time(Duration::from_secs(1));
    group.measurement_time(Duration::from_secs(2));
    group.throughput(Throughput::Elements(records.len() as u64));

    group.bench_function("query_clone", |bencher| {
        bencher.iter(|| black_box(has_match(black_box(&records), black_box("absent"))))
    });
    group.bench_function("query_borrow", |bencher| {
        bencher.iter(|| black_box(has_match_borrowed(black_box(&records), black_box("absent"))))
    });
    group.bench_function("collect_owned_labels", |bencher| {
        bencher.iter(|| {
            black_box(matching_labels_owned(
                black_box(&records),
                black_box("match"),
            ))
        })
    });
    group.bench_function("collect_borrowed_labels", |bencher| {
        bencher.iter(|| {
            black_box(matching_labels_borrowed(
                black_box(&records),
                black_box("match"),
            ))
        })
    });
    group.bench_function("json_string_then_bytes", |bencher| {
        bencher.iter(|| black_box(encode_json_via_string(black_box(&records)).unwrap()))
    });
    group.bench_function("json_direct_bytes", |bencher| {
        bencher.iter(|| black_box(encode_json_direct(black_box(&records)).unwrap()))
    });
    group.finish();
}

criterion_group!(benches, allocation_hotspots);
criterion_main!(benches);
