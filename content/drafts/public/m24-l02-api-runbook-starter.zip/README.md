# M24-L02 API and runbook contracts

Implement the missing API operation validation and runbook section checker described in the exercise sheet. This starter checks documentation completeness, not whether a real service implements the documented behavior.
