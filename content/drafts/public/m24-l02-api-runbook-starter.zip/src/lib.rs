//! Documentation contracts for API operations and service runbooks.

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct OperationDoc {
    pub operation_id: String,
    pub method: String,
    pub path: String,
    pub auth: String,
    pub request_id_header: String,
    pub success_status: u16,
    pub error_codes: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum OperationError {
    MissingOperationId,
    MissingMethod,
    MissingPath,
    MissingAuth,
    MissingRequestIdHeader,
    InvalidSuccessStatus,
    MissingErrorCodes,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum RunbookSection {
    ScopeVersion,
    Prerequisites,
    Startup,
    HealthChecks,
    Diagnostics,
    Rollback,
    StopAndEscalate,
}

const REQUIRED_SECTIONS: [(&str, RunbookSection); 7] = [
    ("scope_version", RunbookSection::ScopeVersion),
    ("prerequisites", RunbookSection::Prerequisites),
    ("startup", RunbookSection::Startup),
    ("health_checks", RunbookSection::HealthChecks),
    ("diagnostics", RunbookSection::Diagnostics),
    ("rollback", RunbookSection::Rollback),
    ("stop_and_escalate", RunbookSection::StopAndEscalate),
];

/// Validate the minimum information a caller needs to understand one API operation.
pub fn validate_operation(operation: &OperationDoc) -> Result<(), OperationError> {
    if operation.operation_id.trim().is_empty() {
        return Err(OperationError::MissingOperationId);
    }
    if operation.method.trim().is_empty() {
        return Err(OperationError::MissingMethod);
    }
    if operation.path.trim().is_empty() {
        return Err(OperationError::MissingPath);
    }
    if operation.auth.trim().is_empty() {
        return Err(OperationError::MissingAuth);
    }
    if operation.request_id_header.trim().is_empty() {
        return Err(OperationError::MissingRequestIdHeader);
    }
    let _ = operation;
    Ok(())
}

/// Return required runbook sections absent from the document, in contract order.
pub fn missing_sections(present: &[&str]) -> Vec<RunbookSection> {
    let _ = present;
    let _ = REQUIRED_SECTIONS;
    Vec::new()
}
