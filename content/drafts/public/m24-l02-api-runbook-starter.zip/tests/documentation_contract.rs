use m24_l02_api_runbook_starter::{
    OperationDoc, OperationError, RunbookSection, missing_sections, validate_operation,
};

/// Return an operation document with every required caller-facing field.
fn valid_operation() -> OperationDoc {
    OperationDoc {
        operation_id: "listProjectTasks".into(),
        method: "GET".into(),
        path: "/v1/projects/{project_id}/tasks".into(),
        auth: "Project owner or member with task:read".into(),
        request_id_header: "X-Request-Id".into(),
        success_status: 200,
        error_codes: vec!["project_forbidden".into(), "rate_limited".into()],
    }
}

/// Accept a complete operation description.
#[test]
fn accepts_complete_operation() {
    assert_eq!(validate_operation(&valid_operation()), Ok(()));
}

/// Reject a success response without a valid status code.
#[test]
fn rejects_missing_success_status() {
    let mut operation = valid_operation();
    operation.success_status = 0;
    assert_eq!(
        validate_operation(&operation),
        Err(OperationError::InvalidSuccessStatus)
    );
}

/// Reject an operation with no documented error mapping.
#[test]
fn rejects_missing_error_codes() {
    let mut operation = valid_operation();
    operation.error_codes = vec!["   ".into()];
    assert_eq!(
        validate_operation(&operation),
        Err(OperationError::MissingErrorCodes)
    );
}

/// Report every required section when the runbook has no section names.
#[test]
fn reports_all_missing_sections_in_contract_order() {
    assert_eq!(
        missing_sections(&[]),
        vec![
            RunbookSection::ScopeVersion,
            RunbookSection::Prerequisites,
            RunbookSection::Startup,
            RunbookSection::HealthChecks,
            RunbookSection::Diagnostics,
            RunbookSection::Rollback,
            RunbookSection::StopAndEscalate,
        ]
    );
}

/// Ignore unknown section names and retain the order of remaining requirements.
#[test]
fn reports_only_uncovered_sections() {
    assert_eq!(
        missing_sections(&["startup", "future_extension", "rollback"]),
        vec![
            RunbookSection::ScopeVersion,
            RunbookSection::Prerequisites,
            RunbookSection::HealthChecks,
            RunbookSection::Diagnostics,
            RunbookSection::StopAndEscalate,
        ]
    );
}
