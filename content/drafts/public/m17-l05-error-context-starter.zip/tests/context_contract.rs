//! Checks the request context across success and failure responses.

use axum::body::{Body, to_bytes};
use axum::http::{Request, StatusCode};
use m17_l05_error_context::{TraceLog, app};
use tower::ServiceExt;

/// Sends one route request and returns response status, headers, body and trace.
async fn send(
    uri: &str,
    request_id: Option<&str>,
) -> (
    StatusCode,
    axum::http::HeaderMap,
    serde_json::Value,
    TraceLog,
) {
    let (router, trace) = app();
    let mut builder = Request::builder()
        .uri(uri)
        .header("authorization", "Bearer never-log-this");
    if let Some(request_id) = request_id {
        builder = builder.header("x-request-id", request_id);
    }
    let response = router
        .oneshot(builder.body(Body::from("password=never-log-this")).unwrap())
        .await
        .unwrap();
    let status = response.status();
    let headers = response.headers().clone();
    let bytes = to_bytes(response.into_body(), usize::MAX).await.unwrap();
    let body = serde_json::from_slice(&bytes).unwrap_or(serde_json::Value::Null);
    (status, headers, body, trace)
}

/// Echoes a valid incoming ID through the handler and response path.
#[tokio::test]
async fn incoming_id_is_propagated() {
    let (status, headers, _, trace) = send("/users/42", Some("req-abc_123")).await;
    assert_eq!(status, StatusCode::OK);
    assert_eq!(headers["x-request-id"], "req-abc_123");
    assert!(
        trace
            .snapshot()
            .iter()
            .any(|event| event == "id=req-abc_123 handler")
    );
}

/// Generates a context ID when no upstream request ID is supplied.
#[tokio::test]
async fn missing_id_is_generated_and_correlated() {
    let (status, headers, _, trace) = send("/users/42", None).await;
    assert_eq!(status, StatusCode::OK);
    let id = headers
        .get("x-request-id")
        .expect("generated request id")
        .to_str()
        .unwrap();
    assert!(!id.is_empty());
    assert!(
        trace
            .snapshot()
            .iter()
            .any(|event| event == &format!("id={id} status=200"))
    );
}

/// Keeps a not-found body stable while returning the same context ID.
#[tokio::test]
async fn error_response_is_correlated() {
    let (status, headers, body, trace) = send("/users/missing", Some("req-missing-4")).await;
    assert_eq!(status, StatusCode::NOT_FOUND);
    assert_eq!(body["code"], "not_found");
    assert_eq!(headers["x-request-id"], "req-missing-4");
    assert!(
        trace
            .snapshot()
            .iter()
            .any(|event| event == "id=req-missing-4 status=404")
    );
}

/// Rejects unsafe or oversized caller IDs and avoids recording credentials.
#[tokio::test]
async fn invalid_id_is_replaced_without_logging_request_secrets() {
    let (status, headers, _, trace) = send("/users/offline", Some("secret=value")).await;
    assert_eq!(status, StatusCode::SERVICE_UNAVAILABLE);
    let id = headers
        .get("x-request-id")
        .expect("generated request id")
        .to_str()
        .unwrap();
    assert_ne!(id, "secret=value");
    let output = trace.snapshot().join("|");
    assert!(!output.contains("never-log-this"));
    assert!(!output.contains("secret=value"));
}
