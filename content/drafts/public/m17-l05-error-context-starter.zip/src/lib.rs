//! Starter for request ID propagation and stable API error correlation.

use axum::body::Body;
use axum::extract::{Extension, Path, Request, State};
use axum::http::{HeaderName, HeaderValue, StatusCode};
use axum::middleware::{self, Next};
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::{Json, Router};
use serde::Serialize;
use std::sync::{Arc, Mutex};

const REQUEST_ID: HeaderName = HeaderName::from_static("x-request-id");

/// Request-scoped context attached by the outer middleware.
#[derive(Clone, Debug)]
struct RequestContext {
    request_id: Option<String>,
}

/// Cloneable event sink that stores only context IDs and response status.
#[derive(Clone, Default)]
pub struct TraceLog(Arc<Mutex<Vec<String>>>);

impl TraceLog {
    /// Returns a stable snapshot of recorded low-sensitivity events.
    pub fn snapshot(&self) -> Vec<String> {
        self.0.lock().expect("trace lock poisoned").clone()
    }

    /// Records one event without request payload or credential fields.
    fn record(&self, event: String) {
        self.0.lock().expect("trace lock poisoned").push(event);
    }
}

/// Client-safe body shared by every application error response.
#[derive(Serialize)]
struct ErrorBody {
    code: &'static str,
    message: &'static str,
}

/// Application error categories mapped to stable HTTP responses.
enum ApiError {
    NotFound,
    Unavailable,
}

/// Converts application failures without serializing internal diagnostics.
impl IntoResponse for ApiError {
    /// Builds the public status/code/message representation.
    fn into_response(self) -> Response {
        let (status, code, message) = match self {
            Self::NotFound => (StatusCode::NOT_FOUND, "not_found", "user was not found"),
            Self::Unavailable => (
                StatusCode::SERVICE_UNAVAILABLE,
                "service_unavailable",
                "service temporarily unavailable",
            ),
        };
        (status, Json(ErrorBody { code, message })).into_response()
    }
}

/// Builds the user router with the request-context middleware.
pub fn app() -> (Router, TraceLog) {
    let trace = TraceLog::default();
    let router = Router::new()
        .route("/users/{id}", get(show_user))
        .layer(middleware::from_fn_with_state(
            trace.clone(),
            request_context,
        ))
        .with_state(trace.clone());
    (router, trace)
}

/// Validates or assigns a request ID and correlates the completed response.
async fn request_context(
    State(trace): State<TraceLog>,
    mut request: Request<Body>,
    next: Next,
) -> Response {
    let request_id = request
        .headers()
        .get(&REQUEST_ID)
        .and_then(|value| value.to_str().ok())
        .filter(|value| valid_request_id(value))
        .map(str::to_owned);
    let context = RequestContext {
        request_id: request_id.clone(),
    };
    request.extensions_mut().insert(context);
    let mut response = next.run(request).await;
    if let Some(request_id) = request_id
        && let Ok(value) = HeaderValue::from_str(&request_id)
    {
        response.headers_mut().insert(REQUEST_ID.clone(), value);
        trace.record(format!(
            "id={request_id} status={}",
            response.status().as_u16()
        ));
    }
    response
}

/// Accepts short visible IDs that cannot inject line breaks or log structure.
fn valid_request_id(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= 64
        && value
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || byte == b'-' || byte == b'_')
}

/// Handles the fixture user while recording only its request context.
async fn show_user(
    Extension(context): Extension<RequestContext>,
    State(trace): State<TraceLog>,
    Path(raw_id): Path<String>,
) -> Result<Json<serde_json::Value>, ApiError> {
    if let Some(request_id) = context.request_id {
        trace.record(format!("id={request_id} handler"));
    }
    match raw_id.as_str() {
        "42" => Ok(Json(serde_json::json!({"id": 42, "name": "Ada"}))),
        "missing" => Err(ApiError::NotFound),
        "offline" => Err(ApiError::Unavailable),
        _ => Err(ApiError::NotFound),
    }
}
