//! Provides a small stable interface for validating and describing profiles.

mod name;
mod report;

pub use name::ProfileNameError;
pub use report::render_profile_report;
