use crate::ProfileNameError;
use crate::name::ProfileName;

/// Formats a validated profile name behind the core crate's stable interface.
///
/// # Errors
/// Returns the specific validation failure when `raw_name` is not a profile name.
pub fn render_profile_report(raw_name: &str) -> Result<String, ProfileNameError> {
    let name = ProfileName::parse(raw_name)?;
    Ok(format!("profile={}", name.as_str()))
}
