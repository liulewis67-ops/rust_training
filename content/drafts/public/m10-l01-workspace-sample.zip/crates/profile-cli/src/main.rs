use profile_core::render_profile_report;

/// Runs the small profile-report example through the core interface.
fn main() {
    match render_profile_report("training_user") {
        Ok(report) => println!("{report}"),
        Err(error) => eprintln!("profile name is invalid: {error:?}"),
    }
}
