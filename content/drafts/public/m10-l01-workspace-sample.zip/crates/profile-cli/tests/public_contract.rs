use profile_core::{ProfileNameError, render_profile_report};

/// Ensures the binary package can use the small public core interface.
#[test]
fn formats_a_valid_profile_report() {
    assert_eq!(
        render_profile_report("training_user"),
        Ok("profile=training_user".to_owned())
    );
}

/// Ensures invalid input returns a typed error across the package seam.
#[test]
fn rejects_a_profile_name_with_spaces() {
    assert_eq!(
        render_profile_report("two names"),
        Err(ProfileNameError::InvalidCharacters)
    );
}

/// Ensures empty names and overlong names remain distinct core errors.
#[test]
fn reports_empty_and_overlong_names() {
    assert_eq!(render_profile_report("   "), Err(ProfileNameError::Empty));
    assert_eq!(
        render_profile_report("abcdefghijklmnopqrstuvwxyz"),
        Err(ProfileNameError::TooLong)
    );
}
