# M10-L01 示例：profile workspace

这是两个独立 package 组成的 Edition 2024 Cargo workspace：`profile-core` 提供配置校验与报告接口，`profile-cli` 通过明确的本地路径依赖调用它。Cargo workspace 管理 package 的成员关系、锁文件和共同命令；成员关系本身不会建立 Rust 代码依赖。

从根目录运行：

```text
cargo check --workspace --offline
cargo check -p profile-core --offline
cargo check -p profile-cli --offline
cargo test --workspace --offline
```

`profile-core` 的根模块只重导出 CLI 必须知道的报告函数和错误类型。解析类型、字段和模块实现保持 crate 内部；CLI 不依赖其文件布局。
