use std::io::Cursor;

use log_core::{
    InputFormat, Level, LogFilter, ParseErrorKind, ProcessError, parse_line, parse_tab_line,
    process_reader, process_reader_with_format,
};

/// Verifies Unicode messages and blank lines are handled by the parser.
#[test]
fn counts_unicode_records_and_skips_empty_lines() {
    let input = "\n10|INFO|启动完成\n11|ERROR|磁盘已满\n";
    let summary = process_reader(Cursor::new(input), &LogFilter::default()).unwrap();

    assert_eq!(summary.records, 2);
    assert_eq!(summary.infos, 1);
    assert_eq!(summary.errors, 1);
}

/// Verifies separators after the second delimiter remain part of the message.
#[test]
fn preserves_delimiters_inside_messages() {
    let record = parse_line(1, "1|INFO|first|second")
        .unwrap()
        .expect("a nonempty row should produce a record");

    assert_eq!(record.message, "first|second");
}

/// Verifies the additive tab grammar preserves tabs and Unicode in messages.
#[test]
fn parses_tab_rows_without_changing_pipe_rows() {
    let input = "ERROR\t10\t磁盘\t已满\nINFO\t11\tready\n";
    let summary =
        process_reader_with_format(Cursor::new(input), &LogFilter::default(), InputFormat::Tab)
            .unwrap();

    assert_eq!(summary.records, 2);
    assert_eq!(summary.errors, 1);
    let record = parse_tab_line(1, "ERROR\t10\t磁盘\t已满")
        .unwrap()
        .expect("a valid tab row should produce a record");
    assert_eq!(record.message, "磁盘\t已满");
    assert_eq!(
        process_reader(Cursor::new("10|ERROR|磁盘已满\n"), &LogFilter::default())
            .unwrap()
            .errors,
        1
    );
}

/// Verifies tab-format failures retain line numbers and parse categories.
#[test]
fn rejects_bad_tab_row_with_original_line_number() {
    let error = process_reader_with_format(
        Cursor::new("INFO\t1\tok\nTRACE\t2\tbad\n"),
        &LogFilter::default(),
        InputFormat::Tab,
    )
    .unwrap_err();

    assert!(matches!(
        error,
        ProcessError::Parse(error)
            if error.line == 2 && error.kind == ParseErrorKind::InvalidLevel
    ));
}

/// Verifies malformed rows report a stable line and error category.
#[test]
fn reports_bad_timestamp_line_number() {
    let input = "1|INFO|ok\nx|INFO|bad\n";
    let error = process_reader(Cursor::new(input), &LogFilter::default()).unwrap_err();

    assert!(matches!(
        error,
        ProcessError::Parse(error)
            if error.line == 2 && error.kind == ParseErrorKind::InvalidTimestamp
    ));
}

/// Verifies unknown severity values are rejected instead of silently ignored.
#[test]
fn rejects_unknown_severity() {
    let error =
        process_reader(Cursor::new("1|TRACE|hidden event\n"), &LogFilter::default()).unwrap_err();

    assert!(matches!(
        error,
        ProcessError::Parse(error) if error.kind == ParseErrorKind::InvalidLevel
    ));
}

/// Verifies level, time, and case-sensitive keyword filters compose together.
#[test]
fn combines_level_time_and_keyword_filters() {
    let filter = LogFilter {
        levels: vec![Level::Error],
        from_ms: Some(10),
        until_ms: Some(20),
        contains: Some("failed".to_owned()),
    };
    let input = concat!(
        "9|ERROR|request failed\n",
        "10|ERROR|request failed\n",
        "15|INFO|request failed\n",
        "19|ERROR|request failed\n",
        "20|ERROR|request failed\n",
        "18|ERROR|request Failed\n"
    );
    let summary = process_reader(Cursor::new(input), &filter).unwrap();

    assert_eq!(summary.records, 2);
    assert_eq!(summary.errors, 2);
}

/// Verifies no filter and empty input produce a zeroed summary.
#[test]
fn empty_input_produces_zero_counts() {
    let summary = process_reader(Cursor::new(""), &LogFilter::default()).unwrap();

    assert_eq!(summary.records, 0);
    assert_eq!(summary.warnings, 0);
}
