# M10-L06 独立检查：兼容新增日志格式

本 Edition 2024 workspace 从已完成的 P1 日志分析 CLI 开始。任务是为新来源增加可选 tab 分隔格式，同时保持旧 pipe 格式、已有过滤和输出契约。只阅读检查题面和此工作区，不查看教师参考或私有检查。

基线可以编译。运行公开行为检查并记录旧、新输入各自结果：

```text
cargo test --workspace --no-fail-fast --locked --offline
```

预期旧格式契约通过，新格式相关行为契约失败。实现后运行：

```text
cargo fmt --all -- --check
cargo check --workspace --locked --offline
cargo test --workspace --no-fail-fast --locked --offline
cargo clippy --workspace --all-targets --locked --offline -- -D warnings
cargo doc --workspace --no-deps --locked --offline
```

不要修改旧格式数据、默认行为、旧测试或汇总输出来绕过新检查；不得增加第三方依赖或改变现有 `LogRecord` 字段语义。

解压本 ZIP 至新目录后，按 `starter-manifest.json` 核验所有起始文件 SHA-256。保留原始快照；Cargo target 放在系统临时目录。重置请从原始 ZIP 重新解压。教师实现和独立学习者证据不得打入公开 ZIP。
