# M06-L05 起始项目：借用配置视图与拥有型配置

这是一个无第三方依赖的 Rust 2024 库项目。先阅读课程实验题面和公开契约测试，然后从本目录运行：

~~~text
cargo check --offline
cargo test --offline
~~~

起始实现提供借用视图和拥有型配置解析器；`queued_config` 尝试把借用视图字段直接放入 `String` 字段，导致类型不匹配。修复它时要明确选择文本所有权，不能让结果借用函数内的局部输入。

实验完成后执行：

~~~text
cargo fmt -- --check
cargo check --offline
cargo test --offline
~~~

公开测试核对借用与拥有解析结果一致、缺失分隔符和空字段、借用字段位于原始输入地址范围、以及队列结果在源输入离开作用域后仍可读取。完成修改后，再从新空目录解压原始 ZIP，按 `starter-manifest.json` 核对版本和逐文件哈希并重做实验。
