use m06_l05_config_choice::{parse_owned, parse_view, queued_config};

#[test]
fn borrowed_and_owned_parsers_agree() {
    for line in ["MODE=cache", "", "=value", "key="] {
        match (parse_view(line), parse_owned(line)) {
            (Some(view), Some(config)) => {
                assert_eq!(
                    (view.key, view.value),
                    (config.key.as_str(), config.value.as_str())
                );
            }
            (None, None) => {}
            _ => panic!("both APIs must agree on whether a separator exists"),
        }
    }
    assert_eq!(parse_view("missing separator"), None);
    assert_eq!(parse_owned("missing separator"), None);
}

#[test]
fn borrowed_fields_point_into_the_original_input() {
    let line = String::from("区域=缓存✅=later");
    let view = parse_view(&line).expect("input has a separator");
    assert_eq!((view.key, view.value), ("区域", "缓存✅=later"));

    let start = line.as_ptr() as usize;
    let end = start + line.len();
    for field in [view.key, view.value] {
        let field_start = field.as_ptr() as usize;
        assert!(field_start >= start);
        assert!(field_start + field.len() <= end);
    }
}

#[test]
fn queued_result_remains_usable_after_source_scope_ends() {
    let config = queued_config();
    assert_eq!(config.key, "MODE");
    assert_eq!(config.value, "cache");
}
