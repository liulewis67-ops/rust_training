/// A zero-copy view of two fields in caller-owned configuration text.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ConfigView<'source> {
    pub key: &'source str,
    pub value: &'source str,
}

/// Parses the fields around the first equals sign without copying text.
pub fn parse_view(line: &str) -> Option<ConfigView<'_>> {
    let (key, value) = line.split_once('=')?;
    Some(ConfigView { key, value })
}

/// An owned configuration that can be retained after its source is dropped.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Config {
    pub key: String,
    pub value: String,
}

/// Parses configuration text into fields owned by the returned value.
pub fn parse_owned(line: &str) -> Option<Config> {
    let (key, value) = line.split_once('=')?;
    Some(Config {
        key: key.to_owned(),
        value: value.to_owned(),
    })
}

/// Builds a queue-ready owned configuration from temporary source text.
pub fn queued_config() -> Config {
    let line = String::from("MODE=cache");
    let view = parse_view(&line).expect("the sample line contains '='");
    Config {
        key: view.key,
        value: view.value,
    }
}
