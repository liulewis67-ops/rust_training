use text_pipeline::{add_badge, append_period, render};

#[test]
fn render_preserves_the_original_and_runs_both_stages_in_order() {
    let (original, processed) = render(String::from("build complete"));

    assert_eq!(original, "build complete");
    assert_eq!(processed, "[ready] build complete.");
}

#[test]
fn each_stage_returns_its_updated_owned_string() {
    let badged = add_badge(String::from("build complete"));
    assert_eq!(badged, "[ready] build complete");

    let punctuated = append_period(badged);
    assert_eq!(punctuated, "[ready] build complete.");
}
