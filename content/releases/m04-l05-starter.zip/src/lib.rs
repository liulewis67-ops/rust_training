//! A small owned-string transformation pipeline.

/// Adds a status badge to an owned message.
pub fn add_badge(mut text: String) -> String {
    text.insert_str(0, "[ready] ");
    text
}

/// Adds terminal punctuation to an owned message.
pub fn append_period(mut text: String) -> String {
    text.push('.');
    text
}

/// Returns the original input alongside its transformed form.
pub fn render(source: String) -> (String, String) {
    let processed = append_period(add_badge(source));
    (source, processed)
}
