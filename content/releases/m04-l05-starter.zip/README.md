# M04-L05 起始项目：文本流水线

这是一个无第三方依赖的 Rust 2024 库项目。先阅读课程实验契约和公开测试，再运行：

```text
cargo check --offline
cargo test --offline
```

起始实现故意无法编译：`render` 把 `source` 按值交给 `add_badge` 后，又尝试返回已移动的 `source`。修复时需保持公开签名及测试，并使原文和两阶段处理结果都正确返回。

实验完成后执行：

```text
cargo fmt -- --check
cargo check --offline
cargo test --offline
```

从原始发行 ZIP 解压到新空目录来重置；逐项对照 `starter-manifest.json`。不要覆盖本起始快照。
