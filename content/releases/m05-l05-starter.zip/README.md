# M05-L05 起始项目：零复制文本查询

这是一个无第三方依赖的 Rust 2024 库项目。先阅读课程实验契约和公开测试，再运行：

~~~text
cargo check --offline
cargo test --offline
~~~

起始 find_token 尝试返回 &str，却有两个输入引用而未说明返回切片来自哪个输入。修复时保持公开签名语义，从 text 的原始 token 子切片中返回精确匹配项。

实验完成后执行：

~~~text
cargo fmt -- --check
cargo check --offline
cargo test --offline
~~~

公开测试检查 String 与字面量行为、Unicode 空白、精确查询、缺失结果和返回切片位于源文本地址区间。修改后再从新空目录解压原 ZIP，按 starter-manifest.json 核对版本与文件哈希。
