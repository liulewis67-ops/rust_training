//! Finds matching borrowed tokens in UTF-8 text.

/// Returns the first whitespace-delimited token matching the query.
pub fn find_token(text: &str, query: &str) -> Option<&str> {
    text.split_whitespace().find(|token| *token == query)
}
