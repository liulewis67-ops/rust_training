use zero_copy_query::find_token;

fn assert_slice_is_inside(source: &str, token: &str) {
    let source_start = source.as_ptr() as usize;
    let token_start = token.as_ptr() as usize;
    assert!(token_start >= source_start);
    assert!(token_start + token.len() <= source_start + source.len());
}

#[test]
fn finds_an_original_slice_in_a_string() {
    let document = String::from("red green blue");
    let result: Option<&str> = find_token(document.as_str(), "green");

    assert_eq!(result, Some("green"));
    assert_slice_is_inside(document.as_str(), result.unwrap());
}

#[test]
fn string_literals_have_the_same_query_behavior() {
    let source = "red green blue";
    let result = find_token(source, "blue");

    assert_eq!(result, Some("blue"));
    assert_slice_is_inside(source, result.unwrap());
}

#[test]
fn uses_unicode_whitespace_and_exact_matching() {
    let source = " red\u{3000}green blue ";

    assert_eq!(find_token(source, "green"), Some("green"));
    assert_eq!(find_token(source, "reen"), None);
    assert_eq!(find_token(source, "missing"), None);
}

#[test]
fn empty_and_all_whitespace_inputs_have_no_match() {
    assert_eq!(find_token("", "anything"), None);
    assert_eq!(find_token("　\t\n", "anything"), None);
}
